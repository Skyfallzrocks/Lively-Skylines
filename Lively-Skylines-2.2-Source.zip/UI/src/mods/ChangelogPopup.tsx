import React, { useState } from "react";

const VERSION = "2.2";
const DATE = "October 13, 2026";
const STORAGE_KEY = "lively-skylines-changelog-hidden";

const changes = [
    { tag: "NEW", color: "#ff4fa8", title: "Bars & nightclubs", items: ["Run every bar: drink prices, happy hour, bouncers, last call, live music and ID checks", "Real residents fill the most popular bars each night from 7 PM", "Liquor tax pays the city; ride-home vouchers cut drunk driving", "Fights, DUIs, underage drinking and noise complaints, plus inspections and promotions", "Laws like Late-Night Licenses, Noise Curfew and Happy Hour Ban change what bars can do"] },
    { tag: "NEW", color: "#f3c25b", title: "Casinos", items: ["Slots, blackjack and roulette, poker and a sportsbook, each upgradable", "House winnings and losses affect the city budget", "Jackpots, high rollers, cheaters and parking-lot robberies can trigger police chases", "Hotel tower, live shows, responsible-gaming and anti-money-laundering programs", "Gangs may try to launder money; problem gambling can grow"] },
    { tag: "NEW", color: "#ff2a4f", title: "Police chases", items: ["Reported crimes can trigger a car or foot pursuit", "Up to four active pursuits with a live pop-up", "Follow the suspect, send backup, deploy spike strips or call off the chase"] },
    { tag: "NEW", color: "#41d69c", title: "Community: youth centers & house parties", items: ["Open youth centers where gangs are strongest; teens visit in the afternoon", "Sports, job training and late-night programs can weaken gangs and reduce crime", "House parties at city homes can lead to noise complaints, police visits and fights"] },
    { tag: "NEW", color: "#ff8a3d", title: "Snapline social & bike share", items: ["Social media has photo posts, stories, likes and comments", "Bike share includes fares, memberships, theft, rebalancing crews and e-bikes"] },
    { tag: "IMPROVED", color: "#b28aff", title: "Linked politics", items: ["Elections re-elect the council using party polling", "Rallies can boost polls; popular laws can help the parties that backed them"] },
    { tag: "NEW", color: "#ff4fa8", title: "Gangs & cartels", items: ["Grow houses, stash houses, warehouses and front businesses can use city buildings", "Street sales use modeled stock, so groups can run dry", "District turf control, turf wars and violence affect neighborhoods", "Surveillance, raids and youth interventions have costs; seized cash goes to the city"] },
    { tag: "NEW", color: "#4f8bff", title: "Banking & treasury", items: ["City Treasury Bank is ready to use", "Deposits earn interest; municipal bonds provide funds now", "City credit ratings affect bond rates", "Loan defaults can hurt the bank, and banks can fail", "Small-business grant fund"] },
    { tag: "NEW", color: "#b28aff", title: "Laws & politics", items: ["45 city laws have benefits and tradeoffs for crime, budgets and public mood", "Council members vote by party platform; lobbying can sway close votes", "Annual elections include party preferences, polling stations and campaign rallies"] },
    { tag: "NEW", color: "#2fd0f0", title: "City news TV", items: ["Watch a city news channel with anchors, lower thirds, a ticker and remote controls", "Stories draw from modeled city activity"] },
    { tag: "NEW", color: "#3fd68d", title: "Home Market", items: ["Listings use residential rents and modeled sale prices", "City map includes nightlife, crime, parks and transit layers", "Compare mortgage costs with rent"] },
    { tag: "IMPROVED", color: "#ffbd59", title: "Events, maps & UI", items: ["Events planner previews attendance, risk and costs", "Dark Dispatch, Civic and Skylines maps show city roads and connected segments", "Quick Options sidebar can be hidden", "Updated loading screen"] },
    { tag: "FIXED", color: "#ff6170", title: "Fixes", items: ["Events and Home Market no longer crash the interface", "Changelog content stays inside its panel and scrolls when needed", "Long titles wrap without pushing controls out of alignment"] },
] as const;

const panelPosition = {
    position: "fixed" as const,
    left: "clamp(12px, 1.5vw, 24px)",
    top: "clamp(12px, calc(100vh - 620px), 448px)",
    width: "min(440px, calc(100vw - 24px))",
    height: "min(560px, calc(100vh - 24px))",
    maxHeight: "calc(100vh - 24px)",
    boxSizing: "border-box" as const,
};

export const ChangelogPopup = () => {
    const [hidden, setHidden] = useState(() => {
        try { return window.localStorage.getItem(STORAGE_KEY) === VERSION; }
        catch { return false; }
    });
    const [expanded, setExpanded] = useState(0);
    const setDismissed = (dismissed: boolean) => {
        setHidden(dismissed);
        try { window.localStorage.setItem(STORAGE_KEY, dismissed ? VERSION : ""); }
        catch { /* The panel still works when storage is unavailable. */ }
    };

    if (hidden) {
        return <button type="button" onClick={() => setDismissed(false)} style={{
            position: "fixed", left: "clamp(12px, 1.5vw, 24px)", bottom: "60px", zIndex: 50,
            padding: "8px 14px", border: "1px solid rgba(255,79,168,.7)", borderRadius: "18px",
            background: "rgba(17,8,34,.95)", color: "#ffd6ef", fontSize: "14px", fontWeight: 800,
            cursor: "pointer", pointerEvents: "auto",
        }}>✦ What’s new in Lively Skylines {VERSION}</button>;
    }

    return <section role="dialog" aria-label={"Lively Skylines changelog " + VERSION} style={{
        ...panelPosition, zIndex: 50, display: "flex", flexDirection: "column", overflow: "hidden",
        border: "1px solid rgba(255,79,168,.55)", borderRadius: "10px",
        background: "linear-gradient(160deg,rgba(40,14,64,.97),rgba(14,10,32,.97))",
        boxShadow: "0 10px 30px rgba(0,0,0,.5)", color: "#f5edff", pointerEvents: "auto",
        fontFamily: "inherit",
    }}>
        <header style={{
            flex: "0 0 auto", display: "flex", alignItems: "center", justifyContent: "space-between",
            gap: "12px", padding: "12px 14px", borderBottom: "1px solid rgba(255,255,255,.1)",
        }}>
            <div style={{ minWidth: 0 }}>
                <div style={{ color: "#ff7ad1", fontSize: "11px", fontWeight: 900, letterSpacing: "2px" }}>LIVELY SKYLINES · CHANGELOG</div>
                <div style={{ marginTop: "2px", fontSize: "20px", lineHeight: 1.2, fontWeight: 900 }}>What’s new in {VERSION}</div>
                <div style={{ marginTop: "2px", color: "#b8a9d2", fontSize: "12px" }}>{DATE}</div>
            </div>
            <button type="button" aria-label="Close changelog" onClick={() => setDismissed(true)} style={{
                flex: "0 0 30px", width: "30px", height: "30px", border: "1px solid rgba(255,255,255,.25)",
                borderRadius: "8px", background: "rgba(255,255,255,.06)", color: "#fff",
                fontSize: "16px", fontWeight: 900, cursor: "pointer",
            }}>×</button>
        </header>
        <div style={{ flex: "1 1 auto", minHeight: 0, overflowY: "auto", padding: "8px 10px 12px", scrollbarWidth: "thin" }}>
            {changes.map((change, index) => <article key={change.title} style={{
                marginTop: "6px", borderRadius: "8px",
                background: expanded === index ? "rgba(255,255,255,.06)" : "rgba(255,255,255,.03)",
                border: "1px solid " + (expanded === index ? change.color : "rgba(255,255,255,.08)"),
                overflow: "hidden",
            }}>
                <button type="button" aria-expanded={expanded === index} onClick={() => setExpanded(expanded === index ? -1 : index)} style={{
                    width: "100%", minHeight: "40px", display: "flex", alignItems: "center", gap: "8px",
                    padding: "8px 10px", border: 0, background: "transparent", color: "inherit",
                    textAlign: "left", cursor: "pointer",
                }}>
                    <span style={{ flex: "0 0 auto", padding: "2px 7px", borderRadius: "5px", background: change.color, color: "#120a22", fontSize: "10px", fontWeight: 900 }}>{change.tag}</span>
                    <span style={{ flex: "1 1 auto", minWidth: 0, fontSize: "15px", lineHeight: 1.2, fontWeight: 800, overflowWrap: "anywhere" }}>{change.title}</span>
                    <span aria-hidden="true" style={{ flex: "0 0 auto", color: "#b8a9d2", fontSize: "13px" }}>{expanded === index ? "−" : "+"}</span>
                </button>
                {expanded === index && <ul style={{ margin: 0, padding: "0 12px 10px 30px", listStyle: "none" }}>
                    {change.items.map((item) => <li key={item} style={{ display: "flex", gap: "7px", marginTop: "5px" }}>
                        <span aria-hidden="true" style={{ flex: "0 0 auto", color: change.color, fontSize: "13px" }}>•</span>
                        <span style={{ minWidth: 0, color: "#e4dbf3", fontSize: "13px", lineHeight: 1.35, overflowWrap: "anywhere" }}>{item}</span>
                    </li>)}
                </ul>}
            </article>)}
        </div>
    </section>;
};
