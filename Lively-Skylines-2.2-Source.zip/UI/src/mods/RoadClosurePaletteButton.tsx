import React from "react";
import { bindValue, trigger, useValue } from "cs2/api";

const GROUP = "BarRush";
const roadUpgradeActive$ = bindValue<boolean>(GROUP, "roadUpgradeActive", false);
const roadClosuresEnabled$ = bindValue<boolean>(GROUP, "roadClosuresEnabled", true);
const shutDownRoadActive$ = bindValue<boolean>(GROUP, "shutDownRoadActive", false);

export const RoadClosurePaletteButton = () => {
    const roadPaletteOpen = useValue(roadUpgradeActive$);
    const enabled = useValue(roadClosuresEnabled$);
    const active = useValue(shutDownRoadActive$);
    if (!roadPaletteOpen || !enabled) return null;

    return <div style={{ position: "fixed", zIndex: 1100, left: "50%", bottom: "21vh", transform: "translateX(-50%)", display: "flex", alignItems: "center", gap: "8rem", padding: "8rem 10rem", borderRadius: "7rem", background: "rgba(25,37,48,.96)", border: "1rem solid rgba(255,255,255,.24)", boxShadow: "0 4rem 14rem rgba(0,0,0,.35)", pointerEvents: "auto" }}>
        <span style={{ color: "#fff", fontSize: "11rem", fontWeight: 700 }}>Road tools</span>
        <button type="button" title="Select a road segment to close or reopen it" onClick={() => trigger(GROUP, active ? "cancelShutDownRoad" : "activateShutDownRoad")} style={{ minWidth: "128rem", height: "42rem", border: "1rem solid rgba(255,255,255,.25)", borderRadius: "5rem", color: "#fff", fontSize: "11rem", fontWeight: 800, cursor: "pointer", background: active ? "#ad3941" : "#2876a9" }}>
            {active ? "Cancel closure" : "Shut Down Road"}
        </button>
    </div>;
};
