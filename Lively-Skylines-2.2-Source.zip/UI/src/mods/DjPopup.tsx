import React from "react";
import { bindValue, trigger, useValue } from "cs2/api";

const GROUP = "BarRush";
const visible$ = bindValue<boolean>(GROUP, "visible", false);
const djName$ = bindValue<string>(GROUP, "djName", "");
const barName$ = bindValue<string>(GROUP, "barName", "");
const attendees$ = bindValue<number>(GROUP, "attendees", 0);
const announcementKind$ = bindValue<string>(GROUP, "announcementKind", "DJ set");
const announcementMessage$ = bindValue<string>(GROUP, "announcementMessage", "");
const scandalCanResolve$ = bindValue<boolean>(GROUP, "scandalCanResolve", false);
const isScandal$ = bindValue<boolean>(GROUP, "announcementIsScandal", false);
const pursuitOverlayData$ = bindValue<string>(GROUP, "pursuitOverlayData", "");
const framesPerDay$ = bindValue<number>(GROUP, "cityCrimeFramesPerDay", 0);

const panel: React.CSSProperties = {
    position: "fixed",
    top: "78rem",
    right: "22rem",
    left: "auto",
    width: "350rem",
    maxWidth: "calc(100vw - 24rem)",
    boxSizing: "border-box",
    padding: "18rem 20rem 17rem",
    borderRadius: "9rem",
    border: "1rem solid rgba(255,255,255,.12)",
    borderTop: "3rem solid #e53b91",
    background: "linear-gradient(135deg, rgba(27,25,43,.97), rgba(14,20,34,.97))",
    boxShadow: "0 10rem 32rem rgba(0,0,0,.38)",
    color: "#f7f5fb",
    fontFamily: "inherit",
    pointerEvents: "auto",
};

export const DjPopup = () => {
    const visible = useValue(visible$);
    const djName = useValue(djName$);
    const barName = useValue(barName$);
    const attendees = useValue(attendees$);
    const announcementKind = useValue(announcementKind$);
    const announcementMessage = useValue(announcementMessage$);
    const scandalCanResolve = useValue(scandalCanResolve$);
    const isScandal = useValue(isScandal$);
    const pursuitOverlayData = useValue(pursuitOverlayData$);
    const framesPerDay = useValue(framesPerDay$);

    const pursuit = pursuitOverlayData.split("|");
    const pursuitActive = pursuit[0] === "active";
    const pursuitResult = pursuit[0] === "result";
    if (!visible && !pursuitActive && !pursuitResult) return null;

    const isTweet = announcementKind.toLowerCase().includes("tweet");
    const isAlert = isScandal || /crime|health|fine|protest|graffiti/i.test(announcementKind);
    const isCrimeReport = /crime/i.test(announcementKind);
    const crimeType = isCrimeReport ? announcementKind.split(/[·:]/).slice(1).join("·").trim() : "";
    const initials = (djName || "Lively Skylines").split(/\s+/).map((part) => part[0] || "").join("").slice(0, 2).toUpperCase();
    const tweetStats = announcementMessage.match(/\n(.+?) · ([\d,]+) likes · ([\d,]+) dislikes$/);
    const message = tweetStats ? announcementMessage.slice(0, tweetStats.index) : announcementMessage;
    const location = tweetStats?.[1] || barName;
    const accent = isAlert ? "#ff9b56" : isTweet ? "#43d7e6" : "#ff73b6";

    const formatClock = (seconds: number) => {
        const safe = Math.max(0, Math.floor(seconds));
        return `${String(Math.floor(safe / 60)).padStart(2, "0")}:${String(safe % 60).padStart(2, "0")}`;
    };
    const activeTotal = Math.max(1, Math.floor((framesPerDay || 28800) / 288));
    const pursuitRemaining = Math.max(0, Number(pursuit[3]) || 0);
    const pursuitElapsed = Math.max(0, Number(pursuit[4]) || 0);
    const pursuitClock = formatClock((pursuitRemaining / activeTotal) * 300);
    const pursuitProgress = Math.max(0, Math.min(100, (pursuitElapsed / (pursuitElapsed + pursuitRemaining || activeTotal)) * 100));
    const coverage = Math.max(0, Math.min(100, Number(pursuitActive ? pursuit[5] : pursuit[3]) || 0));
    const arrested = pursuit[4] === "1" && pursuitResult;

    const pursuitCard = (pursuitActive || pursuitResult) && <section
        role="status"
        aria-live="assertive"
        style={{
            position: "fixed", right: "22rem", bottom: "22rem", width: "360rem", maxWidth: "calc(100vw - 24rem)",
            boxSizing: "border-box", padding: "16rem 18rem", borderRadius: "9rem",
            border: `1rem solid ${pursuitResult ? (arrested ? "rgba(65,220,167,.55)" : "rgba(255,180,80,.55)") : "rgba(255,75,104,.58)"}`,
            borderTop: `3rem solid ${pursuitResult ? (arrested ? "#41dca7" : "#ffb450") : "#ff4b68"}`,
            background: "linear-gradient(135deg, rgba(30,20,38,.98), rgba(12,18,32,.98))",
            boxShadow: "0 10rem 32rem rgba(0,0,0,.46)", color: "#f7f5fb", pointerEvents: "none", fontFamily: "inherit",
        }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: "12rem", alignItems: "center" }}>
            <div style={{ color: pursuitResult ? (arrested ? "#55e4b2" : "#ffc16b") : "#ff7a8e", fontSize: "10rem", fontWeight: 900, letterSpacing: "1.2rem", textTransform: "uppercase" }}>
                {pursuitResult ? (arrested ? "Pursuit ended · arrested" : "Pursuit ended · escaped") : "Active police pursuit"}
            </div>
            {pursuitActive && <div style={{ color: "#fff", fontSize: "20rem", fontWeight: 900, fontVariantNumeric: "tabular-nums" }}>{pursuitClock}</div>}
        </div>
        <div style={{ marginTop: "9rem", fontSize: "17rem", lineHeight: 1.15, fontWeight: 850, color: "#fff" }}>{pursuit[1] || "Unidentified driver"}</div>
        <div style={{ marginTop: "4rem", color: "#b9b2c8", fontSize: "11rem" }}>{pursuit[2] || "City roads"} · {pursuitResult ? "Pursuit result" : "Five-minute game-time window"}</div>
        {pursuitActive && <>
            <div style={{ height: "6rem", marginTop: "13rem", borderRadius: "5rem", overflow: "hidden", background: "rgba(255,255,255,.12)" }}>
                <div style={{ height: "100%", width: `${pursuitProgress}%`, background: "linear-gradient(90deg,#ff4b68,#ffb450)", transition: "width .25s linear" }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", gap: "8rem", marginTop: "11rem" }}>
                <div><div style={{ color: "#938ca4", fontSize: "9rem", textTransform: "uppercase", letterSpacing: ".8rem" }}>Police coverage</div><div style={{ color: "#fff", marginTop: "3rem", fontWeight: 800, fontSize: "13rem" }}>{coverage}% · {pursuit[6] === "1" ? "station nearby" : "low · no local station"}</div></div>
                <div style={{ textAlign: "right" }}><div style={{ color: "#938ca4", fontSize: "9rem", textTransform: "uppercase", letterSpacing: ".8rem" }}>Roadside stop</div><div style={{ color: pursuit[9] === "1" || pursuit[8] === "1" ? "#55e4b2" : "#e6dff0", marginTop: "3rem", fontWeight: 800, fontSize: "13rem" }}>{pursuit[9] === "1" ? "Yielding" : pursuit[8] === "1" ? "Stopped briefly" : pursuit[7] === "1" ? "Possible" : "Not expected"}</div></div>
            </div>
        </>}
        {pursuitResult && <div style={{ marginTop: "12rem", padding: "9rem 10rem", borderRadius: "6rem", background: arrested ? "rgba(65,220,167,.12)" : "rgba(255,180,80,.12)", color: arrested ? "#9cf0d0" : "#ffdda3", fontSize: "11rem", lineHeight: 1.4 }}>
            {arrested ? `Modeled arrest after the pursuit. Police coverage: ${coverage}%.` : `The driver escaped after the five-minute window. Police coverage: ${coverage}%.`}
        </div>}
        <div style={{ marginTop: "11rem", paddingTop: "8rem", borderTop: "1rem solid rgba(255,255,255,.1)", color: "#898397", fontSize: "9rem" }}>City simulation outcome · native citizen criminal records are unchanged</div>
    </section>;

    return <>
        {pursuitCard}
        {visible && <section style={{ ...panel, top: "78rem", borderTopColor: accent }} role="status" aria-live="polite">
            {!scandalCanResolve && <button
                type="button"
                aria-label="Dismiss city update"
                onClick={() => trigger(GROUP, "dismiss")}
                style={{ position: "absolute", right: "12rem", top: "10rem", border: 0, background: "transparent", color: "#c4c2ce", fontSize: "20rem", cursor: "pointer" }}
            >×</button>}
            <div style={{ display: "flex", alignItems: "center", gap: "7rem", color: accent, fontSize: "10rem", fontWeight: 800, letterSpacing: "1.3rem", textTransform: "uppercase", paddingRight: "23rem" }}>
                <span style={{ width: "7rem", height: "7rem", flex: "0 0 7rem", borderRadius: "50%", background: accent, boxShadow: `0 0 9rem ${accent}` }} />
                {isAlert ? "City alert" : isTweet ? "Lively Skylines" : "City update"} <span style={{ color: "#858394" }}>·</span> {announcementKind}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "10rem", marginTop: "12rem" }}>
                <div aria-label={`${djName || "Lively Skylines"} profile image`} role="img" style={{ display: "flex", flex: "0 0 42rem", width: "42rem", height: "42rem", alignItems: "center", justifyContent: "center", border: `2rem solid ${accent}`, borderRadius: "50%", background: "linear-gradient(145deg,#f4dcff,#b7e9ef)", color: "#26243a", fontSize: "13rem", fontWeight: 900 }}>{initials}</div>
                <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: "18rem", lineHeight: 1.15, fontWeight: 800, color: "#fff" }}>{djName || "Lively Skylines"}</div>
                    <div style={{ marginTop: "4rem", color: "#aaa6b8", fontSize: "10rem" }}>{isTweet ? "City resident · creator" : announcementKind} <span style={{ color: "#777486" }}>· just now</span></div>
                </div>
            </div>
            <div style={{ display: "flex", gap: "8rem", alignItems: "center", marginTop: "12rem", padding: "8rem", border: "1rem solid rgba(255,255,255,.09)", borderRadius: "7rem", background: "linear-gradient(120deg,rgba(83,58,118,.68),rgba(23,31,49,.84))" }}>
                <svg viewBox="0 0 150 62" role="img" aria-label={isAlert ? "Illustration of a city alert" : "Illustration of a local city scene"} style={{ width: "104rem", height: "54rem", flex: "0 0 104rem", borderRadius: "5rem", background: isAlert ? "#31213d" : "#172b3d" }}>
                    <rect width="150" height="62" fill={isAlert ? "#352740" : "#192e40"} />
                    <circle cx="123" cy="14" r="9" fill={isAlert ? "#ff9b56" : "#ffd27a"} opacity=".9" />
                    <path d="M0 45 20 30 34 39 53 20 71 39 91 24 111 41 130 28 150 43v19H0z" fill="#65738a" opacity=".48" />
                    <path d="M7 39h30v23H7zM43 32h26v30H43zM77 42h31v20H77zM116 36h27v26h-27z" fill={isAlert ? "#596579" : "#53677a"} />
                    <path d="M12 45h7v7h-7zM25 45h7v7h-7zM49 40h7v8h-7zM59 40h7v8h-7zM84 49h8v7h-8zM123 43h7v8h-7zM133 43h7v8h-7z" fill="#ffdf9c" />
                    {isAlert ? <g><path d="m99 12 9 16H90z" fill="#ffb85c"/><path d="M99 17v5m0 3v1" stroke="#35213c" strokeWidth="2" strokeLinecap="round"/></g> : <path d="M101 12v19m-7-9 7-4 8 4m-8-4 8-5" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" />}
                    <path d="M0 56h150v6H0z" fill="#101a29" opacity=".66" />
                </svg>
                <div style={{ minWidth: 0, flex: "1 1 auto" }}>
                    <div style={{ color: "#aaa6b8", fontSize: "9rem", textTransform: "uppercase", letterSpacing: ".8rem" }}>{isTweet ? "From the city feed" : isCrimeReport ? `Crime report${crimeType ? ` · ${crimeType}` : ""}` : isAlert ? "Community notice" : "Happening in your city"}</div>
                    <div style={{ marginTop: "4rem", color: "#fff", fontSize: "12rem", fontWeight: 750, overflowWrap: "anywhere" }}>{location || barName || "Citywide"}</div>
                </div>
            </div>
            {isCrimeReport && <div style={{ display: "inline-flex", alignSelf: "flex-start", marginTop: "10rem", padding: "6rem 10rem", border: "1rem solid rgba(255,120,111,.55)", borderRadius: "8rem", background: "rgba(183,55,62,.24)", color: "#ffcbc5", fontSize: "11rem", fontWeight: 900, letterSpacing: ".5rem", textTransform: "uppercase" }}>⚠ REPORTED OFFENSE: {crimeType || djName || "Crime reported"}</div>}
            <div style={{ marginTop: "11rem", color: "#e2deea", fontSize: "12rem", lineHeight: 1.45, whiteSpace: "pre-line", overflowWrap: "anywhere" }}>
                {isCrimeReport ? <><strong style={{ color: "#ffcbc5" }}>What happened: {crimeType || djName || "Crime reported"}.</strong>{message && <><br />{message}</>}</> : message || <>Playing at <strong style={{ color: "#fff" }}>{barName}</strong></>}
            </div>
            {(tweetStats || attendees > 0) && <div style={{ display: "flex", flexWrap: "wrap", gap: "7rem", marginTop: "11rem" }}>
                {tweetStats ? <>
                    <span style={{ padding: "5rem 8rem", borderRadius: "12rem", background: "rgba(67,215,230,.12)", color: "#8beaf3", fontSize: "10rem", fontWeight: 750 }}>♡ {tweetStats[2]} likes</span>
                    <span style={{ padding: "5rem 8rem", borderRadius: "12rem", background: "rgba(255,115,182,.11)", color: "#ffa7cf", fontSize: "10rem", fontWeight: 750 }}>↘ {tweetStats[3]} dislikes</span>
                </> : <span style={{ padding: "5rem 8rem", borderRadius: "12rem", background: "rgba(255,115,182,.11)", color: "#ff9bca", fontSize: "10rem", fontWeight: 750 }}>♟ {attendees.toLocaleString()} sims expected</span>}
            </div>}
            {scandalCanResolve && <div style={{ display: "flex", gap: "8rem", marginTop: "14rem" }}>
                <button type="button" onClick={() => trigger(GROUP, "closeScandalVenue")} style={{ flex: 1, minHeight: "36rem", border: "1rem solid rgba(255,255,255,.16)", borderRadius: "6rem", background: "#8b3e38", color: "#fff", fontSize: "11rem", fontWeight: 700, cursor: "pointer" }}>Close venue · $75,000</button>
                <button type="button" onClick={() => trigger(GROUP, "coverUpScandal")} style={{ flex: 1, minHeight: "36rem", border: "1rem solid rgba(255,255,255,.16)", borderRadius: "6rem", background: "#57447d", color: "#fff", fontSize: "11rem", fontWeight: 700, cursor: "pointer" }}>Cover up · $150,000</button>
            </div>}
            <div style={{ display: "flex", justifyContent: "space-between", gap: "8rem", marginTop: "12rem", paddingTop: "9rem", borderTop: "1rem solid rgba(255,255,255,.1)", color: "#858394", fontSize: "9rem" }}><span>{isAlert ? "City incident update" : isTweet ? "Local social post" : "Lively Skylines update"}</span><span>{scandalCanResolve ? "Choose an action above" : "Auto-dismisses shortly"}</span></div>
        </section>}
    </>;
};
