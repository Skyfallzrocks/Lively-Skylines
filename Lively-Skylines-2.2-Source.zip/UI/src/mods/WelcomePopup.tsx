import React, { useState } from "react";

const starts = [4, 11, 18, 26, 33, 41, 48, 56, 64, 72, 81, 89, 96];
const stars = Array.from({ length: 46 }, (_, i) => ({
    x: (i * 71 + 13) % 100,
    y: (i * 47 + 5) % 72,
    delay: `${(i % 9) * -0.43}s`,
    color: i % 4 === 0 ? "#ff54dc" : i % 3 === 0 ? "#46f5ff" : "#fff2ab",
}));
const v2Features = [
    { icon: "♫", title: "Nightlife, venues & events", color: "#ff62bd", text: "Bar and venue operations, casino upgrades, DJ nights, and park event planning with schedules, budgets, attendance, safety, and neighborhood impact." },
    { icon: "⌂", title: "Homeless programs", color: "#62e6bd", text: "Designate shelters, warming centers, and permitted outdoor zones; manage winter response, outreach teams, harm reduction, capacity, and service maps." },
    { icon: "!", title: "Crime, police & pursuits", color: "#ff7489", text: "Crime reports, police operations, criminal records, and active pursuits with coverage-based outcomes. Pursuit updates also feed city news." },
    { icon: "▣", title: "City news & reputation", color: "#ff64bc", text: "Breaking reports, resident social posts, mapped stories, and city reputation changes tied to safety, trust, police, business, nightlife, and housing." },
    { icon: "⚖", title: "Laws, council & elections", color: "#b992ff", text: "Enact modeled ordinances with benefits and tradeoffs, follow council activity, and run yearly elections with resident party preferences and rallies." },
    { icon: "$", title: "Banking & business rescue", color: "#ffc85d", text: "Explore modeled bank reserves, loans, credit ratings, distressed-business support, and rescue outcomes linked to city activity." },
    { icon: "⌂", title: "Home Market", color: "#71aaff", text: "Browse residential properties listed for sale, search and filter by home or district, save listings, sort estimates, and locate homes on the city map." },
    { icon: "◉", title: "CCTV & ALPR", color: "#5adcf0", text: "Place fixed and mobile cameras, review coverage and reads, and connect modeled camera intelligence with police and crime dashboards." },
    { icon: "⌖", title: "City maps & bike share", color: "#54dec1", text: "Explore rendered city roads, buildings, and places; use Civic and Dispatch maps for services and incidents, plus a modeled bike-share network." },
    { icon: "⚙", title: "More controls & polish", color: "#c39aff", text: "Tune enabled features in Settings, use the quick menu to jump between dashboards, and find improved sizing, navigation, and map controls." },
];

export const WelcomePopup = () => {
    const [visible, setVisible] = useState(true);
    const [selectedIndex, setSelectedIndex] = useState(0);
    if (!visible) return null;
    const feature = v2Features[selectedIndex];
    const dismiss = () => setVisible(false);
    const selectPrevious = () => setSelectedIndex((index) => (index + v2Features.length - 1) % v2Features.length);
    const selectNext = () => setSelectedIndex((index) => (index + 1) % v2Features.length);

    return <main style={{ position: "fixed", zIndex: 99999, top: 0, right: 0, bottom: 0, left: 0, width: "100vw", height: "100vh", overflow: "hidden", color: "#fff4fb", background: "#110822", fontFamily: "'Segoe UI',sans-serif", pointerEvents: "auto" }}>
        <style>{`
            @keyframes lsTwinkle { 0%,100%{opacity:.25;transform:scale(.65)} 50%{opacity:1;transform:scale(1.2)} }
            @keyframes lsBeam { 0%,100%{opacity:.5} 50%{opacity:1} }
            @keyframes lsGlow { 0%,100%{filter:drop-shadow(0 0 5px currentColor)} 50%{filter:drop-shadow(0 0 14px currentColor)} }
            @keyframes lsFloat { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
            .ls-star{animation:lsTwinkle 2.2s ease-in-out infinite}
            .ls-sign{animation:lsGlow 2.4s ease-in-out infinite}
            .ls-float{animation:lsFloat 3.8s ease-in-out infinite}
            .ls-window{animation:lsTwinkle 2.7s ease-in-out infinite alternate}
            .ls-continue:hover,.ls-close:hover{filter:brightness(1.18)}
            @media(max-width:700px){.ls-hero{left:5%!important;top:5%!important}.ls-title{font-size:54px!important}.ls-feature-panel{left:4%!important;right:4%!important;bottom:5%!important;width:92%!important;height:48vh!important}.ls-feature-rail{width:35%!important}.ls-feature-detail{padding:12px!important}.ls-feature-copy{font-size:13px!important}.ls-moon{right:5%!important;width:78px!important;height:78px!important}}
            @media(max-height:600px){.ls-feature-panel{height:44vh!important;bottom:3%!important}.ls-city{height:48%!important}.ls-title{font-size:50px!important}}
        `}</style>
        <div style={{ position: "absolute", top: 0, right: 0, bottom: 0, left: 0, background: "radial-gradient(ellipse at 48% 75%,rgba(204,35,142,.24),transparent 44%),radial-gradient(ellipse at 14% 19%,rgba(89,36,149,.46),transparent 36%),linear-gradient(180deg,#110820 0%,#210d39 57%,#120923 100%)" }} />
        {stars.map((s, i) => <i key={i} className="ls-star" style={{ position: "absolute", left: `${s.x}%`, top: `${s.y}%`, width: i % 11 === 0 ? 4 : 2, height: i % 11 === 0 ? 4 : 2, borderRadius: "50%", background: s.color, boxShadow: `0 0 8px ${s.color}`, animationDelay: s.delay }} />)}
        <svg aria-hidden="true" viewBox="0 0 1440 810" preserveAspectRatio="none" style={{ position: "absolute", top: 0, right: 0, bottom: 0, left: 0, width: "100%", height: "100%", pointerEvents: "none" }}>
            <defs><linearGradient id="lsPinkBeam" x1="0" x2="1"><stop stopColor="#ff3ebd" stopOpacity=".05"/><stop offset=".52" stopColor="#ff49c8" stopOpacity=".86"/><stop offset="1" stopColor="#ff3ebd" stopOpacity=".05"/></linearGradient><linearGradient id="lsBlueBeam" x1="0" x2="1"><stop stopColor="#42f5ff" stopOpacity=".04"/><stop offset=".5" stopColor="#42f5ff" stopOpacity=".8"/><stop offset="1" stopColor="#42f5ff" stopOpacity=".03"/></linearGradient><linearGradient id="lsFloor" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#ed3da9" stopOpacity=".13"/><stop offset="1" stopColor="#211337" stopOpacity="0"/></linearGradient></defs>
            <g style={{ transformOrigin: "50% 42%", animation: "lsBeam 4s ease-in-out infinite" }}><path d="M420 312L150 0h85z" fill="url(#lsBlueBeam)"/><path d="M420 312L455 0h75z" fill="url(#lsPinkBeam)"/><path d="M420 312L700 0h74z" fill="url(#lsBlueBeam)"/><path d="M420 312L0 115l22-8z" fill="url(#lsPinkBeam)"/><path d="M420 312L1070 0h30z" fill="url(#lsBlueBeam)"/><path d="M420 312L0 315v-10z" fill="url(#lsPinkBeam)"/></g>
            <path d="M0 602H1440V810H0Z" fill="url(#lsFloor)"/><path d="M0 602H1440" stroke="#ff71dd" strokeOpacity=".7" strokeWidth="2"/><path d="M0 611H1440" stroke="#52f5ff" strokeOpacity=".18"/>
        </svg>

        <div className="ls-hero" style={{ position: "absolute", zIndex: 3, left: "5.2%", top: "6.5%", width: "43vw", maxWidth: 580 }}>
            <div style={{ color: "#d8d3e8", fontSize: 12, letterSpacing: ".38em", marginLeft: 5, textShadow: "0 0 12px #d46aff" }}>CITIES: SKYLINES II</div>
            <div className="ls-title" style={{ marginTop: 9, fontSize: 82, fontWeight: 1000, letterSpacing: "-.055em", lineHeight: ".9", color: "#ff65ac", textShadow: "0 0 21px rgba(255,45,174,.55)" }}>LIVELY<br/>SKYLINES</div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "16px 0 0 7px", color: "#fff0ff", fontSize: 11, fontWeight: 800, letterSpacing: ".38em", textShadow: "0 0 9px #f87dda" }}>THE NIGHTLIFE MOD <span style={{ padding: "4px 8px", border: "1px solid rgba(255,112,210,.72)", borderRadius: 12, color: "#ffd780", background: "rgba(38,12,49,.65)", fontSize: 10, letterSpacing: ".12em" }}>VERSION 2</span></div>
        </div>
        <div aria-hidden="true" className="ls-float" style={{ position: "absolute", zIndex: 2, top: "12%", left: "66%", width: 60, height: 60, borderRadius: "50%", background: "radial-gradient(circle at 35% 30%,#fff7ff 0 5%,#7dfbff 8%,#ff8cf0 21%,#7868d5 45%,#170d31 72%)", boxShadow: "0 0 20px #fc66ff", overflow: "hidden" }}><span style={{ position: "absolute", top: "-10%", right: "30%", bottom: "-10%", left: "30%", borderLeft: "1px solid rgba(255,255,255,.8)", borderRight: "1px solid rgba(255,255,255,.8)", transform: "perspective(20px) rotateY(25deg)" }}/><span style={{ position: "absolute", left: "-10%", right: "-10%", top: "48%", borderTop: "1px solid rgba(255,255,255,.78)" }}/></div>
        <div className="ls-moon ls-float" style={{ position: "absolute", zIndex: 2, top: "8%", right: "13.4%", width: 128, height: 128, borderRadius: "50%", background: "#ffe9d5", boxShadow: "0 0 34px rgba(255,196,220,.4),0 0 90px rgba(255,111,215,.2)" }}><i style={{ position: "absolute", left: "24%", top: "27%", width: "20%", height: "20%", borderRadius: "50%", background: "#edcabc" }}/><i style={{ position: "absolute", left: "54%", top: "32%", width: "15%", height: "15%", borderRadius: "50%", background: "#edcabc" }}/><i style={{ position: "absolute", left: "37%", top: "59%", width: "14%", height: "14%", borderRadius: "50%", background: "#edcabc" }}/></div>
        <div className="ls-city" style={{ position: "absolute", zIndex: 2, left: 0, right: 0, bottom: 0, height: "61%", display: "flex", alignItems: "flex-end", justifyContent: "space-between", pointerEvents: "none" }}>
            {starts.map((left, i) => {
                const width = 8 + (i % 4) * 3.4;
                const height = 23 + ((i * 17) % 43);
                const sign = i === 3 ? "DJ" : i === 6 ? "♪" : i === 8 ? "LIVE" : i === 11 ? "BAR" : "";
                const color = i === 3 ? "#ff50ce" : i === 8 ? "#45f6ff" : "#ff59ce";
                return <div key={i} style={{ position: "relative", flex: `0 0 ${width}%`, height: `${height}%`, minWidth: 30, background: "linear-gradient(90deg,#170d2b,#24123d 52%,#130b25)", border: "1px solid rgba(116,62,151,.38)", borderBottom: "2px solid rgba(255,75,202,.32)", boxShadow: "inset 0 0 24px rgba(3,5,23,.75)" }}>
                    <div style={{ position: "absolute", top: "8%", right: "8%", bottom: "6%", left: "8%", display: "flex", flexWrap: "wrap", justifyContent: "space-between", gap: 3 }}>{Array.from({ length: 28 }, (_, w) => <i key={w} className="ls-window" style={{ opacity: (w * 3 + i) % 7 === 0 ? .15 : .95, animationDelay: `${((w + i) % 8) * -0.31}s`, background: (w + i) % 5 === 0 ? "#4df7ff" : (w + i) % 3 === 0 ? "#ff50cb" : "#ffd668", boxShadow: "0 0 6px currentColor" }}/>)}</div>
                    {sign && <div className="ls-sign" style={{ position: "absolute", zIndex: 2, top: i === 11 ? "3%" : "18%", left: "50%", transform: "translateX(-50%)", padding: "3px 8px", border: `2px solid ${color}`, borderRadius: 5, color, background: "rgba(15,7,28,.88)", fontSize: 24, lineHeight: 1.05, fontWeight: 1000, letterSpacing: ".06em", textShadow: `0 0 6px ${color},0 0 16px ${color}`, boxShadow: `0 0 14px ${color}88`, whiteSpace: "nowrap" }}>{sign}</div>}
                </div>;
            })}
            <div style={{ position: "absolute", bottom: "18%", left: "57%", transform: "translateX(-50%)", width: "21%", minWidth: 155, height: "19%", background: "linear-gradient(180deg,#ff55ad,#ffbe59 60%,#ffda83)", border: "5px solid #ff65b3", boxShadow: "0 0 26px #ff55ad88,0 32px 75px #ffbc5866", display: "flex", flexDirection: "column", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ position: "absolute", top: "-17%", left: -5, right: -5, height: "20%", background: "repeating-linear-gradient(90deg,#ff528d 0 12px,#fff1ca 12px 24px)", border: "1px solid #ffb1da" }}/><b style={{ position: "relative", top: "-31%", color: "#ffe887", fontSize: 11, textShadow: "0 0 8px #ff8b35" }}>OPEN LATE</b><div style={{ display: "flex", width: "88%", height: "62%", justifyContent: "space-between" }}>{[0,1,2,3,4].map(x=><i key={x} style={{ width: "16%", background: "linear-gradient(90deg,#ffb444,#fff0a5,#ffbc55)", boxShadow: "0 0 9px #ffe176" }}/>)}</div>
            </div>
            <div style={{ position: "absolute", bottom: "18%", left: 0, right: 0, height: "19%", background: "linear-gradient(180deg,rgba(255,66,186,.19),rgba(55,27,78,0))", transform: "perspective(100px) rotateX(18deg)", transformOrigin: "top" }}/>
            {Array.from({ length: 20 }, (_, i) => <i key={`person-${i}`} style={{ position: "absolute", zIndex: 4, bottom: `${12 + (i % 3) * 2}%`, left: `${5 + i * 4.6}%`, width: 8, height: 25, borderRadius: "45% 45% 15% 15%", background: i % 5 === 0 ? "#050510" : "#090713", boxShadow: "0 -5px 0 -1px #080713" }} />)}
        </div>

        <section className="ls-feature-panel" style={{ position: "absolute", zIndex: 8, left: "5%", bottom: "4%", width: "88%", maxWidth: 1180, height: "39vh", minHeight: 310, maxHeight: 480, display: "flex", boxSizing: "border-box", padding: 12, border: "1px solid rgba(255,119,217,.72)", borderRadius: 16, background: "linear-gradient(115deg,rgba(18,9,34,.98),rgba(17,14,43,.98))", boxShadow: "0 0 30px rgba(255,61,190,.2),inset 0 0 25px rgba(67,50,113,.22)" }}>
            <nav className="ls-feature-rail" aria-label="Version 2 features" style={{ display: "flex", flexDirection: "column", flex: "0 0 30%", minWidth: 175, gap: 4, paddingRight: 10, overflowY: "auto", borderRight: "1px solid rgba(255,255,255,.12)" }}>
                <div style={{ padding: "3px 4px 7px", color: "#ff75c4", fontSize: 10, fontWeight: 900, letterSpacing: ".16em" }}>V2 FEATURES · {selectedIndex + 1}/{v2Features.length}</div>
                {v2Features.map((item, index) => <button key={item.title} type="button" aria-current={selectedIndex === index ? "step" : undefined} onClick={() => setSelectedIndex(index)} style={{ display: "flex", alignItems: "center", width: "100%", minHeight: 29, gap: 7, padding: "4px 7px", textAlign: "left", border: `1px solid ${selectedIndex === index ? `${item.color}aa` : "rgba(255,255,255,.1)"}`, borderLeft: `3px solid ${selectedIndex === index ? item.color : "rgba(255,255,255,.13)"}`, borderRadius: 6, background: selectedIndex === index ? `${item.color}19` : "rgba(10,9,27,.54)", color: selectedIndex === index ? "#fff" : "#c9c1d5", cursor: "pointer" }}><span style={{ flex: "0 0 18px", color: item.color, fontSize: 14, fontWeight: 900, textAlign: "center" }}>{item.icon}</span><span style={{ fontSize: 11, lineHeight: 1.2 }}>{item.title}</span></button>)}
            </nav>
            <div className="ls-feature-detail" style={{ display: "flex", flex: "1 1 auto", minWidth: 0, flexDirection: "column", padding: "12px 17px 8px" }}>
                <div style={{ color: "#ff70c3", fontSize: 10, fontWeight: 900, letterSpacing: ".22em" }}>THE NIGHTLIFE MOD · VERSION 2 · WHAT’S NEW</div>
                <div style={{ marginTop: 6, color: "#fff5fc", fontSize: 27, fontWeight: 950, textShadow: "0 0 14px rgba(255,72,184,.4)" }}>Welcome to V2</div>
                <div style={{ marginTop: 2, color: "#aaa0ba", fontSize: 11 }}>Click each feature to see what’s new.</div>
                <article key={feature.title} style={{ display: "flex", flex: "1 1 auto", alignItems: "center", gap: 15, minHeight: 100, marginTop: 12, padding: "16px", border: `1px solid ${feature.color}70`, borderLeft: `4px solid ${feature.color}`, borderRadius: 10, background: "rgba(10,9,27,.84)" }}>
                    <span style={{ display: "flex", flex: "0 0 58px", width: 58, height: 58, alignItems: "center", justifyContent: "center", borderRadius: 14, color: feature.color, background: `${feature.color}20`, fontSize: 34, fontWeight: 900 }}>{feature.icon}</span>
                    <div style={{ minWidth: 0 }}><div style={{ color: feature.color, fontSize: 19, fontWeight: 900 }}>{feature.title}</div><p className="ls-feature-copy" style={{ margin: "8px 0 0", color: "#ded6e9", fontSize: 15, lineHeight: 1.5 }}>{feature.text}</p></div>
                </article>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginTop: 10 }}>
                    <span style={{ color: "#8f879e", fontSize: 9 }}>Some outcomes are modeled by the mod; the native city simulation remains in control.</span>
                    <div style={{ display: "flex", flex: "0 0 auto", alignItems: "center", gap: 6 }}><button type="button" onClick={selectPrevious} style={{ minHeight: 31, padding: "0 10px", border: "1px solid #514064", borderRadius: 7, color: "#eee3fa", background: "#231637", cursor: "pointer" }}>← Previous</button><button type="button" onClick={selectNext} style={{ minHeight: 31, padding: "0 11px", border: "1px solid #ff92db", borderRadius: 7, color: "#fff", background: "linear-gradient(100deg,#ef39a8,#8d47fb)", cursor: "pointer", fontWeight: 900 }}>Next →</button><button type="button" className="ls-continue" onClick={dismiss} style={{ minHeight: 31, padding: "0 12px", border: "1px solid #64dfbe", borderRadius: 7, color: "#071b18", background: "#64dfbe", cursor: "pointer", fontWeight: 900 }}>Continue</button></div>
                </div>
            </div>
        </section>
        <button type="button" className="ls-close" onClick={dismiss} aria-label="Close welcome screen" style={{ position: "absolute", zIndex: 10, top: 12, right: 16, width: 36, height: 36, border: "1px solid rgba(255,255,255,.32)", borderRadius: 9, color: "#fff", background: "rgba(18,9,34,.72)", cursor: "pointer", fontSize: 23 }}>×</button>
        <div style={{ position: "absolute", zIndex: 8, right: 16, bottom: 12, color: "rgba(242,215,251,.64)", fontSize: 9, textShadow: "0 1px 4px #110822" }}>Lively Skylines · V2</div>
    </main>;
};
