import { ModRegistrar } from "cs2/modding";
import { DjPopup } from "mods/DjPopup";
import { BarDashboard } from "mods/BarDashboard";
import { WelcomePopup } from "mods/WelcomePopup";
import { ChangelogPopup } from "mods/ChangelogPopup";

const register: ModRegistrar = (moduleRegistry) => {
    // GameTopLeft is the verified runtime HUD anchor used by established CS2 UI mods.
    moduleRegistry.append("GameTopLeft", BarDashboard);
    moduleRegistry.append("GameTopLeft", DjPopup);
    // Show the usage guide on the main menu as requested.
    moduleRegistry.append("Menu", WelcomePopup);
    moduleRegistry.append("Menu", ChangelogPopup);
};

export default register;

