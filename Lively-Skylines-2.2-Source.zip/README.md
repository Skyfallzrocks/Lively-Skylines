# Lively Skylines 2.2 source

This archive contains the C# gameplay and UI integration sources, the TypeScript/React user interface, and the UI build configuration for Lively Skylines.

## Contents

- Code/ — C# mod systems and game integration
- UI/src/ — TypeScript/React UI source, including the responsive changelog panel
- UI/types/, UI/tools/, and the npm lockfile — UI build support
- BarRush.csproj — Cities: Skylines II mod project
- Properties/Thumbnail.png — listing thumbnail

## Build requirements

Use Windows with the official Cities: Skylines II modding toolchain installed. The game SDK references are supplied by that toolchain and are intentionally not bundled here.

Build the C# project with the toolchain environment configured:

dotnet msbuild BarRush.csproj /t:Build /p:Configuration=Release

Build the UI from UI/ after installing Node.js:

npm ci

Set CSII_USERDATAPATH to a writable output directory, then run:

npm run build

The UI build writes Mods/BarRush/BarRush.mjs and its image assets under that output directory.

This archive excludes local build outputs, editor state, Git history, installed dependencies, logs, credentials, and backup bundles.
