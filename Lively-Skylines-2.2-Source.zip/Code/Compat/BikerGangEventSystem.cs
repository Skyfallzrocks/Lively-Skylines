using System.Collections.Generic;
using System;
using Game;
using Game.Areas;
using Game.Buildings;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Creates occasional Lively Skylines biker meetup stories at city venues.</summary>
    public partial class BikerGangEventSystem : GameSystemBase
    {
        private const float kMeetupTime = 20f / 24f;
        private const uint kMeetupDuration = OutingStarter.FramesPerDay / 12u;
        private static readonly string[] s_GangNames =
        {
            "Iron Vultures", "Chrome Wolves", "Midnight Pistons", "Blacktop Riders",
            "Copper Skulls", "Night Owls MC", "Road Hounds", "Ashland Riders",
        };

        private EntityQuery m_BuildingQuery;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private float m_PreviousTime = -1f;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_BuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Building>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CandidateQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.BikerGangEventsEnabled) return;
            float now = m_TimeSystem.normalizedTime;
            bool reachedMeetupTime = m_PreviousTime >= 0f && m_PreviousTime < kMeetupTime && now >= kMeetupTime;
            m_PreviousTime = now;
            if (reachedMeetupTime) TryStartMeetup(settings);
        }

        private void TryStartMeetup(Setting settings)
        {
            uint frame = m_SimulationSystem.frameIndex;
            var random = new Unity.Mathematics.Random(math.max(1u, frame * 1597334677u + 3812015801u));
            BikerRoster.EnsureInitialGroups();
            using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
            if (buildings.Length == 0) return;

            var named = new List<Entity>(buildings.Length);
            var uncovered = new List<Entity>();
            foreach (Entity building in buildings)
            {
                if (string.IsNullOrWhiteSpace(m_NameSystem.GetRenderedLabelName(building))) continue;
                named.Add(building);
                if (!EntityManager.HasComponent<CurrentDistrict>(building)) continue;
                Entity district = EntityManager.GetComponentData<CurrentDistrict>(building).m_District;
                if (district != Entity.Null && !CrimeAreaSystem.HasPoliceStation(district)) uncovered.Add(building);
            }
            if (named.Count == 0) return;

            float recentRate = CityCrimeLedger.WeeklyPerThousand(frame);
            int chance = math.clamp(settings.BikerGangChancePercent + math.min(10, (int)(recentRate * 2f)) + (uncovered.Count > 0 ? 4 : 0), 1, 35);
            if (random.NextInt(100) >= chance) return;

            BikerRoster.Group group = BikerRoster.Get(random.NextInt(BikerRoster.Count));
            Entity location = group != null && group.Home != Entity.Null && EntityManager.Exists(group.Home)
                ? group.Home
                : uncovered.Count > 0 && random.NextInt(100) < 65 ? uncovered[random.NextInt(uncovered.Count)] : named[random.NextInt(named.Count)];
            string venue = m_NameSystem.GetRenderedLabelName(location);
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
            string gang = group != null ? group.Name : s_GangNames[0];
            var localResidents = new List<Entity>();
            using (NativeArray<Entity> candidateResidents = m_CandidateQuery.ToEntityArray(Allocator.Temp))
            {
                Entity targetDistrict = EntityManager.HasComponent<CurrentDistrict>(location)
                    ? EntityManager.GetComponentData<CurrentDistrict>(location).m_District : Entity.Null;
                foreach (Entity resident in candidateResidents)
                {
                    Entity home = EntityManager.GetComponentData<CurrentBuilding>(resident).m_CurrentBuilding;
                    if (home == Entity.Null || !EntityManager.Exists(home) || !EntityManager.HasComponent<CurrentDistrict>(home)) continue;
                    if (targetDistrict != Entity.Null && EntityManager.GetComponentData<CurrentDistrict>(home).m_District == targetDistrict)
                        localResidents.Add(resident);
                }
            }
            List<Entity> existingRiders = BikerRoster.GetActiveRiders(group, EntityManager);
            bool newlyFormed = existingRiders.Count == 0 && group != null;
            if (newlyFormed && localResidents.Count > 0)
            {
                BikerRoster.SetRiders(group, localResidents, area, location, frame);
                existingRiders = BikerRoster.GetActiveRiders(group, EntityManager);
            }
            int bikesReported = random.NextInt(3, 9);

            int population = m_PopulationQuery.CalculateEntityCount();
            int cityCap = PopulationCap.MaxAttendees(population, settings.MaxAttendancePercent);
            int remaining = AttendanceLedger.Remaining(cityCap, frame);
            int requested = math.min(remaining, math.min(existingRiders.Count, Math.Max(0, localResidents.Count)));
            int attendees = 0;
            if (requested > 0)
            {
                using NativeArray<Entity> residents = new NativeArray<Entity>(existingRiders.ToArray(), Allocator.Temp);
                attendees = OutingStarter.Start(EntityManager, residents, requested, ref random, frame,
                    kMeetupDuration, location);
                AttendanceLedger.Add(attendees, frame + kMeetupDuration);
            }

            string place = $"{venue} · {area}";
            string message = $"🏍 {gang} riding group spotted around {area}: {bikesReported} bikes and {attendees:N0} local residents on the ride near {venue}.";
            BikerGangMeetupLedger.Add(gang, venue, area, bikesReported, attendees, frame, frame + kMeetupDuration, location);
            CityBuzzFeed.Add("Biker gang", gang, place, message, frame);
            DjAnnouncement.EnqueueBikerGang(gang, place, attendees, bikesReported);
            ActiveEvents.Add($"{gang} meetup", place, attendees, frame + kMeetupDuration, location);
            Mod.log.Info($"Lively Skylines biker meetup report: {gang} at {place}, {bikesReported} motorbikes reported and {attendees} residents heading there.");
        }
    }
}
