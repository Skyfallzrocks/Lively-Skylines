using System.Collections.Generic;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Fictional per-resident market-harm and recovery state for this city session.</summary>
    public static class SubstanceRecoveryLedger
    {
        public sealed class Resident
        {
            public Entity Citizen;
            public float Dependence;
            public int ModeledFunds;
            public int ExposureCount;
            public int RecoverySessions;
            public bool HomelessAtLastExposure;
            public uint LastExposureFrame;
        }

        public sealed class Center
        {
            public Entity Building;
            public string Name;
            public string District;
            public int Capacity = 8;
            public int Visits;
            public int ResidentsHelped;
        }

        private static readonly Dictionary<Entity, Resident> s_Residents = new Dictionary<Entity, Resident>();
        private static readonly List<Center> s_Centers = new List<Center>();
        public static IEnumerable<Resident> Residents => s_Residents.Values;
        public static IReadOnlyList<Center> Centers => s_Centers;
        public static int DependentCount { get { int count = 0; foreach (Resident r in s_Residents.Values) if (r.Dependence >= 45f) count++; return count; } }
        public static int ResidentsCount => s_Residents.Count;
        public static int DepletedCount { get { int count = 0; foreach (Resident r in s_Residents.Values) if (r.ModeledFunds <= 0 && r.ExposureCount > 0) count++; return count; } }
        public static int TotalSessions { get; private set; }
        public static string Status { get; set; } = "Select an existing city building to establish a recovery center.";

        public static Resident Get(Entity citizen) => s_Residents.TryGetValue(citizen, out Resident resident) ? resident : null;

        public static bool RecordMarketExposure(Entity citizen, bool homeless, int supplyPressure, uint frame, ref Random random)
        {
            if (citizen == Entity.Null) return false;
            if (!s_Residents.TryGetValue(citizen, out Resident resident))
                s_Residents[citizen] = resident = new Resident { Citizen = citizen, ModeledFunds = random.NextInt(250, 901) };
            resident.HomelessAtLastExposure = homeless;
            resident.LastExposureFrame = frame;
            int chance = math.clamp(5 + supplyPressure / 5 + (int)(resident.Dependence * .28f) + (homeless ? 22 : 0), 5, 82);
            if (random.NextInt(100) >= chance) return false;
            resident.ExposureCount++;
            int spend = 45 + random.NextInt(100) + (int)(resident.Dependence * 2.2f);
            resident.ModeledFunds = math.max(0, resident.ModeledFunds - spend);
            resident.Dependence = math.min(100f, resident.Dependence + 9f + (homeless ? 8f : 0f) + math.min(7f, supplyPressure / 20f));
            return true;
        }

        public static bool ContainsCenter(Entity building)
        {
            for (int i = 0; i < s_Centers.Count; i++) if (s_Centers[i].Building == building) return true;
            return false;
        }

        public static bool AddCenter(Entity building, string name, string district)
        {
            if (building == Entity.Null || ContainsCenter(building)) return false;
            s_Centers.Add(new Center { Building = building, Name = name ?? "Recovery center", District = district ?? "City district" });
            Status = $"Recovery center designated at {name}. Residents with modeled dependence can be referred here.";
            return true;
        }

        public static Center GetCenter(int index) => index >= 0 && index < s_Centers.Count ? s_Centers[index] : null;

        public static void RecordCenterVisit(Center center, IList<Entity> referred, int residentsHelped)
        {
            center.Visits++;
            int helped = 0;
            int target = math.min(residentsHelped, referred.Count);
            for (int i = 0; i < target; i++)
            {
                Resident resident = Get(referred[i]);
                if (resident == null) continue;
                resident.Dependence = math.max(0f, resident.Dependence - 24f);
                resident.ModeledFunds = math.min(1200, resident.ModeledFunds + 160);
                resident.RecoverySessions++;
                helped++;
            }
            center.ResidentsHelped += helped;
            TotalSessions++;
            if (helped > 0) DrugMarketLedger.RecordDistrictResponse(center.District, helped, false, false);
            Status = helped > 0
                ? $"{center.Name} hosted an outreach session; {helped} residents received modeled recovery support."
                : $"{center.Name} hosted outreach, but no eligible residents were available.";
            PublicReactionLedger.Add("Community recovery outreach", 1);
        }
    }
}
