using System.Text.RegularExpressions;

namespace BarRush
{
    internal static class CityText
    {
        private static readonly Regex s_AssetName = new Regex(@"Assets\.NAME[#\[]([A-Za-z0-9_]+)\]?", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        public static string Clean(string value)
        {
            string text = (value ?? "").Replace("|", "/").Replace("\r", " ").Replace("\n", " ").Trim();
            return s_AssetName.Replace(text, match => Humanize(match.Groups[1].Value));
        }

        private static string Humanize(string token)
        {
            string readable = Regex.Replace(token.Replace('_', ' '), "([a-z])([A-Z])", "$1 $2");
            string[] parts = readable.Split(' ');
            for (int i = 0; i < parts.Length; i++)
            {
                string part = parts[i];
                if (part.Length == 0) continue;
                parts[i] = char.ToUpperInvariant(part[0]) + (part.Length > 1 ? part.Substring(1) : "");
            }
            return string.Join(" ", parts);
        }
    }
}
