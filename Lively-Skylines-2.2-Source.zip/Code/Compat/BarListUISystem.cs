using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Colossal.UI.Binding;
using Game;
using Game.Citizens;
using Game.City;
using Game.Simulation;
using Game.UI;
using Game.Prefabs;
using Game.Tools;
using Game.Rendering;
using Unity.Collections;
using Unity.Entities;
using UnityEngine;

namespace BarRush
{
    // Supplies live data and click actions for the Bars and City Events HUD panels.
    public partial class BarListUISystem : UISystemBase
    {
        private const string kGroup = "BarRush";
        private const float kRefreshSeconds = 2f;

        private NameSystem m_NameSystem;
        private SimulationSystem m_SimulationSystem;
        private CameraUpdateSystem m_CameraUpdateSystem;
        private EntityQuery m_CompanyQuery;
        private EntityQuery m_ParkQuery;
        private EntityQuery m_CitizenQuery;
        private EntityQuery m_HomelessResidentQuery;
        private EntityQuery m_RoadEdgeQuery;
        private EntityQuery m_CityBuildingQuery;
        private EntityQuery m_ResidentialMarketQuery;
        private CitySystem m_CitySystem;
        private readonly List<Entity> m_Companies = new List<Entity>();
        private readonly List<Entity> m_DiyVenues = new List<Entity>();
        private readonly List<Entity> m_Parks = new List<Entity>();
        private readonly List<Entity> m_BikerGangLocations = new List<Entity>();
        private readonly List<Entity> m_BikerRosterLocations = new List<Entity>();
        private readonly List<Entity> m_GangActivityLocations = new List<Entity>();
        private readonly List<Entity> m_GangOrganizationLocations = new List<Entity>();
        private readonly List<Entity> m_DrugMarketLocations = new List<Entity>();
        private readonly List<Entity> m_LaunderingTargets = new List<Entity>();
        private readonly List<Entity> m_PharmacyTargets = new List<Entity>();
        private readonly List<Entity> m_HouseTargets = new List<Entity>();
        private readonly List<Entity> m_CasinoCandidateBuildings = new List<Entity>();
        private readonly List<Entity> m_CasinoTargets = new List<Entity>();
        private CasinoSystem m_CasinoSystem;
        private readonly List<Entity> m_RehabCandidateBuildings = new List<Entity>();
        private readonly List<Entity> m_RehabTargets = new List<Entity>();
        private readonly List<Entity> m_BankCandidateBuildings = new List<Entity>();
        private readonly List<Entity> m_HomelessCandidateBuildings = new List<Entity>();
        private readonly List<Entity> m_HomeMarketBuildings = new List<Entity>();

        private bool m_BarsVisible;
        private bool m_CityEventsVisible;
        private string m_BarsText = "";
        private string m_BarSceneCityText = "";
        private string m_EventsText = "";
        private int m_BarCount;
        private int m_EventCount;
        private string m_ParkText = "";
        private string m_PeopleText = "";
        private string m_BikerGangText = "";
        private string m_BikerRosterText = "";
        private string m_GangActivityText = "";
        private string m_DispatchMapText = "";
        private string m_CityMapText = "";
        private string m_DrugMarketText = "";
        private string m_LaunderingText = "";
        private string m_PharmacyText = "";
        private string m_HouseText = "";
        private string m_CasinoCandidatesText = "";
        private string m_CasinoRowsText = "";
        private string m_RehabCandidatesText = "";
        private string m_RehabCentersText = "";
        private string m_BankCandidatesText = "";
        private string m_HomelessCandidatesText = "";
        private string m_HomeMarketText = "";
        private float m_LastRefresh;
        private float m_LastPeopleRefresh;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
            World.GetOrCreateSystemManaged<VenueOperationsSystem>();
            World.GetOrCreateSystemManaged<CityIssueReportSystem>();
            World.GetOrCreateSystemManaged<ViolentCrimeEventSystem>();
            World.GetOrCreateSystemManaged<VehiclePursuitSystem>();
            World.GetOrCreateSystemManaged<DrugMarketSystem>();
            World.GetOrCreateSystemManaged<DjEventSystem>();
            World.GetOrCreateSystemManaged<BikerCrimeEventSystem>();
            World.GetOrCreateSystemManaged<BikerGangEventSystem>();
            World.GetOrCreateSystemManaged<GangActivityEventSystem>();
            World.GetOrCreateSystemManaged<ParkEventPlanningSystem>();
            RushHourTrafficSystem rushHourTraffic = World.GetOrCreateSystemManaged<RushHourTrafficSystem>();
            World.GetOrCreateSystemManaged<HomelessBarOutreachSystem>();
            World.GetOrCreateSystemManaged<BarPatioSystem>();
            World.GetOrCreateSystemManaged<BikeShareSystem>();
            World.GetOrCreateSystemManaged<BikeShareUISystem>();
            m_CasinoSystem = World.GetOrCreateSystemManaged<CasinoSystem>();
            World.GetOrCreateSystemManaged<CctvPlacementUISystem>();
            m_CameraUpdateSystem = World.GetOrCreateSystemManaged<CameraUpdateSystem>();
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
            m_ParkQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Buildings.Park>(),
                ComponentType.Exclude<Game.Common.Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(),
                ComponentType.Exclude<Game.Common.Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_HomelessResidentQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(),
                ComponentType.ReadOnly<HouseholdMember>(), ComponentType.Exclude<Game.Common.Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_RoadEdgeQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Net.Edge>(),
                ComponentType.Exclude<Game.Common.Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CityBuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Buildings.Building>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Game.Common.Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_ResidentialMarketQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Buildings.Building>(),
                ComponentType.ReadOnly<Game.Buildings.ResidentialProperty>(), ComponentType.ReadOnly<Game.Buildings.PropertyOnMarket>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Game.Common.Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());

            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "barPanelVisible", () => m_BarsVisible));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "cityEventsVisible", () => m_CityEventsVisible));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "cityEventsEnabled", () => Mod.Settings != null && Mod.Settings.Enabled && Mod.Settings.CityEventsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "famousPeopleEnabled", () => Mod.Settings != null && Mod.Settings.Enabled && Mod.Settings.FamousPeopleEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "crimeReportsEnabled", () => Mod.Settings != null && Mod.Settings.Enabled && Mod.Settings.CrimeReportsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "bikerGangEventsEnabled", () => Mod.Settings != null && Mod.Settings.Enabled && Mod.Settings.BikerGangEventsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "drugMarketsEnabled", () => Mod.Settings != null && Mod.Settings.Enabled && Mod.Settings.DrugMarketsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "crimeReportHidingEnabled", () => Mod.Settings != null && Mod.Settings.Enabled && Mod.Settings.CrimeReportHidingEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting0", () => Mod.Settings != null && Mod.Settings.Enabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting1", () => Mod.Settings != null && Mod.Settings.MidnightRushEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting2", () => Mod.Settings != null && Mod.Settings.DjEventsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting3", () => Mod.Settings != null && Mod.Settings.MajorActsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting4", () => Mod.Settings != null && Mod.Settings.CityEventsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting5", () => Mod.Settings != null && Mod.Settings.EventPurchasesEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting6", () => Mod.Settings != null && Mod.Settings.FamousPeopleEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting7", () => Mod.Settings != null && Mod.Settings.CrimeReportsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting8", () => Mod.Settings != null && Mod.Settings.ViolentCrimeEventsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting9", () => Mod.Settings != null && Mod.Settings.CrimeTweetsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting10", () => Mod.Settings != null && Mod.Settings.CrimeReportHidingEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting11", () => Mod.Settings != null && Mod.Settings.CrimeChangesCompany));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting12", () => Mod.Settings != null && Mod.Settings.CrimeAreaScalingEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting13", () => Mod.Settings != null && Mod.Settings.BikerGangEventsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting14", () => Mod.Settings != null && Mod.Settings.BikerCrimeReportsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting15", () => Mod.Settings != null && Mod.Settings.DrugMarketsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting16", () => Mod.Settings != null && Mod.Settings.LacedDrugIncidentsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting17", () => Mod.Settings != null && Mod.Settings.HomelessOutreachEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting18", () => Mod.Settings != null && Mod.Settings.BikeShareEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting19", () => Mod.Settings != null && Mod.Settings.CityIssueReportsEnabled));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "setting20", () => Mod.Settings != null && Mod.Settings.UnderageSalesEnabled));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "barPanelBars", () => m_BarsText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "barSceneCity", () => m_BarSceneCityText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "surveillance", () => SurveillanceLedger.Row()));
            AddBinding(new TriggerBinding<int, int>(kGroup, "surveillanceAction", (code, value) => { SurveillanceLedger.Action(code, value, ChargeForOperation); Refresh(); }));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "barPanelEvents", () => m_EventsText));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "barPanelBarCount", () => m_BarCount));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "cityEventsCount", () => m_EventCount));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "djArrivals", () => ActiveEvents.DjArrivals));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "famousVisits", () => FamousSimRoster.Visits));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "famousRoster", () => FamousSimRoster.Names));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "cityBuzzFeed", () => CityBuzzFeed.Text));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "cityCrimeSummary", () => CityCrimeLedger.Summary(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "cityCrimeReports", () => CityCrimeLedger.Rows(m_SimulationSystem.frameIndex, "All")));
            AddUpdateBinding(new GetterValueBinding<uint>(kGroup, "cityCrimeCurrentFrame", () => m_SimulationSystem.frameIndex));
            AddUpdateBinding(new GetterValueBinding<uint>(kGroup, "cityCrimeFramesPerDay", () => OutingStarter.FramesPerDay));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "pursuitOverlayData", () => VehiclePursuitLedger.OverlayData(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "communityLife", () => CommunityLifeSystem.Rows(m_SimulationSystem.frameIndex)));
            AddBinding(new TriggerBinding<int, int, int>(kGroup, "communityAction", (kind, a, b) => CommunityLifeSystem.Requests.Enqueue((kind, a, b))));
            AddBinding(new TriggerBinding<int, int>(kGroup, "partyAction", (id, action) => HousePartyLedger.Actions.Enqueue((id, action))));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "pursuitsDetail", () => VehiclePursuitLedger.DetailRows(m_SimulationSystem.frameIndex, EntityManager)));
            AddBinding(new TriggerBinding<int, int>(kGroup, "pursuitAction", (id, action) => VehiclePursuitLedger.EnqueueAction(id, action)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "crimeHideStatus", () => CrimeHideQueue.Status));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "promotersAndManagers", () => m_PeopleText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bikerGangMeetups", () => m_BikerGangText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bikerGangRoster", () => m_BikerRosterText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "gangActivityReports", () => m_GangActivityText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "dispatchMapData", () => m_DispatchMapText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "cityMapData", () => m_CityMapText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "drugMarketReports", () => m_DrugMarketText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "drugMarketProducts", () => DrugMarketLedger.ProductCategoryRows));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "drugMarketOrganizations", () => DrugOrganizationLedger.Rows(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "drugMarketSummary", () => DrugMarketLedger.Summary(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "drugMarketDistricts", () => DrugMarketLedger.DistrictRows(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "drugMarketHealthCalls", () => DrugMarketLedger.HealthRows(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "drugMarketEnforcement", () => DrugMarketLedger.EnforcementRows(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "underworldSummary", () => UnderworldOperations.Summary));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "publicAnger", () => PublicReactionLedger.Anger));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "publicGrievance", () => PublicReactionLedger.LatestCause));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "launderingTargets", () => m_LaunderingText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "pharmacyTargets", () => m_PharmacyText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "houseSearchTargets", () => m_HouseText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "parkList", () => m_ParkText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "homeMarketListings", () => m_HomeMarketText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "casinoCandidates", () => m_CasinoCandidatesText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "casinoRows", () => m_CasinoRowsText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "rehabCandidates", () => m_RehabCandidatesText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "rehabCenters", () => m_RehabCentersText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "homelessCandidates", () => m_HomelessCandidatesText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "homelessSites", () => HomelessProgramsLedger.SiteRows(EntityManager)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "homelessSummary", () => HomelessProgramsLedger.Summary));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "homelessProgramStatus", () => HomelessProgramsLedger.Status));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "substanceRecoverySummary", () => $"{SubstanceRecoveryLedger.ResidentsCount}|{SubstanceRecoveryLedger.DependentCount}|{SubstanceRecoveryLedger.DepletedCount}|{SubstanceRecoveryLedger.TotalSessions}"));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "substanceRecoveryStatus", () => SubstanceRecoveryLedger.Status));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "eventPlanStatus", () => ParkEventPlanningQueue.Status));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "rushHourStatus", () => rushHourTraffic.Status));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "rushHourLastReport", () => rushHourTraffic.LastReport));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "rushHourMovingCars", () => rushHourTraffic.MovingVehicleCount));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "ordinanceRows", () => CityPolicyLedger.Rows));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "gangEconomy", () => GangEconomyLedger.Rows));
            AddBinding(new TriggerBinding<int, int>(kGroup, "gangPropertyAction", (id, action) => { long seized = GangEconomyLedger.PropertyAction(id, action, m_SimulationSystem.frameIndex, ChargeForOperation); if (seized > 0) AddCityMoney(seized); Refresh(); }));
            AddBinding(new TriggerBinding<int, int>(kGroup, "gangOrgAction", (id, action) => { GangEconomyLedger.OrgAction(id, action, m_SimulationSystem.frameIndex, ChargeForOperation); Refresh(); }));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "ordinancesActive", () => CityPolicyLedger.ActiveCount));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "ordinancesPending", () => CityPolicyLedger.PendingCount));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "electionStatus", () => CityPolicyLedger.ElectionStatus));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "currentMayor", () => CityPolicyLedger.Mayor));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "electionStats", () => CityPolicyLedger.ElectionStats(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "electionCandidates", () => CityPolicyLedger.CandidateRows));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "electionResults", () => CityPolicyLedger.ResultRows));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "councilMembers", () => CityPolicyLedger.CouncilMembers));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "electionStatusDetails", () => CityPolicyLedger.StatusAt(m_SimulationSystem.frameIndex)));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bankingStats", () => BankingLedger.Stats));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bankingTreasury", () => BankingLedger.TreasuryRow(PublicReactionLedger.Anger)));
            AddBinding(new TriggerBinding<int, int>(kGroup, "treasuryAction", (action, amount) => { BankingLedger.TreasuryAction(action, amount, m_SimulationSystem.frameIndex, PublicReactionLedger.Anger, ChargeForOperation, AddCityMoney); Refresh(); }));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bankingBanks", () => BankingLedger.BankRows));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bankingCandidates", () => m_BankCandidatesText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bankingBusinesses", () => BankingLedger.BusinessRows));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bankingLoans", () => BankingLedger.LoanRows));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bankingCreditRows", () => BankingLedger.CreditRows));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "bankingRescueEnabled", () => BankingLedger.RescueEnabled));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bankingSettings", () => BankingLedger.SelectedBankSettings));

            AddBinding(new TriggerBinding(kGroup, "toggleBarPanel", ToggleBars));
            AddBinding(new TriggerBinding(kGroup, "openBarPanel", OpenBars));
            AddBinding(new TriggerBinding(kGroup, "toggleCityEvents", ToggleCityEvents));
            AddBinding(new TriggerBinding(kGroup, "closeCityEvents", () => m_CityEventsVisible = false));
            AddBinding(new TriggerBinding(kGroup, "closeBarPanel", () => m_BarsVisible = false));
            AddBinding(new TriggerBinding<int, int, string, string>(kGroup, "planPark", PlanPark));
            AddBinding(new TriggerBinding<int>(kGroup, "focusBar", FocusBar));
            AddBinding(new TriggerBinding<int>(kGroup, "focusHomeListing", FocusHomeListing));
            AddBinding(new TriggerBinding<int>(kGroup, "raidVenue", RaidVenue));
            AddBinding(new TriggerBinding<int>(kGroup, "closeVenue", CloseVenue));
            AddBinding(new TriggerBinding<int, int, int>(kGroup, "barSetting", BarSetting));
            AddBinding(new TriggerBinding<int, int>(kGroup, "barCityAction", BarCityAction));
            AddBinding(new TriggerBinding<int>(kGroup, "focusBikerGang", FocusBikerGang));
            AddBinding(new TriggerBinding<int>(kGroup, "focusBikerTurf", FocusBikerTurf));
            AddBinding(new TriggerBinding<int>(kGroup, "focusGangActivity", FocusGangActivity));
            AddBinding(new TriggerBinding<int>(kGroup, "focusGangOrganization", FocusGangOrganization));
            AddBinding(new TriggerBinding<int>(kGroup, "focusDrugMarket", FocusDrugMarket));
            AddBinding(new TriggerBinding<int>(kGroup, "startLaundering", StartLaundering));
            AddBinding(new TriggerBinding<int>(kGroup, "raidLaundering", RaidLaundering));
            AddBinding(new TriggerBinding<int>(kGroup, "leaveLaundering", LeaveLaundering));
            AddBinding(new TriggerBinding<int>(kGroup, "startPharmacyMarket", StartPharmacyMarket));
            AddBinding(new TriggerBinding<int>(kGroup, "raidPharmacy", RaidPharmacy));
            AddBinding(new TriggerBinding<int>(kGroup, "searchHouse", SearchHouse));
            AddBinding(new TriggerBinding<int>(kGroup, "designateCasino", DesignateCasino));
            AddBinding(new TriggerBinding<int, int, int>(kGroup, "setCasinoSetting", SetCasinoSetting));
            AddBinding(new TriggerBinding<int>(kGroup, "setCasinoOpen", SetCasinoOpen));
            AddBinding(new TriggerBinding<int>(kGroup, "focusCasino", FocusCasino));
            AddBinding(new TriggerBinding<int>(kGroup, "runCasinoSession", RunCasinoSession));
            AddBinding(new TriggerBinding<int, int>(kGroup, "designateRehab", (index, _) => DesignateRehab(index)));
            AddBinding(new TriggerBinding<int>(kGroup, "runRehabSession", RunRehabSession));
            AddBinding(new TriggerBinding<int, int>(kGroup, "designateHomelessSite", DesignateHomelessSite));
            AddBinding(new TriggerBinding<int>(kGroup, "removeHomelessSite", RemoveHomelessSite));
            AddBinding(new TriggerBinding<int, int>(kGroup, "setHomelessProgramOption", SetHomelessProgramOption));
            AddBinding(new TriggerBinding<int, int>(kGroup, "hideCrimeReport", HideCrimeReport));
            AddBinding(new TriggerBinding<int>(kGroup, "toggleModSetting", ToggleModSetting));
            AddBinding(new TriggerBinding<int, int>(kGroup, "ordinanceAction", (index, action) => { CityPolicyLedger.Act(index, action, m_SimulationSystem.frameIndex); Refresh(); }));
            AddBinding(new TriggerBinding(kGroup, "runCityElection", () => { CityPolicyLedger.RunElection(m_SimulationSystem.frameIndex); Refresh(); }));
            AddBinding(new TriggerBinding(kGroup, "runElectionPoll", () => { CityPolicyLedger.RunPoll(m_SimulationSystem.frameIndex); Refresh(); }));
            AddBinding(new TriggerBinding<int, int>(kGroup, "campaignRally", (candidate, big) => { CityPolicyLedger.Rally(candidate, big != 0, m_SimulationSystem.frameIndex); Refresh(); }));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "councilElectionResult", () => CityPolicyLedger.LastCouncilResult + "|" + CityPolicyLedger.MayorParty));
            AddBinding(new TriggerBinding(kGroup, "startElectionDebate", () => { CityPolicyLedger.StartDebate(m_SimulationSystem.frameIndex); Refresh(); }));
            AddBinding(new TriggerBinding<int>(kGroup, "designateBank", DesignateBank));
            AddBinding(new TriggerBinding<int>(kGroup, "selectBank", (index) => { BankingLedger.SelectBank(index); Refresh(); }));
            AddBinding(new TriggerBinding<int, int>(kGroup, "offerBankLoan", (index, amount) => { BankingLedger.OfferLoan(index, amount, m_SimulationSystem.frameIndex); Refresh(); }));
            AddBinding(new TriggerBinding<int, int, int>(kGroup, "rescueBusiness", (index, option, amount) => { BankingLedger.RescueBusiness(index, option, amount, m_SimulationSystem.frameIndex); Refresh(); }));
            AddBinding(new TriggerBinding<int, int>(kGroup, "setBankingSetting", (setting, value) => { BankingLedger.ApplySetting(setting, value); Refresh(); }));
            Mod.log.Info("Lively Skylines and City Events UI system created.");
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 16;

        private void ToggleModSetting(int index)
        {
            Setting settings = Mod.Settings;
            if (settings == null) return;
            switch (index)
            {
                case 0: settings.Enabled = !settings.Enabled; break;
                case 1: settings.MidnightRushEnabled = !settings.MidnightRushEnabled; break;
                case 2: settings.DjEventsEnabled = !settings.DjEventsEnabled; break;
                case 3: settings.MajorActsEnabled = !settings.MajorActsEnabled; break;
                case 4: settings.CityEventsEnabled = !settings.CityEventsEnabled; break;
                case 5: settings.EventPurchasesEnabled = !settings.EventPurchasesEnabled; break;
                case 6: settings.FamousPeopleEnabled = !settings.FamousPeopleEnabled; break;
                case 7: settings.CrimeReportsEnabled = !settings.CrimeReportsEnabled; break;
                case 8: settings.ViolentCrimeEventsEnabled = !settings.ViolentCrimeEventsEnabled; break;
                case 9: settings.CrimeTweetsEnabled = !settings.CrimeTweetsEnabled; break;
                case 10: settings.CrimeReportHidingEnabled = !settings.CrimeReportHidingEnabled; break;
                case 11: settings.CrimeChangesCompany = !settings.CrimeChangesCompany; break;
                case 12: settings.CrimeAreaScalingEnabled = !settings.CrimeAreaScalingEnabled; break;
                case 13: settings.BikerGangEventsEnabled = !settings.BikerGangEventsEnabled; break;
                case 14: settings.BikerCrimeReportsEnabled = !settings.BikerCrimeReportsEnabled; break;
                case 15: settings.DrugMarketsEnabled = !settings.DrugMarketsEnabled; break;
                case 16: settings.LacedDrugIncidentsEnabled = !settings.LacedDrugIncidentsEnabled; break;
                case 17: settings.HomelessOutreachEnabled = !settings.HomelessOutreachEnabled; break;
                case 18: settings.BikeShareEnabled = !settings.BikeShareEnabled; break;
                case 19: settings.CityIssueReportsEnabled = !settings.CityIssueReportsEnabled; break;
                case 20: settings.UnderageSalesEnabled = !settings.UnderageSalesEnabled; break;
                default: return;
            }
            settings.ApplyAndSave();
            Refresh();
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();
            if ((m_BarsVisible || m_CityEventsVisible)
                && UnityEngine.Time.realtimeSinceStartup - m_LastRefresh >= kRefreshSeconds)
            {
                Refresh();
            }
        }

        private void ToggleBars()
        {
            m_BarsVisible = !m_BarsVisible;
            if (m_BarsVisible)
            {
                m_CityEventsVisible = false;
                Refresh();
            }
        }

        private void OpenBars()
        {
            m_CityEventsVisible = false;
            if (m_BarsVisible) return;
            m_BarsVisible = true;
            Refresh();
        }

        private void ToggleCityEvents()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.CityEventsEnabled) return;
            // City events now live inside the main React dashboard. Treat any
            // legacy toggle request as an open request; it must never hide the
            // dashboard while the Events tab is being selected.
            m_CityEventsVisible = false;
            m_BarsVisible = true;
            Refresh();
        }

        private void Refresh()
        {
            m_LastRefresh = UnityEngine.Time.realtimeSinceStartup;
            uint frame = m_SimulationSystem.frameIndex;
            CityPolicyLedger.Advance(frame, m_CitizenQuery.CalculateEntityCount());
            ApplyOrdinanceBudget(CityPolicyLedger.TakeMonthlyBudget(frame), frame);
            GangEconomyLedger.Advance(frame, EntityManager, m_CityBuildingQuery, m_NameSystem);
            ApplyOrdinanceBudget((int)Math.Max(int.MinValue, Math.Min(int.MaxValue, BankingLedger.TakeTreasuryCashflow(frame, CityMoney()))), frame, "City treasury (deposits, bonds and grants)");
            RefreshUnhousedResidentCount();
            EnsureOrganizationTurf(frame);

            List<ActiveEvents.Entry> events = ActiveEvents.Current(frame);
            var eventLines = new List<string>(events.Count);
            foreach (ActiveEvents.Entry entry in events)
            {
                float hoursLeft = (entry.EndFrame - frame) * 24f / OutingStarter.FramesPerDay;
                string location = string.IsNullOrEmpty(entry.Place) ? "" : $" at {entry.Place}";
                eventLines.Add($"{entry.Title}{location} — {entry.Attendees:N0} sims · about {hoursLeft:0.#} in-game hours left");
            }

            m_EventCount = eventLines.Count;
            m_EventsText = string.Join("\n", eventLines);

            BarFinder.CollectBarCompanies(EntityManager, m_CompanyQuery, m_Companies);
            BarFinder.CollectDIYMusicVenueBuildings(EntityManager, m_CompanyQuery, m_DiyVenues);
            var sortedBars = new List<KeyValuePair<string, Entity>>(m_Companies.Count);
            foreach (Entity company in m_Companies)
            {
                string name = m_NameSystem.GetRenderedLabelName(company);
                // Some game assets have no localized display name and NameSystem returns
                // their internal localization key (for example Assets.NAME[Commercial_Bar]).
                // Keep those keys out of the player-facing dashboard and create a useful
                // venue label below instead.
                bool hasDisplayName = !string.IsNullOrWhiteSpace(name)
                    && name.IndexOf("Assets.NAME", StringComparison.OrdinalIgnoreCase) < 0
                    && name.IndexOf("Assets.NAME[", StringComparison.OrdinalIgnoreCase) < 0;
                sortedBars.Add(new KeyValuePair<string, Entity>(hasDisplayName ? name : string.Empty, company));
            }
            sortedBars.Sort((a, b) => string.CompareOrdinal(a.Key, b.Key));
            m_Companies.Clear();
            var barLines = new List<string>(sortedBars.Count);
            for (int i = 0; i < sortedBars.Count; i++)
            {
                string name = sortedBars[i].Key.Replace("|", " ").Replace("\n", " ").Replace("\r", " ");
                Entity company = sortedBars[i].Value;
                m_Companies.Add(company);
                Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
                string kind = BarFinder.IsNightclub(company) ? "Nightclub" : "Bar";
                string type = BarFinder.IsDIYMusicVenue(building, m_DiyVenues) ? $"DIY Music Venue · {kind}" : kind;
                if (string.IsNullOrWhiteSpace(name)) name = $"{kind} #{i + 1}";
                var scene = BarSceneLedger.Get(building);
                if (string.IsNullOrEmpty(scene.Name)) scene.Name = name;
                barLines.Add($"{i}|{type}|{name}|{BarCaseLedger.Get(building)}|{VenueOperations.Status(building, frame)}|{scene.Price}|{(scene.HappyHour ? 1 : 0)}|{scene.Bouncers}|{scene.LastCall}|{(scene.LiveMusic ? 1 : 0)}|{(scene.StrictId ? 1 : 0)}|{scene.Popularity}|{scene.Rowdiness}|{scene.Tonight}|{scene.LastNight}|{scene.Total}|{scene.LastRevenue}|{scene.Revenue}|{scene.TaxPaid}|{scene.Fights}|{scene.FightsStopped}|{scene.Duis}|{scene.Underage}|{scene.Noise}|{scene.Stars}|{scene.Inspections}|{scene.Violations}|{(scene.Area ?? "").Replace("|", " ").Replace("\n", " ")}|{string.Join("~", scene.Events)}|{scene.PromoBoost}");
            }
            m_BarCount = barLines.Count;
            m_BarsText = string.Join("\n", barLines);
            m_BarSceneCityText = $"{BarSceneLedger.LiquorTax}|{(BarSceneLedger.RideHome ? 1 : 0)}|{BarSceneLedger.CityTaxTotal}|{BarSceneLedger.LastNightTax}|{BarSceneLedger.LastNightGuests}|{BarSceneLedger.LastNightFights}|{BarSceneLedger.LastNightDuis}|{BarSceneLedger.NightsRun}|{BarSceneLedger.LastNightSummary.Replace("|", " ")}|{BarSceneLedger.MaxLastCall}|{(BarSceneLedger.HappyHourBanned ? 1 : 0)}|{BarSceneLedger.MinBouncers}|{(BarSceneLedger.NightOpen ? 1 : 0)}|{BarSceneLedger.RideHomeSpent}";

            List<BikerGangMeetupLedger.Entry> bikerEntries = BikerGangMeetupLedger.Recent(frame);
            m_BikerGangLocations.Clear();
            var bikerLines = new List<string>(bikerEntries.Count);
            for (int i = 0; i < bikerEntries.Count; i++)
            {
                BikerGangMeetupLedger.Entry entry = bikerEntries[i];
                m_BikerGangLocations.Add(entry.Location);
                string status = frame < entry.EndFrame ? "Meetup active" : "Meetup ended";
                string age = CrimeAge(frame, entry.Frame);
                bikerLines.Add($"{i}|{entry.Gang}|{entry.Venue}|{entry.Area}|{entry.Bikes}|{entry.Residents}|{status}|{age}");
            }
            m_BikerGangText = string.Join("\n", bikerLines);

            m_BikerRosterLocations.Clear();
            var bikerRosterLines = new List<string>();
            for (int i = 0; i < BikerRoster.Count; i++)
            {
                BikerRoster.Group group = BikerRoster.Get(i);
                if (group == null) continue;
                m_BikerRosterLocations.Add(group.Home);
                bikerRosterLines.Add($"{i}|{CleanMapText(group.Name)}|{CleanMapText(group.Area)}|{BikerRoster.GetActiveRiders(group, EntityManager).Count}");
            }
            m_BikerRosterText = string.Join("\n", bikerRosterLines);

            List<GangActivityLedger.Entry> gangEntries = GangActivityLedger.Recent(frame);
            m_GangActivityLocations.Clear();
            var gangLines = new List<string>(gangEntries.Count);
            for (int i = 0; i < gangEntries.Count; i++)
            {
                GangActivityLedger.Entry entry = gangEntries[i];
                m_GangActivityLocations.Add(entry.Location);
                string status = frame < entry.EndFrame ? "Active report" : "Report ended";
                string age = CrimeAge(frame, entry.Frame);
                gangLines.Add($"{i}|{entry.Type}|{entry.Group}|{entry.Activity}|{entry.Area}|{entry.Members}|{status}|{age}");
            }
            m_GangActivityText = string.Join("\n", gangLines);
            m_GangOrganizationLocations.Clear();
            for (int organizationId = 0; organizationId < DrugOrganizationLedger.Count("Street gang") + DrugOrganizationLedger.Count("Cartel"); organizationId++)
            {
                DrugOrganizationLedger.Organization organization = DrugOrganizationLedger.ById(organizationId);
                if (organization != null) m_GangOrganizationLocations.Add(organization.Location);
            }

            BuildDispatchMap();
            BuildCityMap();
            BuildHomeMarketListings();
            List<DrugMarketLedger.Entry> drugEntries = DrugMarketLedger.Recent(frame);
            m_DrugMarketLocations.Clear();
            foreach (DrugMarketLedger.Entry entry in drugEntries) m_DrugMarketLocations.Add(entry.Location);
            m_DrugMarketText = DrugMarketLedger.Rows(frame);
            BuildUnderworldTargets(frame);
            BuildCasinoRows();
            BuildRecoveryRows();
            BuildHomelessProgramRows();
            BuildBankingRows(frame);
            BankingLedger.Advance(frame);

            if (UnityEngine.Time.realtimeSinceStartup - m_LastPeopleRefresh >= 20f || string.IsNullOrEmpty(m_PeopleText))
                RefreshPromotersAndManagers(frame);

            using NativeArray<Entity> parks = m_ParkQuery.ToEntityArray(Allocator.Temp);
            var namedParks = new List<KeyValuePair<string, Entity>>(parks.Length);
            foreach (Entity park in parks)
            {
                string parkName = m_NameSystem.GetRenderedLabelName(park);
                if (string.IsNullOrEmpty(parkName)) parkName = $"Park {park.Index}";
                namedParks.Add(new KeyValuePair<string, Entity>(parkName, park));
            }
            namedParks.Sort((a, b) => string.CompareOrdinal(a.Key, b.Key));
            m_Parks.Clear();
            var parkLines = new List<string>();
            int listed = namedParks.Count;
            for (int i = 0; i < listed; i++)
            {
                m_Parks.Add(namedParks[i].Value);
                string safeName = namedParks[i].Key.Replace("|", " ").Replace("\n", " ").Replace("\r", " ");
                parkLines.Add($"{i}|{safeName}");
            }
            m_ParkText = string.Join("\n", parkLines);
        }

        private void RefreshUnhousedResidentCount()
        {
            int residents = 0;
            using NativeArray<Entity> citizens = m_HomelessResidentQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity citizen in citizens)
            {
                Entity household = EntityManager.GetComponentData<HouseholdMember>(citizen).m_Household;
                if (household != Entity.Null && EntityManager.Exists(household) && EntityManager.HasComponent<HomelessHousehold>(household))
                    residents++;
            }
            HomelessProgramsLedger.SetUnhousedResidentCount(residents);
        }

        private void RefreshPromotersAndManagers(uint frame)
        {
            m_LastPeopleRefresh = UnityEngine.Time.realtimeSinceStartup;
            using NativeArray<Entity> citizens = m_CitizenQuery.ToEntityArray(Allocator.Temp);
            if (citizens.Length == 0)
            {
                m_PeopleText = "";
                return;
            }

            string[] promoterNames = { "Neon Nova", "Afterglow", "Velvet Voltage", "Midnight Mix", "Pink Static", "Electric Avenue", "Lunar Club" };
            string[] managerNames = { "Night Shift", "Pulse Crew", "Silver Lining", "Late Check-In", "Moonlight Office", "The Door Team" };
            var random = new System.Random(unchecked((int)(frame * 1103515245u + 12345u)));
            var chosen = new HashSet<Entity>();
            var people = new List<string>(5);

            for (int i = 0; i < 5 && chosen.Count < citizens.Length; i++)
            {
                Entity citizen = citizens[random.Next(citizens.Length)];
                int attempts = 0;
                while (chosen.Contains(citizen) && attempts++ < citizens.Length)
                    citizen = citizens[random.Next(citizens.Length)];
                if (!chosen.Add(citizen)) continue;

                string simName = m_NameSystem.GetRenderedLabelName(citizen);
                if (string.IsNullOrWhiteSpace(simName)) simName = $"City resident {citizen.Index}";
                simName = simName.Replace("|", " ").Replace("\n", " ").Replace("\r", " ");
                bool promoter = i < 3;
                string[] aliases = promoter ? promoterNames : managerNames;
                string alias = aliases[random.Next(aliases.Length)];
                people.Add($"{(promoter ? "Promoter" : "Event Manager")}|{alias}|{simName}");
            }

            m_PeopleText = string.Join("\n", people);
        }

        private void PlanPark(int index, int size, string name, string type)
        {
            if (index < 0 || index >= m_Parks.Count || !EntityManager.Exists(m_Parks[index]))
            {
                ParkEventPlanningQueue.SetStatus("Park list is refreshing. Try again in a moment.");
                return;
            }
            if (ActiveEvents.HasActiveCityEvent(m_SimulationSystem.frameIndex))
            {
                ParkEventPlanningQueue.SetStatus("A city event is already running. Wait for it to finish.");
                return;
            }
            ParkEventPlanningQueue.Enqueue(m_Parks[index], size, name, type);
            ParkEventPlanningQueue.SetStatus("Checking the event size and city attendance limit…");
        }

        private void FocusBar(int index)
        {
            if (index < 0 || index >= m_Companies.Count || !EntityManager.Exists(m_Companies[index])) return;
            Entity company = m_Companies[index];
            if (!EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) return;
            Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
            if (building == Entity.Null || !EntityManager.Exists(building) || !EntityManager.HasComponent<Game.Objects.Transform>(building)) return;
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(building).m_Position;
            var camera = m_CameraUpdateSystem.gamePlayController;
            if (camera != null) camera.pivot = new UnityEngine.Vector3(position.x, position.y, position.z);
        }

        private void RaidVenue(int index)
        {
            if (index < 0 || index >= m_Companies.Count) return;
            Entity company = m_Companies[index];
            if (!EntityManager.Exists(company) || !EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) return;
            Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
            VenueOperations.QueueRaid(building);
            VenueOperations.Set(building, "Raid queued · 10 officers dispatched");
        }

        private void BarSetting(int index, int code, int value)
        {
            if (index < 0 || index >= m_Companies.Count) return;
            Entity company = m_Companies[index];
            if (!EntityManager.Exists(company) || !EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) return;
            Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
            if (building == Entity.Null) return;
            BarSceneLedger.Bar b = BarSceneLedger.Get(building);
            uint frame = m_SimulationSystem.frameIndex;
            string place = string.IsNullOrEmpty(b.Name) ? "a local bar" : b.Name;
            switch (code)
            {
                case 0: b.Price = Unity.Mathematics.math.clamp(value, 0, 2); b.Log(b.Price == 0 ? "Switched to cheap drinks." : b.Price == 2 ? "Went premium on drinks." : "Set standard drink prices."); break;
                case 1: b.HappyHour = !b.HappyHour; b.Log(b.HappyHour ? "Started a happy hour." : "Ended happy hour."); break;
                case 2: b.Bouncers = Unity.Mathematics.math.clamp(value, 0, 2); break;
                case 3: b.LastCall = Unity.Mathematics.math.clamp(value, 0, 2); break;
                case 4: b.LiveMusic = !b.LiveMusic; b.Log(b.LiveMusic ? "Booked local bands." : "Stopped live music."); break;
                case 5: b.StrictId = !b.StrictId; b.Log(b.StrictId ? "Started strict ID checks." : "Loosened ID checks at the door."); break;
                case 6:
                    if (!ChargeForOperation(10000)) { b.Log("A promotion needs $10,000 in city funds."); break; }
                    b.PromoBoost = Unity.Mathematics.math.min(40, b.PromoBoost + 15);
                    b.Log("The city ran a $10,000 nightlife promotion for this bar.");
                    CityBuzzFeed.Add("Nightlife · promo", "Nightlife Now", place, $"Tonight's hot spot: {place}. Specials all night.", frame);
                    break;
                case 7:
                    if (!ChargeForOperation(2000)) { b.Log("An inspection needs $2,000 in city funds."); break; }
                    b.Inspections++;
                    var rnd = new System.Random(unchecked((int)(frame * 2654435761u) ^ building.Index));
                    int chance = 15 + b.Rowdiness / 2 + (b.StrictId ? 0 : 25) + (BarSceneLedger.EffBouncers(b) == 0 ? 10 : 0);
                    if (rnd.Next(100) < chance)
                    {
                        int fine = 5000 + rnd.Next(0, 10001);
                        b.Violations++;
                        b.Popularity = Unity.Mathematics.math.max(5, b.Popularity - 5);
                        AddCityMoney(fine);
                        b.Log($"Inspectors found violations and fined the bar ${fine:N0} (paid to the city).");
                        CityBuzzFeed.Add("Bars · inspection", "City dispatch", place, $"City inspectors fined {place} ${fine:N0} for violations.", frame);
                    }
                    else { b.Popularity = Unity.Mathematics.math.min(100, b.Popularity + 2); b.Log("Inspection passed with no violations."); }
                    break;
            }
            Refresh();
        }

        private void BarCityAction(int code, int value)
        {
            if (code == 0) BarSceneLedger.LiquorTax = Unity.Mathematics.math.clamp(value, 0, 2);
            else if (code == 1) BarSceneLedger.RideHome = !BarSceneLedger.RideHome;
            Refresh();
        }

        private void CloseVenue(int index)
        {
            if (index < 0 || index >= m_Companies.Count) return;
            Entity company = m_Companies[index];
            if (!EntityManager.Exists(company) || !EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) return;
            Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
            VenueOperations.QueueClose(building);
            VenueOperations.Set(building, "Venue closure queued");
        }

        private void FocusBikerGang(int index)
        {
            if (index < 0 || index >= m_BikerGangLocations.Count) return;
            Entity location = m_BikerGangLocations[index];
            FocusLocation(location);
        }

        private void FocusBikerTurf(int index)
        {
            if (index < 0 || index >= m_BikerRosterLocations.Count) return;
            FocusLocation(m_BikerRosterLocations[index]);
        }

        private void FocusLocation(Entity location)
        {
            if (location == Entity.Null || !EntityManager.Exists(location) || !EntityManager.HasComponent<Game.Objects.Transform>(location)) return;
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(location).m_Position;
            var camera = m_CameraUpdateSystem.gamePlayController;
            if (camera != null) camera.pivot = new UnityEngine.Vector3(position.x, position.y, position.z);
        }

        private void FocusGangActivity(int index)
        {
            if (index < 0 || index >= m_GangActivityLocations.Count) return;
            Entity location = m_GangActivityLocations[index];
            if (location == Entity.Null || !EntityManager.Exists(location) || !EntityManager.HasComponent<Game.Objects.Transform>(location)) return;
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(location).m_Position;
            var camera = m_CameraUpdateSystem.gamePlayController;
            if (camera != null) camera.pivot = new UnityEngine.Vector3(position.x, position.y, position.z);
        }

        private void FocusGangOrganization(int index)
        {
            if (index < 0 || index >= m_GangOrganizationLocations.Count) return;
            Entity location = m_GangOrganizationLocations[index];
            if (location == Entity.Null || !EntityManager.Exists(location) || !EntityManager.HasComponent<Game.Objects.Transform>(location)) return;
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(location).m_Position;
            var camera = m_CameraUpdateSystem.gamePlayController;
            if (camera != null) camera.pivot = new UnityEngine.Vector3(position.x, position.y, position.z);
        }

        private void BuildDispatchMap()
        {
            var rows = new StringBuilder(32768);
            using (NativeArray<Entity> edges = m_RoadEdgeQuery.ToEntityArray(Allocator.Temp))
            {
                int stride = edges.Length > 3000 ? (edges.Length + 2999) / 3000 : 1;
                for (int i = 0; i < edges.Length; i += stride)
                {
                    Game.Net.Edge edge = EntityManager.GetComponentData<Game.Net.Edge>(edges[i]);
                    if (!EntityManager.Exists(edge.m_Start) || !EntityManager.Exists(edge.m_End)
                        || !EntityManager.HasComponent<Game.Net.Node>(edge.m_Start) || !EntityManager.HasComponent<Game.Net.Node>(edge.m_End)) continue;
                    Unity.Mathematics.float3 start = EntityManager.GetComponentData<Game.Net.Node>(edge.m_Start).m_Position;
                    Unity.Mathematics.float3 end = EntityManager.GetComponentData<Game.Net.Node>(edge.m_End).m_Position;
                    rows.Append("R|").Append(Coordinate(start.x)).Append('|').Append(Coordinate(start.z)).Append('|')
                        .Append(Coordinate(end.x)).Append('|').Append(Coordinate(end.z)).AppendLine();
                }
            }

            foreach (Entity company in m_Companies)
            {
                if (!EntityManager.Exists(company) || !EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) continue;
                Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
                AppendMapPoint(rows, 'V', building, m_NameSystem.GetRenderedLabelName(company), BarFinder.IsNightclub(company) ? "Nightclub" : "Bar");
            }
            foreach (Entity venue in m_DiyVenues)
                AppendMapPoint(rows, 'V', venue, m_NameSystem.GetRenderedLabelName(venue), "DIY venue");
            CityCrimeLedger.AppendMapRows(rows, EntityManager);
            VehiclePursuitLedger.AppendMapRows(rows, EntityManager, m_SimulationSystem.frameIndex);
            ProtestLocationLedger.AppendMapRows(rows);
            BarPatioLedger.AppendMapRows(rows);
            HomelessEncampmentLedger.AppendMapRows(rows, m_SimulationSystem.frameIndex);
            HomelessProgramsLedger.AppendMapRows(rows, EntityManager);
            BikeShareLedger.AppendMapRows(rows);
            for (int i = 0; i < BikerRoster.Count; i++)
            {
                BikerRoster.Group group = BikerRoster.Get(i);
                if (group != null) AppendTurf(rows, 'B', group.Home, group.Name, group.Area, 900f);
            }
            for (int i = 0; i < DrugOrganizationLedger.Count("Street gang") + DrugOrganizationLedger.Count("Cartel"); i++)
            {
                DrugOrganizationLedger.Organization organization = DrugOrganizationLedger.ById(i);
                if (organization != null) AppendTurf(rows, 'G', organization.Location, organization.Name, organization.Territory, organization.Type == "Cartel" ? 1350f : 850f);
            }
            m_DispatchMapText = rows.ToString();
        }

        private void BuildCityMap()
        {
            var rows = new StringBuilder(32768);
            using (NativeArray<Entity> edges = m_RoadEdgeQuery.ToEntityArray(Allocator.Temp))
            {
                int stride = edges.Length > 3000 ? (edges.Length + 2999) / 3000 : 1;
                for (int i = 0; i < edges.Length; i += stride)
                {
                    Game.Net.Edge edge = EntityManager.GetComponentData<Game.Net.Edge>(edges[i]);
                    if (!EntityManager.Exists(edge.m_Start) || !EntityManager.Exists(edge.m_End)
                        || !EntityManager.HasComponent<Game.Net.Node>(edge.m_Start) || !EntityManager.HasComponent<Game.Net.Node>(edge.m_End)) continue;
                    Unity.Mathematics.float3 start = EntityManager.GetComponentData<Game.Net.Node>(edge.m_Start).m_Position;
                    Unity.Mathematics.float3 end = EntityManager.GetComponentData<Game.Net.Node>(edge.m_End).m_Position;
                    rows.Append("R|").Append(Coordinate(start.x)).Append('|').Append(Coordinate(start.z)).Append('|')
                        .Append(Coordinate(end.x)).Append('|').Append(Coordinate(end.z)).AppendLine();
                }
            }

            var businessBuildings = new HashSet<Entity>();
            using (NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity company in companies)
                {
                    if (!EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) continue;
                    Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
                    string category = BarFinder.IsBar(EntityManager, company) ? "Entertainment" : "Business";
                    if (building != Entity.Null) businessBuildings.Add(building);
                    AppendMapPoint(rows, BarFinder.IsBar(EntityManager, company) ? 'V' : 'S', building,
                        m_NameSystem.GetRenderedLabelName(company), category);
                }
            }

            using (NativeArray<Entity> parks = m_ParkQuery.ToEntityArray(Allocator.Temp))
                foreach (Entity park in parks) AppendMapPoint(rows, 'P', park, m_NameSystem.GetRenderedLabelName(park), "Park");

            using (NativeArray<Entity> buildings = m_CityBuildingQuery.ToEntityArray(Allocator.Temp))
            {
                int stride = buildings.Length > 3000 ? (buildings.Length + 2999) / 3000 : 1;
                for (int i = 0; i < buildings.Length; i += stride)
                {
                    Entity building = buildings[i];
                    if (EntityManager.HasComponent<Game.Buildings.Park>(building)) continue;
                    if (businessBuildings.Contains(building)) continue;
                    string name = m_NameSystem.GetRenderedLabelName(building);
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    AppendMapPoint(rows, 'L', building, name, "City place");
                }
            }
            BarPatioLedger.AppendMapRows(rows);
            HomelessEncampmentLedger.AppendMapRows(rows, m_SimulationSystem.frameIndex);
            HomelessProgramsLedger.AppendMapRows(rows, EntityManager);
            BikeShareLedger.AppendMapRows(rows);
            m_CityMapText = rows.ToString();
        }

        private void BuildUnderworldTargets(uint frame)
        {
            m_LaunderingTargets.Clear(); m_PharmacyTargets.Clear(); m_HouseTargets.Clear();
            var laundryRows = new List<string>();
            var pharmacyRows = new List<string>();
            var houseRows = new List<string>();
            using (NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity company in companies)
                {
                    if (!EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) continue;
                    Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
                    if (building == Entity.Null || !EntityManager.Exists(building)) continue;
                    string name = m_NameSystem.GetRenderedLabelName(company);
                    if (string.IsNullOrWhiteSpace(name)) name = m_NameSystem.GetRenderedLabelName(building);
                    string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                    string searchable = (name + " " + m_NameSystem.GetRenderedLabelName(building)).ToLowerInvariant();
                    if (!BarFinder.IsBar(EntityManager, company) && !searchable.Contains("pharmacy") && !searchable.Contains("chemist") && !searchable.Contains("drugstore") && !searchable.Contains("drug store"))
                    {
                        m_LaunderingTargets.Add(building);
                        laundryRows.Add($"{m_LaunderingTargets.Count - 1}|{CleanMapText(name)}|{CleanMapText(area)}|{UnderworldOperations.LaunderingStatus(building, frame)}");
                    }
                    if (searchable.Contains("pharmacy") || searchable.Contains("chemist") || searchable.Contains("drugstore") || searchable.Contains("drug store"))
                    {
                        m_PharmacyTargets.Add(building);
                        pharmacyRows.Add($"{m_PharmacyTargets.Count - 1}|{CleanMapText(name)}|{CleanMapText(area)}|{UnderworldOperations.PharmacyStatus(building)}");
                    }
                }
            }

            var companyBuildings = new HashSet<Entity>();
            using (NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp))
                foreach (Entity company in companies)
                    if (EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) companyBuildings.Add(EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property);
            using (NativeArray<Entity> buildings = m_CityBuildingQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity building in buildings)
                {
                    if (companyBuildings.Contains(building) || EntityManager.HasComponent<Game.Buildings.Park>(building)) continue;
                    string name = m_NameSystem.GetRenderedLabelName(building);
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    string lower = name.ToLowerInvariant();
                    if (!(lower.Contains("housing") || lower.Contains("residential") || lower.Contains("house") || lower.Contains("apartment") || lower.Contains("flat"))) continue;
                    if (!CityCrimeLedger.HasRecentThreatAt(building, frame)) continue;
                    string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                    m_HouseTargets.Add(building);
                    houseRows.Add($"{m_HouseTargets.Count - 1}|{CleanMapText(name)}|{CleanMapText(area)}|{UnderworldOperations.HouseStatus(building)}");
                    if (houseRows.Count >= 100) break;
                }
            }
            m_LaunderingText = string.Join("\n", laundryRows);
            m_PharmacyText = string.Join("\n", pharmacyRows);
            m_HouseText = string.Join("\n", houseRows);
        }

        private long CityMoney()
        {
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city)) return 0;
            return EntityManager.GetComponentData<PlayerMoney>(city).money;
        }

        private void AddCityMoney(long amount)
        {
            if (amount <= 0) return;
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city)) return;
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            if (money.m_Unlimited) return;
            money.Add((int)Math.Min(int.MaxValue, amount));
            EntityManager.SetComponentData(city, money);
        }

        private void ApplyOrdinanceBudget(int net, uint frame, string source = "Active city laws")
        {
            if (net == 0) return;
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city)) return;
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            if (money.m_Unlimited) return;
            if (net > 0) money.Add(net); else money.Subtract(-net);
            EntityManager.SetComponentData(city, money);
            CityBuzzFeed.Add(net > 0 ? "Ordinance income collected" : "Ordinance costs paid", "City finance", "City Hall",
                net > 0 ? $"{source} brought in ${net:N0} this month." : $"{source} cost ${-net:N0} this month.", frame);
        }

        private bool ChargeForOperation(int amount)
        {
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city)) return false;
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            if (!money.m_Unlimited && money.money < amount) return false;
            if (!money.m_Unlimited) { money.Subtract(amount); EntityManager.SetComponentData(city, money); }
            return true;
        }

        private string TargetName(Entity location)
        {
            string name = m_NameSystem.GetRenderedLabelName(location);
            return string.IsNullOrWhiteSpace(name) ? "City address" : name;
        }

        private void StartLaundering(int index)
        {
            if (index < 0 || index >= m_LaunderingTargets.Count) return;
            Entity location = m_LaunderingTargets[index];
            UnderworldOperations.StartLaundering(location, TargetName(location), m_SimulationSystem.frameIndex);
            Refresh();
        }

        private void LeaveLaundering(int index)
        {
            if (index < 0 || index >= m_LaunderingTargets.Count) return;
            Entity location = m_LaunderingTargets[index];
            UnderworldOperations.LeaveLaundering(location, TargetName(location), m_SimulationSystem.frameIndex);
            Refresh();
        }

        private void RaidLaundering(int index)
        {
            if (index < 0 || index >= m_LaunderingTargets.Count) return;
            if (!ChargeForOperation(50000)) { CityBuzzFeed.Add("Raid not funded", "City finance", "Citywide", "The $50,000 simulated financial-crime raid could not be funded.", m_SimulationSystem.frameIndex); return; }
            Entity location = m_LaunderingTargets[index];
            var random = new Unity.Mathematics.Random(Unity.Mathematics.math.max(1u, m_SimulationSystem.frameIndex ^ (uint)location.Index * 2246822519u));
            bool found = random.NextInt(100) < 55;
            int recovery = found ? random.NextInt(10000, 90001) : 0;
            UnderworldOperations.RaidLaundering(location, TargetName(location), m_SimulationSystem.frameIndex, found, recovery);
            Refresh();
        }

        private void StartPharmacyMarket(int index)
        {
            if (index < 0 || index >= m_PharmacyTargets.Count) return;
            Entity location = m_PharmacyTargets[index];
            string[] modeledProducts = { "cannabis-type product", "stimulant-type product", "opioid-type product", "club-drug type product", "unknown mixed supply" };
            var random = new Unity.Mathematics.Random(Unity.Mathematics.math.max(1u, m_SimulationSystem.frameIndex ^ (uint)location.Index * 3266489917u));
            UnderworldOperations.StartPharmacyMarket(location, TargetName(location), modeledProducts[random.NextInt(modeledProducts.Length)], m_SimulationSystem.frameIndex);
            Refresh();
        }

        private void RaidPharmacy(int index)
        {
            if (index < 0 || index >= m_PharmacyTargets.Count) return;
            if (!ChargeForOperation(75000)) { CityBuzzFeed.Add("Raid not funded", "City finance", "Citywide", "The $75,000 simulated drug-market raid could not be funded.", m_SimulationSystem.frameIndex); return; }
            Entity location = m_PharmacyTargets[index];
            var random = new Unity.Mathematics.Random(Unity.Mathematics.math.max(1u, m_SimulationSystem.frameIndex ^ (uint)location.Index * 668265263u));
            UnderworldOperations.RaidPharmacy(location, TargetName(location), m_SimulationSystem.frameIndex, random.NextInt(100) < 28);
            Refresh();
        }

        private void SearchHouse(int index)
        {
            if (index < 0 || index >= m_HouseTargets.Count) return;
            if (!ChargeForOperation(50000)) { CityBuzzFeed.Add("Search not funded", "City finance", "Citywide", "The $50,000 simulated police search could not be funded.", m_SimulationSystem.frameIndex); return; }
            Entity location = m_HouseTargets[index];
            var random = new Unity.Mathematics.Random(Unity.Mathematics.math.max(1u, m_SimulationSystem.frameIndex ^ (uint)location.Index * 1597334677u));
            int roll = random.NextInt(100);
            string finding = roll < 78 ? "Nothing found" : roll < 94 ? "Unregistered weapon reported" : roll < 98 ? "Controlled substances reported" : "Possible explosive hazard reported";
            uint frame = m_SimulationSystem.frameIndex;
            string place = TargetName(location);
            UnderworldOperations.SearchHouse(location, place, frame, finding);
            if (finding != "Nothing found")
            {
                Entity incident = EntityManager.CreateEntity();
                Entity district = EntityManager.HasComponent<Game.Areas.CurrentDistrict>(location)
                    ? EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(location).m_District : Entity.Null;
                bool hasPolice = CrimeAreaSystem.HasPoliceStation(district);
                string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
                string response = hasPolice ? "Police dispatched to the reported threat" : "No nearby station · response delayed";
                string detail = $"Police searched {place} after a reported threat. Search result: {finding}. {response}. This is a fictional city-simulation report; the building and residents are unchanged.";
                CityCrimeLedger.Record(incident, location, place, area, hasPolice, false, frame, detail, "Police search · threat found", "Unidentified", response);
                CityBuzzFeed.AddCrime(incident, $"{place} · {area}", detail, frame, "Police operations", "Police search · threat found");
            }
            Refresh();
        }

        private void BuildCasinoRows()
        {
            m_CasinoCandidateBuildings.Clear();
            var candidates = new List<KeyValuePair<string, Entity>>();
            using (NativeArray<Entity> buildings = m_CityBuildingQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity building in buildings)
                {
                    if (EntityManager.HasComponent<Game.Buildings.Park>(building) || CasinoLedger.Contains(building)) continue;
                    string name = m_NameSystem.GetRenderedLabelName(building);
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    candidates.Add(new KeyValuePair<string, Entity>(name, building));
                }
            }
            candidates.Sort((a, b) => string.CompareOrdinal(a.Key, b.Key));
            var availableRows = new List<string>();
            for (int i = 0; i < candidates.Count && i < 160; i++)
            {
                Entity building = candidates[i].Value;
                m_CasinoCandidateBuildings.Add(building);
                string name = CleanMapText(candidates[i].Key);
                string area = CleanMapText(CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building));
                availableRows.Add($"{i}|{name}|{area}");
            }
            m_CasinoCandidatesText = string.Join("\n", availableRows);

            m_CasinoTargets.Clear();
            var casinoRows = new List<string>();
            for (int i = 0; i < CasinoLedger.All.Count; i++)
            {
                CasinoLedger.Casino casino = CasinoLedger.All[i];
                m_CasinoTargets.Add(casino.Building);
                string status = casino.Building != Entity.Null && EntityManager.Exists(casino.Building) ? (casino.Open ? "Open" : "Closed") : "Building unavailable";
                casinoRows.Add($"{i}|{CleanMapText(casino.Name)}|{CleanMapText(casino.District)}|{status}|{casino.Security}|{casino.GamingFloor}|{casino.Marketing}|{(casino.AllDay ? "All day" : "Night hours")}|{casino.LastVisitors}|{casino.TotalVisitors}|{casino.ModeledRevenue}|{casino.SafetyReports}|{CleanMapText(casino.LastReport)}|{casino.Slots}|{casino.Tables}|{casino.Poker}|{casino.Sportsbook}|{(casino.Hotel ? 1 : 0)}|{(casino.Shows ? 1 : 0)}|{(casino.ResponsibleGaming ? 1 : 0)}|{(casino.Aml ? 1 : 0)}|{casino.Reputation}|{(int)casino.AtRisk}|{casino.CityProfit}|{casino.LastNet}|{casino.Jackpots}|{casino.BiggestJackpot}|{casino.Whales}|{casino.CheatersCaught}|{casino.Robberies}|{casino.LaunderingBlocked}|{casino.LaunderingMissed}|{casino.Handle}|{CleanMapText(string.Join("~", casino.Events))}|{casino.Fines}");
            }
            m_CasinoRowsText = string.Join("\n", casinoRows);
        }

        private void BuildHomeMarketListings()
        {
            m_HomeMarketBuildings.Clear();
            var rows = new List<string>();
            using (NativeArray<Entity> buildings = m_ResidentialMarketQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity building in buildings)
                {
                    if (!EntityManager.Exists(building) || !EntityManager.HasComponent<Game.Objects.Transform>(building)) continue;
                    Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(building).m_Position;
                    string name = m_NameSystem.GetRenderedLabelName(building);
                    if (string.IsNullOrWhiteSpace(name)) name = "Residential property";
                    string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                    int index = m_HomeMarketBuildings.Count;
                    m_HomeMarketBuildings.Add(building);
                    // CS2 exposes market status but not a household-facing listing price here.
                    // Keep the estimate explicit and deterministic for a stable, browsable UI.
                    uint priceSeed = unchecked((uint)building.Index * 7919u + (uint)building.Version * 104729u);
                    // Real rent from the simulation: the average rent households in this building
                    // actually pay (PropertyRenter.m_Rent); falls back to the market asking rent.
                    int rent = 0, rentingHouseholds = 0;
                    if (EntityManager.HasBuffer<Game.Buildings.Renter>(building))
                    {
                        DynamicBuffer<Game.Buildings.Renter> renters = EntityManager.GetBuffer<Game.Buildings.Renter>(building, true);
                        long rentSum = 0;
                        for (int r = 0; r < renters.Length; r++)
                        {
                            Entity renter = renters[r].m_Renter;
                            if (renter == Entity.Null || !EntityManager.Exists(renter)) continue;
                            if (!EntityManager.HasComponent<Household>(renter) || !EntityManager.HasComponent<Game.Buildings.PropertyRenter>(renter)) continue;
                            rentSum += EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(renter).m_Rent;
                            rentingHouseholds++;
                        }
                        if (rentingHouseholds > 0) rent = (int)(rentSum / rentingHouseholds);
                    }
                    if (rent <= 0 && EntityManager.HasComponent<Game.Buildings.PropertyOnMarket>(building))
                        rent = Math.Max(0, EntityManager.GetComponentData<Game.Buildings.PropertyOnMarket>(building).m_AskingRent);
                    // With a real rent, anchor the modeled sale estimate to it (about 20x annual rent, +/-10%).
                    int estimate = rent > 0
                        ? (int)(rent * 12L * 20L * (90 + (int)(priceSeed % 21u)) / 100L)
                        : 145000 + (int)(priceSeed % 560000u);
                    string type = name.IndexOf("apartment", StringComparison.OrdinalIgnoreCase) >= 0
                        || name.IndexOf("flat", StringComparison.OrdinalIgnoreCase) >= 0 ? "Apartment" : "House";
                    rows.Add($"{index}|{CleanMapText(name)}|{CleanMapText(area)}|{Coordinate(position.x)}|{Coordinate(position.z)}|{estimate}|{type}|{rent}|{rentingHouseholds}");
                }
            }
            m_HomeMarketText = string.Join("\n", rows);
        }

        private void FocusHomeListing(int index)
        {
            if (index < 0 || index >= m_HomeMarketBuildings.Count) return;
            Entity building = m_HomeMarketBuildings[index];
            if (building == Entity.Null || !EntityManager.Exists(building) || !EntityManager.HasComponent<Game.Objects.Transform>(building)) return;
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(building).m_Position;
            var camera = m_CameraUpdateSystem.gamePlayController;
            if (camera != null) camera.pivot = new UnityEngine.Vector3(position.x, position.y, position.z);
        }

        private void DesignateCasino(int index)
        {
            if (index < 0 || index >= m_CasinoCandidateBuildings.Count) return;
            Entity building = m_CasinoCandidateBuildings[index];
            if (building == Entity.Null || !EntityManager.Exists(building) || CasinoLedger.Contains(building)) return;
            if (!ChargeForOperation(250000))
            {
                CityBuzzFeed.Add("Casino proposal not funded", "City finance", "Citywide", "Selecting a building for casino conversion requires a $250,000 startup investment.", m_SimulationSystem.frameIndex);
                return;
            }
            string name = TargetName(building);
            string district = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
            if (!CasinoLedger.TryCreate(building, name, district)) return;
            CityBuzzFeed.Add("Casino opened", "Lively Skylines", name, $"The city has designated {name} in {district} as a casino. The building asset itself remains unchanged; this mod now models resident visits, operating hours, gaming-floor capacity, security, marketing, estimated revenue, and safety reports for the address. City staff can review those settings and activity on the Casinos page as the venue operates. This is a city-simulation designation and does not change the building's underlying game asset.", m_SimulationSystem.frameIndex);
            Refresh();
        }

        private void SetCasinoSetting(int index, int setting, int value)
        {
            CasinoLedger.Casino casino = CasinoLedger.Get(index);
            if (casino == null) return;
            if (setting >= 10)
            {
                if (setting <= 13)
                {
                    int cur = setting == 10 ? casino.Slots : setting == 11 ? casino.Tables : setting == 12 ? casino.Poker : casino.Sportsbook;
                    int tgt = Unity.Mathematics.math.clamp(value, 0, 3);
                    if (tgt == cur) return;
                    if (tgt > cur)
                    {
                        int unit = setting == 10 ? 60000 : setting == 11 ? 90000 : setting == 12 ? 70000 : 80000;
                        int c2 = unit * tgt;
                        if (!ChargeForOperation(c2)) { casino.LastReport = $"Upgrade needs ${c2:N0} in city funds."; Refresh(); return; }
                        casino.Log($"{(setting == 10 ? "Slots" : setting == 11 ? "Table games" : setting == 12 ? "Poker room" : "Sportsbook")} upgraded to level {tgt} for ${c2:N0}.");
                    }
                    if (setting == 10) casino.Slots = tgt; else if (setting == 11) casino.Tables = tgt; else if (setting == 12) casino.Poker = tgt; else casino.Sportsbook = tgt;
                }
                else if (setting == 20)
                {
                    if (casino.Hotel) return;
                    if (!ChargeForOperation(300000)) { casino.LastReport = "The casino hotel needs $300,000 in city funds."; Refresh(); return; }
                    casino.Hotel = true; casino.Reputation = Unity.Mathematics.math.min(100, casino.Reputation + 10);
                    casino.Log("A casino hotel tower opened, drawing high rollers and tourists.");
                    CityBuzzFeed.Add("Casino hotel opens", "Nightlife Now", casino.Name, $"{casino.Name} opened a hotel tower. Expect more high rollers and visitors.", m_SimulationSystem.frameIndex);
                }
                else if (setting == 21) casino.Shows = !casino.Shows;
                else if (setting == 22) casino.ResponsibleGaming = !casino.ResponsibleGaming;
                else if (setting == 23) casino.Aml = !casino.Aml;
                Refresh();
                return;
            }
            int current = setting == 0 ? casino.Security : setting == 1 ? casino.GamingFloor : setting == 2 ? casino.Marketing : casino.AllDay ? 1 : 0;
            int target = setting == 0 ? Unity.Mathematics.math.clamp(value, 1, 3)
                : setting == 1 ? Unity.Mathematics.math.clamp(value, 1, 3)
                : setting == 2 ? Unity.Mathematics.math.clamp(value, 0, 3)
                : setting == 3 ? Unity.Mathematics.math.clamp(value, 0, 1) : current;
            if (target == current) return;
            if (target > current)
            {
                int cost = setting == 0 ? 75000 * target : setting == 1 ? 150000 * target : setting == 2 ? 45000 * target : 125000;
                if (!ChargeForOperation(cost))
                {
                    casino.LastReport = $"Upgrade needs ${cost:N0} in available city funds.";
                    CityBuzzFeed.Add("Casino upgrade not funded", "City finance", casino.Name, casino.LastReport, m_SimulationSystem.frameIndex);
                    Refresh();
                    return;
                }
                CityBuzzFeed.Add("Casino upgrade purchased", "City finance", casino.Name,
                    $"{CasinoUpgradeName(setting)} upgraded to level {target}. City funds used: ${cost:N0}.", m_SimulationSystem.frameIndex);
                casino.LastReport = $"{CasinoUpgradeName(setting)} upgraded to level {target} · ${cost:N0} city funds.";
            }
            if (setting == 0) casino.Security = target;
            else if (setting == 1) casino.GamingFloor = target;
            else if (setting == 2) casino.Marketing = target;
            else if (setting == 3) casino.AllDay = target != 0;
            Refresh();
        }

        private static string CasinoUpgradeName(int setting) => setting == 0 ? "Security" : setting == 1 ? "Gaming floor" : setting == 2 ? "Marketing" : "Extended-hours permit";

        private void RunCasinoSession(int index)
        {
            CasinoLedger.Casino casino = CasinoLedger.Get(index);
            if (casino == null) return;
            if (!casino.Open)
            {
                casino.LastReport = "Open the casino before starting a session.";
                Refresh();
                return;
            }
            m_CasinoSystem.RequestSession(index);
        }

        private void SetCasinoOpen(int index)
        {
            CasinoLedger.Casino casino = CasinoLedger.Get(index);
            if (casino == null) return;
            casino.Open = !casino.Open;
            CityBuzzFeed.Add(casino.Open ? "Casino opened" : "Casino closed", "Lively Skylines", casino.Name,
                casino.Open ? $"{casino.Name} is open for modeled resident visits." : $"{casino.Name} paused casino operations; its building remains unchanged.", m_SimulationSystem.frameIndex);
            Refresh();
        }

        private void FocusCasino(int index)
        {
            if (index < 0 || index >= m_CasinoTargets.Count) return;
            FocusLocation(m_CasinoTargets[index]);
        }

        private void BuildBankingRows(uint frame)
        {
            m_BankCandidateBuildings.Clear();
            var candidates = new List<KeyValuePair<string, Entity>>();
            using (NativeArray<Entity> buildings = m_CityBuildingQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity building in buildings)
                {
                    if (EntityManager.HasComponent<Game.Buildings.Park>(building)) continue;
                    string label = m_NameSystem.GetRenderedLabelName(building);
                    if (string.IsNullOrWhiteSpace(label)) continue;
                    string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                    if (label.IndexOf("bank", System.StringComparison.OrdinalIgnoreCase) >= 0
                        || label.IndexOf("credit union", System.StringComparison.OrdinalIgnoreCase) >= 0
                        || label.IndexOf("financial", System.StringComparison.OrdinalIgnoreCase) >= 0)
                        BankingLedger.RegisterBank(building, CleanMapText(label), CleanMapText(area));
                    candidates.Add(new KeyValuePair<string, Entity>(label, building));
                }
            }
            candidates.Sort((a, b) => string.CompareOrdinal(a.Key, b.Key));
            var candidateRows = new List<string>();
            for (int i = 0; i < candidates.Count && i < 200; i++)
            {
                Entity building = candidates[i].Value;
                m_BankCandidateBuildings.Add(building);
                candidateRows.Add($"{i}|{CleanMapText(candidates[i].Key)}|{CleanMapText(CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building))}");
            }
            m_BankCandidatesText = string.Join("\n", candidateRows);

            var businessRows = new List<BankingLedger.Business>();
            using (NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity company in companies)
                {
                    if (!EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) continue;
                    Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
                    if (building == Entity.Null || !EntityManager.Exists(building)) continue;
                    string name = m_NameSystem.GetRenderedLabelName(company);
                    if (string.IsNullOrWhiteSpace(name)) name = m_NameSystem.GetRenderedLabelName(building);
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                    long losses = CrimeCompanySwapSystem.BusinessLosses(building);
                    int cases = BarCaseLedger.Get(building);
                    int index = businessRows.Count;
                    long debt = 35000 + ((long)(building.Index * 7919L) % 175000L);
                    long monthlyLoss = losses > 0 ? Math.Min(25000, losses / 4 + 2200) : 1200 + (building.Index % 7) * 700;
                    int rating = Unity.Mathematics.math.clamp(770 - (int)Math.Min(280, losses / 1200) - cases * 34 - building.Index % 53, 300, 850);
                    string grade = rating >= 760 ? "AAA" : rating >= 700 ? "AA" : rating >= 640 ? "A" : rating >= 580 ? "BBB" : rating >= 520 ? "BB" : "CCC";
                    int cashDays = Math.Max(0, 42 - (int)(losses / 6500) - cases * 5 - building.Index % 9);
                    bool hasRecentCrime = losses > 0 || cases >= 2;
                    string status = hasRecentCrime ? (cashDays < 8 ? "Bankrupt" : "At risk") : cashDays < 8 ? "Distressed" : "Stable";
                    businessRows.Add(new BankingLedger.Business
                    {
                        Building = building,
                        Name = CleanMapText(name),
                        Area = CleanMapText(area),
                        Kind = BarFinder.IsBar(EntityManager, company) ? "Venue" : "Company",
                        Debt = debt,
                        MonthlyLoss = monthlyLoss,
                        Jobs = 4 + Math.Abs(building.Index * 13 % 42),
                        CashDays = cashDays,
                        Rating = rating,
                        Grade = grade,
                        Status = status,
                    });
                }
            }
            businessRows.Sort((a, b) => string.CompareOrdinal(a.Status, b.Status));
            BankingLedger.RefreshBusinesses(businessRows);
        }

        private void DesignateBank(int index)
        {
            if (index < 0 || index >= m_BankCandidateBuildings.Count) return;
            Entity building = m_BankCandidateBuildings[index];
            string name = TargetName(building);
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
            BankingLedger.DesignateBank(building, name, area, m_SimulationSystem.frameIndex);
            Refresh();
        }

        private void BuildRecoveryRows()
        {
            m_RehabCandidateBuildings.Clear();
            var candidates = new List<KeyValuePair<string, Entity>>();
            using (NativeArray<Entity> buildings = m_CityBuildingQuery.ToEntityArray(Allocator.Temp))
                foreach (Entity building in buildings)
                {
                    if (EntityManager.HasComponent<Game.Buildings.Park>(building) || SubstanceRecoveryLedger.ContainsCenter(building)) continue;
                    string name = m_NameSystem.GetRenderedLabelName(building);
                    if (!string.IsNullOrWhiteSpace(name)) candidates.Add(new KeyValuePair<string, Entity>(name, building));
                }
            candidates.Sort((a, b) => string.CompareOrdinal(a.Key, b.Key));
            var candidateRows = new List<string>();
            for (int i = 0; i < candidates.Count && i < 120; i++)
            {
                m_RehabCandidateBuildings.Add(candidates[i].Value);
                candidateRows.Add($"{i}|{CleanMapText(candidates[i].Key)}|{CleanMapText(CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, candidates[i].Value))}");
            }
            m_RehabCandidatesText = string.Join("\n", candidateRows);
            m_RehabTargets.Clear();
            var centerRows = new List<string>();
            for (int i = 0; i < SubstanceRecoveryLedger.Centers.Count; i++)
            {
                SubstanceRecoveryLedger.Center center = SubstanceRecoveryLedger.Centers[i];
                m_RehabTargets.Add(center.Building);
                centerRows.Add($"{i}|{CleanMapText(center.Name)}|{CleanMapText(center.District)}|{center.Capacity}|{center.Visits}|{center.ResidentsHelped}");
            }
            m_RehabCentersText = string.Join("\n", centerRows);
        }

        private void DesignateRehab(int index)
        {
            if (index < 0 || index >= m_RehabCandidateBuildings.Count) return;
            Entity building = m_RehabCandidateBuildings[index];
            if (building == Entity.Null || !EntityManager.Exists(building) || SubstanceRecoveryLedger.ContainsCenter(building)) return;
            if (!ChargeForOperation(150000))
            {
                SubstanceRecoveryLedger.Status = "Recovery center designation requires a $150,000 city startup investment.";
                return;
            }
            string name = TargetName(building);
            string district = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
            if (!SubstanceRecoveryLedger.AddCenter(building, name, district)) return;
            CityBuzzFeed.Add("Recovery center", "City health services", name,
                $"The city designated {name} as a recovery outreach center. The building asset is unchanged; referral sessions can now route residents here.", m_SimulationSystem.frameIndex);
            Refresh();
        }

        private void RunRehabSession(int index)
        {
            SubstanceRecoveryLedger.Center center = SubstanceRecoveryLedger.GetCenter(index);
            if (center == null || center.Building == Entity.Null || !EntityManager.Exists(center.Building)) return;
            var eligible = new List<SubstanceRecoveryLedger.Resident>();
            foreach (SubstanceRecoveryLedger.Resident resident in SubstanceRecoveryLedger.Residents)
                if (resident.Dependence >= 20f && EntityManager.Exists(resident.Citizen) && EntityManager.HasComponent<CurrentBuilding>(resident.Citizen)
                    && !EntityManager.HasComponent<Leisure>(resident.Citizen)) eligible.Add(resident);
            eligible.Sort((a, b) => b.Dependence.CompareTo(a.Dependence));
            if (eligible.Count == 0)
            {
                SubstanceRecoveryLedger.Status = $"{center.Name}: no residents currently qualify for a modeled referral session.";
                return;
            }
            int population = m_CitizenQuery.CalculateEntityCount();
            int cap = PopulationCap.MaxAttendees(population, Mod.Settings != null ? Mod.Settings.MaxAttendancePercent : 10);
            int capacity = Unity.Mathematics.math.min(center.Capacity, AttendanceLedger.Remaining(cap, m_SimulationSystem.frameIndex));
            int referredCount = Unity.Mathematics.math.min(capacity, eligible.Count);
            if (referredCount <= 0) { SubstanceRecoveryLedger.Status = "The city attendance limit is full. Try again later."; return; }
            var referred = new List<Entity>(referredCount);
            for (int i = 0; i < referredCount; i++) referred.Add(eligible[i].Citizen);
            if (!ChargeForOperation(20000)) { SubstanceRecoveryLedger.Status = "A recovery outreach session costs $20,000 in city funds."; return; }
            using (NativeArray<Entity> residents = new NativeArray<Entity>(referred.ToArray(), Allocator.Temp))
            {
                var random = new Unity.Mathematics.Random(Unity.Mathematics.math.max(1u, m_SimulationSystem.frameIndex * 747796405u + (uint)center.Building.Index));
                uint duration = Unity.Mathematics.math.max(1u, OutingStarter.FramesPerDay / 6u);
                int helped = OutingStarter.Start(EntityManager, residents, referred.Count, ref random, m_SimulationSystem.frameIndex, duration, center.Building);
                AttendanceLedger.Add(helped, m_SimulationSystem.frameIndex + duration);
                SubstanceRecoveryLedger.RecordCenterVisit(center, referred, helped);
                CityBuzzFeed.Add("Recovery outreach", "City health services", center.Name,
                    $"A voluntary modeled outreach session at {center.Name} routed {helped} residents to support. Dependence and fictional financial strain can improve with repeated recovery visits.", m_SimulationSystem.frameIndex);
            }
            Refresh();
        }

        private void BuildHomelessProgramRows()
        {
            m_HomelessCandidateBuildings.Clear();
            var candidates = new List<KeyValuePair<string, Entity>>();
            using (NativeArray<Entity> buildings = m_CityBuildingQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity building in buildings)
                {
                    if (!EntityManager.Exists(building)) continue;
                    string name = m_NameSystem.GetRenderedLabelName(building);
                    if (!string.IsNullOrWhiteSpace(name)) candidates.Add(new KeyValuePair<string, Entity>(name, building));
                }
            }
            candidates.Sort((a, b) => string.CompareOrdinal(a.Key, b.Key));
            var rows = new List<string>();
            for (int i = 0; i < candidates.Count && i < 160; i++)
            {
                Entity building = candidates[i].Value;
                m_HomelessCandidateBuildings.Add(building);
                string area = CleanMapText(CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building));
                rows.Add($"{i}|{CleanMapText(candidates[i].Key)}|{area}|{HomelessProgramsLedger.TypeFor(building)}");
            }
            m_HomelessCandidatesText = string.Join("\n", rows);
        }

        private void DesignateHomelessSite(int index, int type)
        {
            if (index < 0 || index >= m_HomelessCandidateBuildings.Count || type < HomelessProgramsLedger.Shelter || type > HomelessProgramsLedger.GreenZone) return;
            Entity building = m_HomelessCandidateBuildings[index];
            if (building == Entity.Null || !EntityManager.Exists(building)) return;
            string name = TargetName(building);
            string district = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
            if (!HomelessProgramsLedger.Designate(building, name, district, type)) return;
            CityBuzzFeed.Add("Housing & outreach", "City services", name,
                $"The city designated {name} in {district} as a {HomelessProgramsLedger.TypeName(type)}. This mod-side program uses the selected address; it does not replace or alter the building asset.", m_SimulationSystem.frameIndex);
            Refresh();
        }

        private void RemoveHomelessSite(int index)
        {
            if (index < 0 || index >= HomelessProgramsLedger.Sites.Count) return;
            HomelessProgramsLedger.Remove(HomelessProgramsLedger.Sites[index].Building);
            Refresh();
        }

        private void SetHomelessProgramOption(int option, int value)
        {
            if (option < 0 || option > 2) return;
            HomelessProgramsLedger.SetOption(option, value);
            Refresh();
        }

        private void EnsureOrganizationTurf(uint frame)
        {
            var random = new Unity.Mathematics.Random(Unity.Mathematics.math.max(1u, frame * 747796405u + 2891336453u));
            DrugOrganizationLedger.EnsureInitialRoster(ref random, frame);
            DrugOrganizationLedger.EnsureStartingTurfs(EntityManager, m_CityBuildingQuery, m_NameSystem, ref random);
            BikerRoster.EnsureStartingTurfs(EntityManager, m_CityBuildingQuery, m_NameSystem, ref random);
        }

        private void AppendTurf(StringBuilder rows, char kind, Entity location, string name, string area, float radius)
        {
            if (location == Entity.Null || !EntityManager.Exists(location) || !EntityManager.HasComponent<Game.Objects.Transform>(location)) return;
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(location).m_Position;
            rows.Append(kind).Append('|').Append(Coordinate(position.x)).Append('|').Append(Coordinate(position.z)).Append('|')
                .Append(CleanMapText(name)).Append('|').Append(CleanMapText(area)).Append('|').Append(Coordinate(radius)).AppendLine();
        }

        private void AppendMapPoint(StringBuilder rows, char kind, Entity entity, string name, string category)
        {
            if (entity == Entity.Null || !EntityManager.Exists(entity) || !EntityManager.HasComponent<Game.Objects.Transform>(entity)) return;
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(entity).m_Position;
            rows.Append(kind).Append('|').Append(Coordinate(position.x)).Append('|').Append(Coordinate(position.z)).Append('|')
                .Append(CleanMapText(name)).Append('|').Append(CleanMapText(category)).AppendLine();
        }

        private void FocusDrugMarket(int index)
        {
            if (index < 0 || index >= m_DrugMarketLocations.Count) return;
            Entity location = m_DrugMarketLocations[index];
            if (location == Entity.Null || !EntityManager.Exists(location) || !EntityManager.HasComponent<Game.Objects.Transform>(location)) return;
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(location).m_Position;
            var camera = m_CameraUpdateSystem.gamePlayController;
            if (camera != null) camera.pivot = new UnityEngine.Vector3(position.x, position.y, position.z);
        }

        private static string Coordinate(float value) => value.ToString("0.##", CultureInfo.InvariantCulture);
        private static string CleanMapText(string value)
        {
            string clean = CityText.Clean(value);
            return string.IsNullOrWhiteSpace(clean) ? "Local city place" : clean;
        }

        private static string CrimeAge(uint frame, uint reported)
        {
            uint hours = OutingStarter.FramesPerDay / 24u;
            uint elapsed = frame >= reported ? frame - reported : 0u;
            if (elapsed < hours) return "Just now";
            if (elapsed < OutingStarter.FramesPerDay) return $"{elapsed / hours} in-game hours ago";
            uint days = elapsed / OutingStarter.FramesPerDay;
            return days == 1 ? "Yesterday" : $"{days} in-game days ago";
        }

        private void HideCrimeReport(int index, int version)
        {
            CrimeHideQueue.Enqueue(new Entity { Index = index, Version = version });
        }
    }
}

