using System.Collections.Generic;
using Game;
using Game.Buildings;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Fictional biker-associated theft reports tied to actual city riders and shown in the city crime feed.</summary>
    public partial class BikerCrimeEventSystem : GameSystemBase
    {
        private const float kReportTime = 22.15f / 24f;
        private const uint kCooldown = OutingStarter.FramesPerDay / 2u;
        private static readonly string[] s_Crimes = { "Pickpocketing", "Pickpocketing", "Robbery", "Car break-in", "Shoplifting", "Smash-and-grab" };
        private EntityQuery m_BuildingQuery;
        private EntityQuery m_CitizenQuery;
        private EntityQuery m_ParkedPersonalCarQuery;
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private float m_PreviousTime = -1f;
        private uint m_LastIncidentFrame;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_BuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Building>(), ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_ParkedPersonalCarQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Vehicles.ParkedCar>(),
                ComponentType.ReadOnly<Game.Vehicles.PersonalCar>(), ComponentType.ReadOnly<Game.Objects.Transform>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.BikerGangEventsEnabled || !settings.BikerCrimeReportsEnabled || !settings.CrimeReportsEnabled) return;
            float now = m_TimeSystem.normalizedTime;
            bool reached = m_PreviousTime >= 0f && m_PreviousTime < kReportTime && now >= kReportTime;
            m_PreviousTime = now;
            if (!reached) return;
            uint frame = m_SimulationSystem.frameIndex;
            if (m_LastIncidentFrame != 0 && frame - m_LastIncidentFrame < kCooldown) return;
            CreateReport(frame);
        }

        private void CreateReport(uint frame)
        {
            var random = new Random(math.max(1u, frame * 3266489917u + 668265263u));
            BikerRoster.EnsureInitialGroups();
            float cityRate = CityCrimeLedger.WeeklyPerThousand(frame);
            int pressureBonus = (int)math.min(24f, cityRate * 3f);
            int chance = math.clamp(Mod.Settings.BikerCrimeChancePercent + 18 + pressureBonus, 0, 85);
            if (BikerRoster.Count == 0 || random.NextInt(100) >= chance) return;
            var groups = new List<BikerRoster.Group>();
            for (int i = 0; i < BikerRoster.Count; i++)
            {
                BikerRoster.Group group = BikerRoster.Get(i);
                if (BikerRoster.GetActiveRiders(group, EntityManager).Count > 0) groups.Add(group);
            }
            if (groups.Count == 0) return;

            BikerRoster.Group chosen = groups[random.NextInt(groups.Count)];
            List<Entity> riders = BikerRoster.GetActiveRiders(chosen, EntityManager);
            string type = s_Crimes[random.NextInt(s_Crimes.Length)];
            Entity location = chosen.Home;
            Entity suspect = Entity.Null;
            int stolenCash = 0;
            if (type == "Car break-in")
            {
                if (!TrySelectAndBreakIntoCar(ref random, out location, out suspect, out stolenCash))
                    type = random.NextInt(2) == 0 ? "Pickpocketing" : "Robbery";
            }
            if (location == Entity.Null || !EntityManager.Exists(location))
            {
                using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
                if (buildings.Length == 0) return;
                location = buildings[random.NextInt(buildings.Length)];
            }
            string place = type == "Car break-in"
                ? $"Parked car near {DistrictLandmark(location)}"
                : m_NameSystem.GetRenderedLabelName(location);
            if (string.IsNullOrWhiteSpace(place)) place = "City area";
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
            Entity district = EntityManager.HasComponent<Game.Areas.CurrentDistrict>(location) ? EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(location).m_District : Entity.Null;
            bool hasPolice = CrimeAreaSystem.HasPoliceStation(district);

            // CCTV cuts the odds of the mod's modeled biker crime at its selected location.
            if (EntityManager.HasComponent<Game.Objects.Transform>(location) &&
                CctvCrimeCoverage.Covers(EntityManager, EntityManager.GetComponentData<Game.Objects.Transform>(location).m_Position) &&
                random.NextInt(100) < 75)
                return;

            if (suspect == Entity.Null) suspect = riders[random.NextInt(riders.Count)];
            string suspectName = m_NameSystem.GetRenderedLabelName(suspect);
            if (string.IsNullOrWhiteSpace(suspectName)) suspectName = "Unidentified local resident";
            string response = hasPolice ? "Police unit dispatched · suspect reported under pursuit" : "No station in district · police response delayed";
            string detail = type == "Car break-in"
                ? $"Parked personal car broken into. ${stolenCash:N0} stolen from the owner's household funds. Alleged suspect: {suspectName}, linked to {chosen.Name}. {response}."
                : $"Lively Skylines simulated {type.ToLowerInvariant()} report linked to {chosen.Name}. Suspect: {suspectName}. {response}.";
            Entity incident = EntityManager.CreateEntity();
            CityCrimeLedger.Record(incident, location, place, area, hasPolice, false, frame, detail, type, suspectName, response);
            string feedMessage = type == "Car break-in"
                ? $"Car break-in reported at {place}, {area}. ${stolenCash:N0} stolen from the vehicle owner's household funds. Alleged suspect: {suspectName}, linked to {chosen.Name}. {response}."
                : $"Police are investigating a reported {type.ToLowerInvariant()} near {place} in {area}. The report names {suspectName} as an alleged suspect linked to {chosen.Name}; this is a modeled allegation, not a real-world accusation. {response}. Residents are advised to report relevant information and avoid confronting anyone.";
            CityBuzzFeed.AddCrime(incident, $"{place} · {area}", feedMessage, frame, "Lively Skylines report", type);

            if (Mod.Settings.CrimeTweetsEnabled && Mod.Settings.FamousPeopleEnabled && FamousSimRoster.TryPick(EntityManager, ref random, out Entity celebrity, out string famousName))
            {
                string tweet = type == "Pickpocketing" ? $"Reports of pickpocketing near {place}. Keep your belongings close and look out for each other." : type == "Car break-in" ? $"A car break-in was reported near {place}. Please check on neighbors and report anything you saw." : $"A robbery was reported near {place}. Hoping everyone is safe and police can respond quickly.";
                CityBuzzFeed.AddSocial("Tweet", famousName, $"{place} · {area}", tweet, frame, random.NextInt(80, 12000), random.NextInt(5, 1500), incident);
                FamousSimRoster.RecordPost(celebrity);
            }
            m_LastIncidentFrame = frame;
            Mod.log.Info(type == "Car break-in"
                ? $"Lively Skylines simulated car break-in at {place}; ${stolenCash:N0} stolen from household funds; alleged resident {suspectName}, group {chosen.Name}."
                : $"Lively Skylines simulated {type} report at {place}; alleged resident {suspectName}, group {chosen.Name}, police status: {response}.");
        }

        private bool TrySelectAndBreakIntoCar(ref Random random, out Entity vehicle, out Entity suspect, out int stolenCash)
        {
            vehicle = Entity.Null;
            suspect = Entity.Null;
            stolenCash = 0;
            var eligible = new List<Entity>();
            using NativeArray<Entity> cars = m_ParkedPersonalCarQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity car in cars)
            {
                Entity owner = EntityManager.GetComponentData<Game.Vehicles.PersonalCar>(car).m_Keeper;
                if (owner == Entity.Null || !EntityManager.Exists(owner)
                    || !EntityManager.HasComponent<Game.Citizens.HouseholdMember>(owner)) continue;
                Entity household = EntityManager.GetComponentData<Game.Citizens.HouseholdMember>(owner).m_Household;
                if (household == Entity.Null || !EntityManager.Exists(household)
                    || !EntityManager.HasBuffer<Game.Economy.Resources>(household)) continue;
                DynamicBuffer<Game.Economy.Resources> resources = EntityManager.GetBuffer<Game.Economy.Resources>(household, true);
                for (int i = 0; i < resources.Length; i++)
                    if (resources[i].m_Resource == Game.Economy.Resource.Money && resources[i].m_Amount > 0)
                    {
                        eligible.Add(car);
                        break;
                    }
            }
            if (eligible.Count == 0) return false;

            vehicle = eligible[random.NextInt(eligible.Count)];
            suspect = EntityManager.GetComponentData<Game.Vehicles.PersonalCar>(vehicle).m_Keeper;
            Entity householdEntity = EntityManager.GetComponentData<Game.Citizens.HouseholdMember>(suspect).m_Household;
            DynamicBuffer<Game.Economy.Resources> wallet = EntityManager.GetBuffer<Game.Economy.Resources>(householdEntity);
            for (int i = 0; i < wallet.Length; i++)
            {
                Game.Economy.Resources balance = wallet[i];
                if (balance.m_Resource != Game.Economy.Resource.Money || balance.m_Amount <= 0) continue;
                stolenCash = math.min(balance.m_Amount, random.NextInt(80, 501));
                balance.m_Amount -= stolenCash;
                wallet[i] = balance;
                return stolenCash > 0;
            }
            return false;
        }

        private string DistrictLandmark(Entity vehicle)
        {
            if (EntityManager.HasComponent<Game.Citizens.CurrentBuilding>(EntityManager.GetComponentData<Game.Vehicles.PersonalCar>(vehicle).m_Keeper))
            {
                Entity building = EntityManager.GetComponentData<Game.Citizens.CurrentBuilding>(EntityManager.GetComponentData<Game.Vehicles.PersonalCar>(vehicle).m_Keeper).m_CurrentBuilding;
                string landmark = building != Entity.Null && EntityManager.Exists(building) ? m_NameSystem.GetRenderedLabelName(building) : null;
                if (!string.IsNullOrWhiteSpace(landmark)) return landmark;
            }
            return CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, vehicle);
        }
    }
}
