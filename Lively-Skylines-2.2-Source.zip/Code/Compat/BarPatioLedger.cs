using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace BarRush
{
    /// <summary>Map overlays for patio seating and short queues outside bars.</summary>
    public static class BarPatioLedger
    {
        public sealed class Patio
        {
            public float X;
            public float Z;
            public string Name;
            public string Area;
            public int Seats;
            public int Seated;
            public int Queue;
        }

        private static readonly List<Patio> s_Patios = new List<Patio>();

        public static void Replace(List<Patio> patios)
        {
            s_Patios.Clear();
            s_Patios.AddRange(patios);
        }

        public static void AppendMapRows(StringBuilder rows)
        {
            foreach (Patio patio in s_Patios)
            {
                rows.Append("T|").Append(patio.X.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(patio.Z.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(Clean(patio.Name)).Append('|').Append(Clean(patio.Area)).Append('|')
                    .Append(patio.Seats).Append('|').Append(patio.Seated).Append('|').Append(patio.Queue).AppendLine();
            }
        }

        private static string Clean(string value) => (value ?? string.Empty).Replace('|', '/').Replace('\r', ' ').Replace('\n', ' ').Trim();
    }
}
