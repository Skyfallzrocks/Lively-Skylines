using System.Collections.Generic;
using System.Globalization;
using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Modeled ALPR pass-by log. Watchlist matches are fictional and do not alter native crime state.</summary>
    public sealed class AlprPassBySystem : GameSystemBase
    {
        private const float kCameraRange = 125f;
        private const uint kVehicleCooldown = 96u;
        private const int kMaxPasses = 100;
        private EntityQuery m_CarQuery;
        private SimulationSystem m_Simulation;
        private NameSystem m_Names;
        private readonly Dictionary<Entity, uint> m_LastSeen = new Dictionary<Entity, uint>();
        private readonly HashSet<int> m_FictionalWatchlist = new HashSet<int>();
        private readonly List<PassBy> m_Passes = new List<PassBy>();
        private int m_TotalReads;
        private int m_FlaggedReads;
        private string m_Status = "Place an ALPR camera to begin modeled plate reads.";

        private sealed class PassBy
        {
            public string Plate;
            public string Vehicle;
            public string Area;
            public uint Frame;
            public bool Flagged;
            public string Response;
        }

        protected override void OnCreate()
        {
            base.OnCreate();
            m_Simulation = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_Names = World.GetOrCreateSystemManaged<NameSystem>();
            m_CarQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Vehicles.PersonalCar>(),
                ComponentType.ReadOnly<Game.Vehicles.Controller>(), ComponentType.ReadOnly<Game.Objects.Moving>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Game.Vehicles.ParkedCar>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<Game.Prefabs.PrefabData>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.CrimeReportsEnabled) return;
            List<Unity.Mathematics.float3> cameras = CctvCrimeCoverage.GetAlprPositions(EntityManager);
            if (cameras.Count == 0)
            {
                m_Status = "No ALPR camera placed. Import an Object named Lively ALPR Camera and place it from the CCTV page.";
                return;
            }

            uint frame = m_Simulation.frameIndex;
            var passedThisScan = new HashSet<Entity>();
            using NativeArray<Entity> cars = m_CarQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity vehicle in cars)
            {
                if (m_LastSeen.TryGetValue(vehicle, out uint last) && frame >= last && frame - last < kVehicleCooldown) continue;
                float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(vehicle).m_Position;
                if (!NearCamera(position, cameras)) continue;
                if (!EntityManager.HasComponent<Game.Vehicles.Controller>(vehicle)) continue;
                Entity driver = EntityManager.GetComponentData<Game.Vehicles.Controller>(vehicle).m_Controller;
                if (driver == Entity.Null || !EntityManager.Exists(driver) || !EntityManager.HasComponent<Citizen>(driver)) continue;
                passedThisScan.Add(vehicle);
                m_LastSeen[vehicle] = frame;
                RecordPass(vehicle, driver, position, frame);
            }

            if (m_LastSeen.Count > 4096)
            {
                var stale = new List<Entity>();
                foreach (KeyValuePair<Entity, uint> item in m_LastSeen)
                    if (!EntityManager.Exists(item.Key) || (frame >= item.Value && frame - item.Value > OutingStarter.FramesPerDay)) stale.Add(item.Key);
                foreach (Entity entity in stale) m_LastSeen.Remove(entity);
            }
            m_Status = $"Reading traffic · {cameras.Count} ALPR camera(s) · {m_TotalReads} modeled pass-bys · {m_FlaggedReads} fictional watchlist flags.";
        }

        private void RecordPass(Entity vehicle, Entity driver, float3 position, uint frame)
        {
            int key = vehicle.Index;
            uint mixed = (uint)key * 2654435761u + 2246822519u;
            if (!m_FictionalWatchlist.Contains(key) && mixed % 100u < 8u) m_FictionalWatchlist.Add(key);
            bool flagged = m_FictionalWatchlist.Contains(key);
            string name = m_Names.GetRenderedLabelName(driver);
            if (string.IsNullOrWhiteSpace(name)) name = "Unidentified driver";
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_Names, vehicle);
            if (string.IsNullOrWhiteSpace(area)) area = "City road";
            string plate = $"{(char)('A' + (key % 26))}{(char)('A' + ((key / 7) % 26))}{(char)('A' + ((key / 19) % 26))}-{1000 + (key * 37 % 9000):0000}";
            string response = flagged
                ? (CrimeAreaSystem.HasPoliceStation(GetDistrict(vehicle)) ? "Fictional watchlist match · patrol response logged" : "Fictional watchlist match · no nearby station, response delayed")
                : "Plate read logged · no modeled watchlist match";
            m_TotalReads++;
            if (flagged)
            {
                m_FlaggedReads++;
                Entity incident = EntityManager.CreateEntity();
                string detail = $"ALPR logged generated plate {plate} on the mod's fictional watchlist near {area}. A modeled patrol response was recorded for driver {name}. Native game criminal status is not read or changed.";
                CityCrimeLedger.Record(incident, vehicle, "ALPR traffic check", area, true, false, frame, detail,
                    "ALPR watchlist alert", name, response);
                CityBuzzFeed.Add("ALPR alert", "City traffic cameras", area, detail, frame);
                PublicReactionLedger.Add("Fictional ALPR watchlist match reported", 1);
            }
            m_Passes.Insert(0, new PassBy { Plate = plate, Vehicle = name, Area = area, Frame = frame, Flagged = flagged, Response = response });
            if (m_Passes.Count > kMaxPasses) m_Passes.RemoveRange(kMaxPasses, m_Passes.Count - kMaxPasses);
        }

        private Entity GetDistrict(Entity vehicle) => EntityManager.HasComponent<Game.Areas.CurrentDistrict>(vehicle)
            ? EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(vehicle).m_District : Entity.Null;

        private static bool NearCamera(float3 position, List<float3> cameras)
        {
            float radiusSq = kCameraRange * kCameraRange;
            foreach (float3 camera in cameras)
                if (math.distancesq(new float2(position.x, position.z), new float2(camera.x, camera.z)) <= radiusSq) return true;
            return false;
        }

        public string Rows
        {
            get
            {
                uint frame = m_Simulation == null ? 0 : m_Simulation.frameIndex;
                var rows = new List<string>();
                foreach (PassBy pass in m_Passes)
                {
                    uint elapsed = frame >= pass.Frame ? frame - pass.Frame : 0;
                    string age = elapsed < 64 ? "Just now" : $"{elapsed / 64} ticks ago";
                    rows.Add($"{Clean(pass.Plate)}|{Clean(pass.Vehicle)}|{Clean(pass.Area)}|{(pass.Flagged ? 1 : 0)}|{Clean(pass.Response)}|{age}");
                }
                return string.Join("\n", rows);
            }
        }

        public string Status => m_Status;
        public int TotalReads => m_TotalReads;
        public int FlaggedReads => m_FlaggedReads;

        private static string Clean(string value) => (value ?? "Unknown").Replace("|", "/").Replace("\r", " ").Replace("\n", " ");
    }
}
