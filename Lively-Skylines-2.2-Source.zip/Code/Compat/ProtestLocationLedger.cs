using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Session-only map locations for fictional peaceful civic gathering alerts.</summary>
    public static class ProtestLocationLedger
    {
        private struct Entry
        {
            public float X;
            public float Z;
            public string Place;
            public string Area;
            public uint Frame;
            public int Turnout;
        }

        private static readonly List<Entry> s_Entries = new List<Entry>();

        public static void Record(EntityManager entityManager, Entity location, string place, string area, uint frame, int turnout)
        {
            if (location == Entity.Null || !entityManager.Exists(location)
                || !entityManager.HasComponent<Game.Objects.Transform>(location)) return;
            Unity.Mathematics.float3 position = entityManager.GetComponentData<Game.Objects.Transform>(location).m_Position;
            s_Entries.Add(new Entry { X = position.x, Z = position.z, Place = Clean(place), Area = Clean(area), Frame = frame, Turnout = turnout });
            if (s_Entries.Count > 100) s_Entries.RemoveAt(0);
        }

        public static void AppendMapRows(StringBuilder rows)
        {
            foreach (Entry entry in s_Entries)
            {
                rows.Append("P|").Append(entry.X.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(entry.Z.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(entry.Place).Append(" · ").Append(entry.Turnout).Append(" gathered").Append('|').Append(entry.Area).Append('|').Append(entry.Frame).AppendLine();
            }
        }

        private static string Clean(string value) => (value ?? string.Empty).Replace('|', '/').Replace('\r', ' ').Replace('\n', ' ').Trim();
    }
}
