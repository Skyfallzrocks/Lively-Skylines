namespace BarRush
{
    /// <summary>Fictional, session-only civic mood that lets disruptive reports influence protest stories.</summary>
    public static class PublicReactionLedger
    {
        public static int Anger { get; private set; }
        public static string LatestCause { get; private set; } = "No major public grievance reported";

        public static void Add(string cause, int amount)
        {
            Anger = Unity.Mathematics.math.clamp(Anger + amount, 0, 100);
            LatestCause = CityText.Clean(cause);
        }

        public static void ProtestOccurred()
        {
            Anger = Unity.Mathematics.math.max(0, Anger - 18);
        }
    }
}
