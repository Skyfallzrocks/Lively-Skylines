using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Game.Objects;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Session-side designations for voluntary housing and street-outreach programs.</summary>
    public static class HomelessProgramsLedger
    {
        public const int Shelter = 0;
        public const int CodeBlue = 1;
        public const int GreenZone = 2;

        public sealed class Site
        {
            public Entity Building;
            public string Name;
            public string District;
            public int Type;
            public int Capacity;
            public int PeopleServed;
            public int Visits;
        }

        private static readonly List<Site> s_Sites = new List<Site>();
        public static IReadOnlyList<Site> Sites => s_Sites;
        public static bool CodeBlueWinterActive { get; private set; }
        public static bool NeedleShareEnabled { get; private set; }
        public static int MobileTruckCount { get; private set; }
        public static int EncampmentResidents { get; private set; }
        public static int OutreachVisits { get; private set; }
        public static int NeedleExchanges { get; private set; }
        public static int TotalCapacity
        {
            get
            {
                int capacity = 0;
                foreach (Site site in s_Sites) if (IsActive(site)) capacity += site.Capacity;
                return capacity;
            }
        }
        public static string Status { get; private set; } = "Choose existing city buildings to assign local outreach programs.";

        public static int TypeFor(Entity building)
        {
            Site site = Find(building);
            return site == null ? -1 : site.Type;
        }

        public static bool Designate(Entity building, string name, string district, int type)
        {
            if (building == Entity.Null || type < Shelter || type > GreenZone) return false;
            Site site = Find(building);
            if (site == null)
            {
                site = new Site { Building = building };
                s_Sites.Add(site);
            }
            site.Name = name ?? "City property";
            site.District = district ?? "City district";
            site.Type = type;
            site.Capacity = type == Shelter ? 40 : type == CodeBlue ? 24 : 18;
            Status = $"{TypeName(type)} designated at {site.Name}. The building itself is unchanged.";
            return true;
        }

        public static bool Remove(Entity building)
        {
            Site site = Find(building);
            if (site == null) return false;
            s_Sites.Remove(site);
            Status = $"Program designation removed from {site.Name}.";
            return true;
        }

        public static void SetOption(int option, int value)
        {
            if (option == 0)
            {
                NeedleShareEnabled = value != 0;
                Status = NeedleShareEnabled ? "Needle share service is open for voluntary visits." : "Needle share service is paused.";
            }
            else if (option == 1)
            {
                CodeBlueWinterActive = value != 0;
                Status = CodeBlueWinterActive ? "Winter Code Blue response is active. Turn it off when winter conditions end." : "Winter Code Blue response is inactive.";
            }
            else if (option == 2)
            {
                MobileTruckCount = Unity.Mathematics.math.clamp(value, 0, 8);
                Status = MobileTruckCount == 0 ? "Mobile harm-prevention fleet is parked." : $"{MobileTruckCount} mobile harm-prevention truck(s) are available for outreach.";
            }
        }

        public static bool IsActive(Site site)
        {
            return site != null && (site.Type != CodeBlue || CodeBlueWinterActive);
        }

        public static void SetUnhousedResidentCount(int residents)
        {
            EncampmentResidents = Unity.Mathematics.math.max(0, residents);
        }

        public static void RecordNightOutreach(int residents, int frameSeed)
        {
            EncampmentResidents = residents;
            if (residents <= 0 || MobileTruckCount <= 0) return;
            int visits = Unity.Mathematics.math.min(residents, MobileTruckCount * 8);
            OutreachVisits += visits;
            foreach (Site site in s_Sites)
                if (IsActive(site)) site.Visits += 1;
            if (NeedleShareEnabled)
            {
                int exchanges = Unity.Mathematics.math.min(residents, Unity.Mathematics.math.max(1, MobileTruckCount * 3));
                NeedleExchanges += exchanges;
            }
            Status = $"Mobile teams completed {visits} voluntary outreach visits. Needle exchange is {(NeedleShareEnabled ? "open" : "paused").ToLowerInvariant()}.";
        }

        public static void RecordSites(List<Site> sites)
        {
            for (int i = 0; i < s_Sites.Count; i++) s_Sites[i].PeopleServed = 0;
            if (sites == null) return;
            foreach (Site site in sites)
            {
                Site stored = Find(site.Building);
                if (stored != null) stored.PeopleServed = site.PeopleServed;
            }
        }

        public static string CandidateTypeRows(List<Entity> candidates)
        {
            var rows = new StringBuilder();
            if (candidates == null) return string.Empty;
            for (int i = 0; i < candidates.Count; i++)
                rows.Append(i).Append('|').Append(TypeFor(candidates[i])).AppendLine();
            return rows.ToString().TrimEnd('\r', '\n');
        }

        public static void AppendMapRows(StringBuilder rows, EntityManager entityManager)
        {
            foreach (Site site in s_Sites)
            {
                if (!IsActive(site) || site.Building == Entity.Null || !entityManager.Exists(site.Building) ||
                    !entityManager.HasComponent<Transform>(site.Building)) continue;
                Unity.Mathematics.float3 position = entityManager.GetComponentData<Transform>(site.Building).m_Position;
                rows.Append("H|").Append(position.x.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(position.z.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(Clean($"{TypeName(site.Type)} · {site.Name}")).Append('|')
                    .Append(Clean(site.District)).Append('|').Append(site.Capacity).AppendLine();
            }
        }

        public static void CollectActiveBuildings(EntityManager entityManager, List<Entity> buildings)
        {
            if (buildings == null) return;
            buildings.Clear();
            foreach (Site site in s_Sites)
                if (IsActive(site) && site.Building != Entity.Null && entityManager.Exists(site.Building) &&
                    entityManager.HasComponent<Transform>(site.Building)) buildings.Add(site.Building);
        }

        public static string SiteRows(EntityManager entityManager)
        {
            var rows = new StringBuilder();
            for (int i = 0; i < s_Sites.Count; i++)
            {
                Site site = s_Sites[i];
                string status = site.Building != Entity.Null && entityManager.Exists(site.Building)
                    ? (IsActive(site) ? "Open" : "Winter only · inactive") : "Building unavailable";
                rows.Append(i).Append('|').Append(Clean(site.Name)).Append('|').Append(Clean(site.District)).Append('|')
                    .Append(site.Type).Append('|').Append(site.Capacity).Append('|').Append(site.PeopleServed).Append('|')
                    .Append(site.Visits).Append('|').Append(status).AppendLine();
            }
            return rows.ToString().TrimEnd('\r', '\n');
        }

        public static string Summary => $"{s_Sites.Count}|{EncampmentResidents}|{OutreachVisits}|{NeedleExchanges}|{MobileTruckCount}|{(NeedleShareEnabled ? 1 : 0)}|{(CodeBlueWinterActive ? 1 : 0)}";

        public static string TypeName(int type) => type == Shelter ? "Homeless shelter" : type == CodeBlue ? "Code Blue · winter" : "Green camping zone";

        private static Site Find(Entity building)
        {
            for (int i = 0; i < s_Sites.Count; i++) if (s_Sites[i].Building == building) return s_Sites[i];
            return null;
        }

        private static string Clean(string value) => (value ?? string.Empty).Replace('|', '/').Replace('\r', ' ').Replace('\n', ' ').Trim();
    }
}
