using System.Collections.Generic;
using Game.Buildings;
using Game.Companies;
using Game.Economy;
using Game.Prefabs;
using Unity.Collections;
using Unity.Entities;

namespace BarRush
{
    public static class BarFinder
    {
        public static EntityQuery CreateCompanyQuery(EntityManager em) => em.CreateEntityQuery(
            ComponentType.ReadOnly<CommercialCompany>(),
            ComponentType.ReadOnly<PropertyRenter>(),
            ComponentType.Exclude<Game.Common.Deleted>(),
            ComponentType.Exclude<Game.Tools.Temp>());

        public static bool IsBar(EntityManager em, Entity company)
        {
            if (!em.HasComponent<PrefabRef>(company)) return false;
            Entity prefab = em.GetComponentData<PrefabRef>(company).m_Prefab;
            return em.HasComponent<IndustrialProcessData>(prefab)
                && em.GetComponentData<IndustrialProcessData>(prefab).m_Output.m_Resource == Resource.Entertainment;
        }

        public static bool IsNightclub(Entity company)
        {
            // A stable, city-specific split: about one in six entertainment
            // businesses gets nightclub identity without changing its prefab.
            uint hash = unchecked((uint)company.Index * 2654435761u + (uint)company.Version * 2246822519u);
            return hash % 6u == 0u;
        }

        public static void CollectBarBuildings(EntityManager em, EntityQuery query, List<Entity> buildings)
        {
            buildings.Clear();
            using NativeArray<Entity> companies = query.ToEntityArray(Allocator.Temp);
            foreach (Entity company in companies)
            {
                if (!IsBar(em, company)) continue;
                Entity building = em.GetComponentData<PropertyRenter>(company).m_Property;
                if (building != Entity.Null && em.Exists(building)) buildings.Add(building);
            }
        }

        public static void CollectBarCompanies(EntityManager em, EntityQuery query, List<Entity> companies)
        {
            companies.Clear();
            using NativeArray<Entity> all = query.ToEntityArray(Allocator.Temp);
            foreach (Entity company in all) if (IsBar(em, company)) companies.Add(company);
        }

        /// <summary>
        /// Picks a tiny, deterministic set of local bars as DIY music venues.
        /// Keep the set small so music venue identity stays special in large cities.
        /// </summary>
        public static void CollectDIYMusicVenueBuildings(EntityManager em, EntityQuery query, List<Entity> buildings)
        {
            buildings.Clear();
            var candidates = new List<KeyValuePair<uint, Entity>>();
            using NativeArray<Entity> companies = query.ToEntityArray(Allocator.Temp);
            foreach (Entity company in companies)
            {
                if (!IsBar(em, company)) continue;
                Entity building = em.GetComponentData<PropertyRenter>(company).m_Property;
                if (building == Entity.Null || !em.Exists(building)) continue;
                uint hash = unchecked((uint)company.Index * 2654435761u + (uint)company.Version * 2246822519u);
                candidates.Add(new KeyValuePair<uint, Entity>(hash, building));
            }
            candidates.Sort((a, b) => a.Key.CompareTo(b.Key));
            int count = System.Math.Min(2, candidates.Count);
            for (int i = 0; i < count; i++) buildings.Add(candidates[i].Value);
        }

        public static bool IsDIYMusicVenue(Entity building, List<Entity> venues)
        {
            for (int i = 0; i < venues.Count; i++)
                if (venues[i] == building) return true;
            return false;
        }

        public static Entity FindBarCompany(EntityManager em, EntityQuery query, Entity building)
        {
            using NativeArray<Entity> companies = query.ToEntityArray(Allocator.Temp);
            foreach (Entity company in companies)
                if (em.GetComponentData<PropertyRenter>(company).m_Property == building && IsBar(em, company)) return company;
            return Entity.Null;
        }
    }
}
