using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Game.Common;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Session crime reports, deduplicated by the game's incident entity.</summary>
    public static class CityCrimeLedger
    {
        private struct Report
        {
            public Entity Incident;
            public Entity Building;
            public string Place;
            public string Area;
            public string Details;
            public uint Frame;
            public bool AtBar;
            public bool CompanyChanged;
            public bool Hidden;
            public bool PoliceStationInArea;
            public string CrimeType;
            public string Suspect;
            public string PoliceResponse;
        }

        private const int kMaxReports = 300;
        private static readonly List<Report> s_Reports = new List<Report>();
        private static readonly HashSet<Entity> s_Seen = new HashSet<Entity>();
        private static bool s_HasFrame;
        private static uint s_LastFrame;

        public static void Record(Entity incident, Entity building, string place, string area, bool policeStationInArea, bool atBar, uint frame, string details = null, string crimeType = null, string suspect = null, string policeResponse = null)
        {
            SyncFrame(frame);
            if (incident == Entity.Null || !s_Seen.Add(incident)) return;
            string normalizedCrimeType = Clean(crimeType ?? "Crime");
            int grievance = normalizedCrimeType.IndexOf("shooting", System.StringComparison.OrdinalIgnoreCase) >= 0
                || normalizedCrimeType.IndexOf("stabbing", System.StringComparison.OrdinalIgnoreCase) >= 0 ? 6 : 2;
            PublicReactionLedger.Add($"Reported {normalizedCrimeType.ToLowerInvariant()}", grievance);
            s_Reports.Insert(0, new Report
            {
                Incident = incident,
                Building = building,
                Place = Clean(place),
                Area = Clean(area),
                Details = Clean(details ?? (atBar ? "Police responded to a reported crime at this venue." : "Police responded to a reported crime in this area.")),
                Frame = frame,
                AtBar = atBar,
                PoliceStationInArea = policeStationInArea,
                CompanyChanged = false,
                CrimeType = normalizedCrimeType,
                Suspect = Clean(suspect ?? "Unknown"),
                PoliceResponse = Clean(policeResponse ?? (policeStationInArea ? "Police response reported" : "No nearby station · response delayed")),
            });

            GetawayQueue.Report(building, Clean(area), normalizedCrimeType, Clean(suspect ?? "Unknown"), policeStationInArea, frame);

            if (s_Reports.Count > kMaxReports)
            {
                for (int i = kMaxReports; i < s_Reports.Count; i++) s_Seen.Remove(s_Reports[i].Incident);
                s_Reports.RemoveRange(kMaxReports, s_Reports.Count - kMaxReports);
            }
        }

        public static void MarkCompanyChanged(Entity incident)
        {
            for (int i = 0; i < s_Reports.Count; i++)
            {
                if (s_Reports[i].Incident != incident) continue;
                Report report = s_Reports[i];
                report.CompanyChanged = true;
                report.Details = "Crime reported; the venue changed companies afterward.";
                s_Reports[i] = report;
                return;
            }
        }

        public static string Summary(uint frame)
        {
            SyncFrame(frame);
            uint week = OutingStarter.FramesPerDay * 7u;
            int total = 0;
            int atBars = 0;
            var changed = new HashSet<Entity>();
            var countsByPlace = new Dictionary<string, int>();
            foreach (Report report in s_Reports)
            {
                if (report.Hidden) continue;
                if (frame < report.Frame || frame - report.Frame > week) continue;
                total++;
                if (report.AtBar) atBars++;
                if (report.AtBar && report.CompanyChanged) changed.Add(report.Building);
                countsByPlace.TryGetValue(report.Place, out int count);
                countsByPlace[report.Place] = count + 1;
            }

            string most = "None reported";
            int highest = 0;
            foreach (KeyValuePair<string, int> item in countsByPlace)
            {
                if (item.Value <= highest) continue;
                most = item.Key;
                highest = item.Value;
            }
            int population = CrimeAreaSystem.CityPopulation;
            float perThousand = population > 0 ? (float)total * 1000f / population : 0f;
            int areasWithoutPolice = 0;
            foreach (Report report in s_Reports)
                if (!report.Hidden && frame >= report.Frame && frame - report.Frame <= week && !report.PoliceStationInArea) areasWithoutPolice++;
            return $"{total}|{atBars}|{changed.Count}|{most}|{perThousand.ToString("0.0", CultureInfo.InvariantCulture)}|{areasWithoutPolice}";
        }

        public static float WeeklyPerThousand(uint frame)
        {
            SyncFrame(frame);
            uint week = OutingStarter.FramesPerDay * 7u;
            int total = 0;
            foreach (Report report in s_Reports)
                if (!report.Hidden && frame >= report.Frame && frame - report.Frame <= week) total++;
            int population = CrimeAreaSystem.CityPopulation;
            return population > 0 ? (float)total * 1000f / population : 0f;
        }

        public static int CountInArea(string area, uint frame)
        {
            if (string.IsNullOrWhiteSpace(area) || area == "Unassigned turf") return 0;
            SyncFrame(frame);
            uint week = OutingStarter.FramesPerDay * 7u;
            int total = 0;
            foreach (Report report in s_Reports)
                if (!report.Hidden && report.Area == area && frame >= report.Frame && frame - report.Frame <= week) total++;
            return total;
        }

        public static bool HasRecentThreatAt(Entity building, uint frame)
        {
            if (building == Entity.Null) return false;
            SyncFrame(frame);
            uint recentWindow = OutingStarter.FramesPerDay * 3u;
            foreach (Report report in s_Reports)
                if (!report.Hidden && report.Building == building && frame >= report.Frame && frame - report.Frame <= recentWindow)
                    return true;
            return false;
        }

        public static void AppendMapRows(StringBuilder rows, EntityManager entityManager)
        {
            foreach (Report report in s_Reports)
            {
                if (report.Hidden || report.Building == Entity.Null || !entityManager.Exists(report.Building)
                    || !entityManager.HasComponent<Game.Objects.Transform>(report.Building)) continue;
                Unity.Mathematics.float3 position = entityManager.GetComponentData<Game.Objects.Transform>(report.Building).m_Position;
                rows.Append("C|").Append(position.x.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(position.z.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(Clean(report.Place)).Append('|').Append(Clean(report.Details)).Append('|')
                    .Append(Clean(report.Area)).Append('|').Append(Clean(report.CrimeType)).Append('|').Append(report.Frame).AppendLine();
            }
        }

        // Row format: incidentIndex|incidentVersion|place|details|age|isBar|companyChanged|area|stationPresent|crimeType|suspect|response|frame
        public static string Rows(uint frame, string filter)
        {
            SyncFrame(frame);
            var rows = new List<string>();
            foreach (Report report in s_Reports)
            {
                if (report.Hidden) continue;
                bool changed = report.AtBar && report.CompanyChanged;
                if (filter == "Bars" && !report.AtBar) continue;
                if (filter == "Citywide" && report.AtBar) continue;
                if (filter == "Sold" && !changed) continue;
                if (filter == "Still open" && changed) continue;
                string age = Age(frame, report.Frame);
                rows.Add($"{report.Incident.Index}|{report.Incident.Version}|{Clean(report.Place)}|{Clean(report.Details)}|{age}|{(report.AtBar ? "1" : "0")}|{(changed ? "1" : "0")}|{Clean(report.Area)}|{(report.PoliceStationInArea ? "1" : "0")}|{Clean(report.CrimeType)}|{Clean(report.Suspect)}|{Clean(report.PoliceResponse)}|{report.Frame}");
                if (rows.Count >= 300) break;
            }
            return string.Join("\n", rows);
        }

        public static bool Contains(Entity incident)
        {
            foreach (Report report in s_Reports)
                if (report.Incident == incident && !report.Hidden) return true;
            return false;
        }

        public static bool Hide(Entity incident)
        {
            for (int i = 0; i < s_Reports.Count; i++)
            {
                if (s_Reports[i].Incident != incident || s_Reports[i].Hidden) continue;
                Report report = s_Reports[i];
                report.Hidden = true;
                s_Reports[i] = report;
                CityBuzzFeed.HideIncident(incident);
                return true;
            }
            return false;
        }

        private static string Age(uint frame, uint reported)
        {
            uint hours = OutingStarter.FramesPerDay / 24u;
            uint elapsed = frame >= reported ? frame - reported : 0u;
            if (elapsed < hours) return "Just now";
            if (elapsed < OutingStarter.FramesPerDay) return $"{elapsed / hours} in-game hours ago";
            uint days = elapsed / OutingStarter.FramesPerDay;
            return days == 1 ? "Yesterday" : $"{days} in-game days ago";
        }

        private static string Clean(string value) => (value ?? "Unknown location").Replace("|", "/").Replace("\r", " ").Replace("\n", " ");

        private static void SyncFrame(uint frame)
        {
            if (s_HasFrame && frame < s_LastFrame)
            {
                s_Reports.Clear();
                s_Seen.Clear();
            }
            s_HasFrame = true;
            s_LastFrame = frame;
        }
    }
}
