using System.Collections.Generic;
using Game;
using Game.City;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    public enum ScandalResolution
    {
        CloseVenue,
        CoverUp,
    }

    public static class UnderageSalesQueue
    {
        public struct Request
        {
            public Entity Building;
            public ScandalResolution Resolution;
        }

        private static readonly Queue<Request> s_Requests = new Queue<Request>();
        private static bool s_Queued;
        public static void Enqueue(Entity building, ScandalResolution resolution)
        {
            if (s_Queued) return;
            s_Queued = true;
            s_Requests.Enqueue(new Request { Building = building, Resolution = resolution });
        }
        public static bool TryDequeue(out Request request)
        {
            if (s_Requests.Count == 0) { request = default; return false; }
            request = s_Requests.Dequeue();
            s_Queued = false;
            return true;
        }
    }

    /// <summary>Rare fictional compliance incidents and city responses for nightlife businesses.</summary>
    public partial class UnderageSalesSystem : GameSystemBase
    {
        private const int kCloseCost = 75000;
        private const int kCoverUpCost = 150000;
        private const float kIncidentCheckTime = 22f / 24f;
        private CitySystem m_CitySystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private EntityQuery m_CompanyQuery;
        private float m_PreviousTime = -1f;
        private readonly List<Entity> m_Companies = new List<Entity>();
        private readonly HashSet<Entity> m_IncidentCompanies = new HashSet<Entity>();

        protected override void OnCreate()
        {
            base.OnCreate();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.UnderageSalesEnabled) return;
            float now = m_TimeSystem.normalizedTime;
            bool incidentTime = m_PreviousTime >= 0f && m_PreviousTime < kIncidentCheckTime && now >= kIncidentCheckTime;
            m_PreviousTime = now;
            if (incidentTime) MaybeCreateIncident();
            while (UnderageSalesQueue.TryDequeue(out UnderageSalesQueue.Request request)) Resolve(request);
        }

        private void MaybeCreateIncident()
        {
            uint frame = World.GetOrCreateSystemManaged<SimulationSystem>().frameIndex;
            var random = new Random(math.max(1u, frame * 3266489917u + 0x6D2B79F5u));
            if (random.NextInt(100) >= 4) return; // Rare citywide incident, about four nights in a hundred.
            BarFinder.CollectBarCompanies(EntityManager, m_CompanyQuery, m_Companies);
            if (m_Companies.Count == 0) return;

            int start = random.NextInt(m_Companies.Count);
            Entity company = Entity.Null;
            for (int offset = 0; offset < m_Companies.Count; offset++)
            {
                Entity candidate = m_Companies[(start + offset) % m_Companies.Count];
                if (m_IncidentCompanies.Add(candidate)) { company = candidate; break; }
            }
            if (company == Entity.Null) return;

            Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
            string name = m_NameSystem.GetRenderedLabelName(company);
            if (string.IsNullOrEmpty(name)) name = "a local bar";
            bool discovered = random.NextInt(100) < 35;
            if (discovered)
            {
                BarCaseLedger.Record(building);
                CityBuzzFeed.Add("Case", "City report", name, "A report about underage sales surfaced at this venue.", frame);
            }
            DjAnnouncement.EnqueueUnderageSalesScandal(name, building, discovered);
            Mod.log.Info(discovered
                ? $"Underage-sales incident reported at {name}; city response choices shown."
                : $"Underage-sales incident at {name} went undiscovered.");
        }

        public static void QueueResolution(Entity building, bool closeVenue)
        {
            if (building == Entity.Null) return;
            UnderageSalesQueue.Enqueue(building, closeVenue ? ScandalResolution.CloseVenue : ScandalResolution.CoverUp);
        }

        private void Resolve(UnderageSalesQueue.Request request)
        {
            if (request.Building == Entity.Null || !EntityManager.Exists(request.Building))
            {
                DjAnnouncement.SetScandalActionError("The venue is no longer available.");
                return;
            }

            bool close = request.Resolution == ScandalResolution.CloseVenue;
            int cost = close ? kCloseCost : kCoverUpCost;
            if (!CanAfford(cost))
            {
                DjAnnouncement.SetScandalActionError($"The city needs ${cost:N0} to take that action.");
                return;
            }

            Entity company = BarFinder.FindBarCompany(EntityManager, m_CompanyQuery, request.Building);
            if (company == Entity.Null)
            {
                DjAnnouncement.SetScandalActionError("This venue no longer has a bar company.");
                return;
            }

            Charge(cost);
            if (close)
            {
                EntityManager.AddComponent<Deleted>(company);
                DjAnnouncement.SetScandalResolved($"The city paid $75,000 to close the venue. The building can seek a new tenant.");
            }
            else
            {
                BarCaseLedger.ClearOne(request.Building);
                DjAnnouncement.SetScandalResolved("The city paid $150,000 to suppress the report. The case was removed from the public tally.");
            }
        }

        private bool CanAfford(int amount)
        {
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city)) return false;
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            return money.m_Unlimited || money.money >= amount;
        }

        private void Charge(int amount)
        {
            Entity city = m_CitySystem.City;
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            money.Subtract(amount);
            EntityManager.SetComponentData(city, money);
        }
    }
}
