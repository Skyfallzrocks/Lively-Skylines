using System.Collections.Generic;
using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Maps homeless residents to stable encampments and periodically routes a small group to outdoor public spaces.</summary>
    public partial class HomelessBarOutreachSystem : GameSystemBase
    {
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private EntityQuery m_CitizenQuery;
        private EntityQuery m_PopulationQuery;
        private EntityQuery m_EncampmentBuildingQuery;
        private EntityQuery m_CompanyQuery;
        private NameSystem m_NameSystem;
        private readonly List<Entity> m_Bars = new List<Entity>();
        private readonly List<Entity> m_EncampmentSites = new List<Entity>();
        private float m_PreviousTime = -1f;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<HouseholdMember>(),
                ComponentType.ReadOnly<CurrentBuilding>(), ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_EncampmentBuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Buildings.Building>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 128;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.HomelessOutreachEnabled) return;
            float now = m_TimeSystem.normalizedTime;
            bool evening = m_PreviousTime >= 0f && m_PreviousTime < 0.75f && now >= 0.75f;
            m_PreviousTime = now;
            if (evening) RouteHomelessResidentsToOutdoorSpaces();
        }

        private void RouteHomelessResidentsToOutdoorSpaces()
        {
            uint frame = m_SimulationSystem.frameIndex;
            int population = m_PopulationQuery.CalculateEntityCount();
            if (population <= 0) return;
            using NativeArray<Entity> candidates = m_CitizenQuery.ToEntityArray(Allocator.Temp);
            var homeless = new List<Entity>();
            foreach (Entity citizen in candidates)
            {
                Entity household = EntityManager.GetComponentData<HouseholdMember>(citizen).m_Household;
                if (household != Entity.Null && EntityManager.Exists(household) && EntityManager.HasComponent<HomelessHousehold>(household))
                    homeless.Add(citizen);
            }
            if (homeless.Count == 0)
            {
                HomelessEncampmentLedger.Clear(frame);
                return;
            }

            UpdateEncampments(homeless.Count, frame);
            HomelessProgramsLedger.RecordNightOutreach(homeless.Count, (int)frame);

            if (m_EncampmentSites.Count == 0) return;
            BarFinder.CollectBarBuildings(EntityManager, m_CompanyQuery, m_Bars);

            // Keep movement small. Route residents to the same real building
            // entities that anchor the mod's Civic Map encampment markers, with
            // a smaller share visiting existing bars. No park fallback is used.
            int cap = PopulationCap.MaxAttendees(population, Mod.Settings.MaxAttendancePercent);
            int maxVisitors = math.min(math.max(1, homeless.Count / 20), math.max(1, population / 200));
            int allowed = math.min(maxVisitors, AttendanceLedger.Remaining(cap, frame));
            if (allowed <= 0) return;

            var random = new Random(math.max(1u, frame * 3266489917u));
            uint duration = OutingStarter.FramesPerDay / 8u;
            int routed = 0;
            for (int i = homeless.Count - 1; i > 0; i--)
            {
                int swap = random.NextInt(i + 1);
                (homeless[i], homeless[swap]) = (homeless[swap], homeless[i]);
            }
            for (int i = 0; i < homeless.Count && routed < allowed; i++)
            {
                Entity citizen = homeless[i];
                bool visitBar = m_Bars.Count > 0 && random.NextInt(100) < 30;
                Entity destination = visitBar ? m_Bars[random.NextInt(m_Bars.Count)] : m_EncampmentSites[random.NextInt(m_EncampmentSites.Count)];
                if (!EntityManager.Exists(citizen) || !EntityManager.Exists(destination)) continue;
                EntityManager.AddComponentData(citizen, new Leisure
                {
                    m_TargetAgent = destination,
                    m_LastPossibleFrame = frame + duration,
                });
                routed++;
            }
            AttendanceLedger.Add(routed, frame + duration);
            if (routed > 0)
            {
                if (random.NextInt(100) < 35)
                {
                    bool atBar = m_Bars.Count > 0 && random.NextInt(100) < 30;
                    Entity destination = atBar ? m_Bars[random.NextInt(m_Bars.Count)] : m_EncampmentSites[random.NextInt(m_EncampmentSites.Count)];
                    string place = m_NameSystem.GetRenderedLabelName(destination);
                    if (string.IsNullOrWhiteSpace(place)) place = atBar ? "a neighborhood bar" : "a mapped encampment site";
                    CityBuzzFeed.Add("Community", atBar ? "Bar outreach" : "Encampment update", place,
                        atBar ? "A small group of unhoused residents visited this bar area during an outing. Encampment markers on Civic Map show approximate mod-managed locations." : "Residents returned to a mod-managed encampment site shown on Civic Map. These map locations are used for the mod's outdoor routing.", frame);
                }
                Mod.log.Info($"Routed {routed} unhoused residents to mod-managed encampment sites and local bars ({homeless.Count} unhoused citizens / {population} residents).");
            }
        }

        private void UpdateEncampments(int homelessCount, uint frame)
        {
            using NativeArray<Entity> buildings = m_EncampmentBuildingQuery.ToEntityArray(Allocator.Temp);
            if (buildings.Length == 0)
            {
                HomelessEncampmentLedger.Clear(frame);
                m_EncampmentSites.Clear();
                return;
            }

            var random = new Random(math.max(1u, frame * 2246822519u + 3266489917u));
            int desiredGroupCount = math.clamp((homelessCount + 29) / 30, 1, 8);
            // Outreach designations anchor the same map locations used for nightly
            // resident routing. If no program has been designated, retain the prior
            // approximate citywide encampment model.
            var availableSites = new List<Entity>(buildings.Length);
            HomelessProgramsLedger.CollectActiveBuildings(EntityManager, availableSites);
            bool designatedSites = availableSites.Count > 0;
            if (!designatedSites)
            {
            foreach (Entity building in buildings)
            {
                if (EntityManager.Exists(building) && EntityManager.HasComponent<Game.Objects.Transform>(building))
                    availableSites.Add(building);
            }
            }
            if (availableSites.Count == 0)
            {
                HomelessEncampmentLedger.Clear(frame);
                m_EncampmentSites.Clear();
                return;
            }

            int groupCount = math.min(desiredGroupCount, availableSites.Count);
            List<HomelessEncampmentLedger.Encampment> existing = HomelessEncampmentLedger.CopyEntries(frame);
            bool sitesAvailable = m_EncampmentSites.Count == groupCount;
            if (sitesAvailable)
            {
                for (int i = 0; i < m_EncampmentSites.Count; i++)
                {
                    if ((designatedSites && m_EncampmentSites[i] != availableSites[i]) || !EntityManager.Exists(m_EncampmentSites[i]) ||
                        !EntityManager.HasComponent<Game.Objects.Transform>(m_EncampmentSites[i]))
                    {
                        sitesAvailable = false;
                        break;
                    }
                }
            }
            if (sitesAvailable && existing.Count == groupCount)
            {
                int existingBaseResidents = homelessCount / groupCount;
                int existingRemainder = homelessCount % groupCount;
                for (int i = 0; i < existing.Count; i++) existing[i].Residents = existingBaseResidents + (i < existingRemainder ? 1 : 0);
                HomelessEncampmentLedger.Replace(existing, frame);
                return;
            }

            var entries = new List<HomelessEncampmentLedger.Encampment>(groupCount);
            var selectedSites = new List<Entity>(groupCount);
            var usedDistricts = new HashSet<string>();
            if (designatedSites)
            {
                for (int i = 0; i < groupCount; i++) selectedSites.Add(availableSites[i]);
            }
            else
            {
                for (int i = availableSites.Count - 1; i > 0; i--)
                {
                    int swap = random.NextInt(i + 1);
                    (availableSites[i], availableSites[swap]) = (availableSites[swap], availableSites[i]);
                }

                // Prefer distinct districts so map zones spread across the city.
                foreach (Entity building in availableSites)
                {
                    string district = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                    if (string.IsNullOrWhiteSpace(district)) district = "Citywide area";
                    if (usedDistricts.Add(district))
                    {
                        selectedSites.Add(building);
                        if (selectedSites.Count >= groupCount) break;
                    }
                }
                if (selectedSites.Count < groupCount)
                {
                    foreach (Entity building in availableSites)
                    {
                        if (selectedSites.Contains(building)) continue;
                        selectedSites.Add(building);
                        if (selectedSites.Count >= groupCount) break;
                    }
                }
            }

            int baseResidents = homelessCount / groupCount;
            int remainder = homelessCount % groupCount;
            for (int i = 0; i < selectedSites.Count; i++)
            {
                Entity anchor = selectedSites[i];
                string district = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, anchor);
                if (string.IsNullOrWhiteSpace(district)) district = "Citywide area";
                string place = m_NameSystem.GetRenderedLabelName(anchor);
                if (string.IsNullOrWhiteSpace(place)) place = district;
                Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(anchor).m_Position;
                entries.Add(new HomelessEncampmentLedger.Encampment
                {
                    X = position.x,
                    Z = position.z,
                    Place = $"Encampment zone · {place}",
                    Area = district,
                    Residents = baseResidents + (i < remainder ? 1 : 0),
                });
            }
            m_EncampmentSites.Clear();
            m_EncampmentSites.AddRange(selectedSites);
            HomelessEncampmentLedger.Replace(entries, frame);
        }
    }
}
