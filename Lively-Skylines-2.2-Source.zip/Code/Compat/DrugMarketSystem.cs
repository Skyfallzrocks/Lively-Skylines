using System.Collections.Generic;
using Game;
using Game.Buildings;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Abstract nightly city story: buyers head to dense hotspots; profits are estimates only.</summary>
    public partial class DrugMarketSystem : GameSystemBase
    {
        private const float kMarketTime = 22f / 24f;
        private const uint kMarketDuration = OutingStarter.FramesPerDay / 12u;
        private static readonly string[] s_MarketCategories = DrugMarketLedger.ProductCategories;
        private EntityQuery m_BuildingQuery;
        private EntityQuery m_BuyerQuery;
        private EntityQuery m_PopulationQuery;
        private EntityQuery m_CompanyQuery;
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private uint m_LastMarketDay = uint.MaxValue;
        private uint m_LastDecayDay = uint.MaxValue;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_BuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Building>(), ComponentType.ReadOnly<Game.Objects.Transform>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_BuyerQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.ReadOnly<HouseholdMember>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.DrugMarketsEnabled) return;
            uint frame = m_SimulationSystem.frameIndex;
            var random = new Random(math.max(1u, frame * 747796405u + 2891336453u));
            DrugOrganizationLedger.EnsureInitialRoster(ref random, frame);
            string formedGroup = DrugOrganizationLedger.GrowIfDue(frame, ref random);
            if (!string.IsNullOrEmpty(formedGroup))
                CityBuzzFeed.Add("Gang activity", formedGroup, "Citywide", $"A new organization has formed: {formedGroup}.", frame);
            float now = m_TimeSystem.normalizedTime;
            uint day = frame / OutingStarter.FramesPerDay;
            if (m_LastDecayDay != day)
            {
                if (m_LastDecayDay != uint.MaxValue) DrugMarketLedger.DecayDistrictPressure();
                RefreshDistrictRoster();
                m_LastDecayDay = day;
            }
            // Run once per in-game day after the evening threshold. This works
            // even when the mod is enabled or loaded after the clock crossed 22:00.
            if (now >= kMarketTime && m_LastMarketDay != day)
            {
                m_LastMarketDay = day;
                TryStartMarket(settings, frame, random);
            }
        }

        private void RefreshDistrictRoster()
        {
            using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity building in buildings)
            {
                if (!EntityManager.HasComponent<Game.Areas.CurrentDistrict>(building)) continue;
                Entity district = EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(building).m_District;
                if (district == Entity.Null) continue;
                DrugMarketLedger.GetDistrict(CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building));
            }
        }

        private void TryStartMarket(Setting settings, uint frame, Random random)
        {
            int cityPressureBonus = math.min(12, DrugMarketLedger.AveragePressure / 8);
            int nightlyChance = math.clamp(settings.DrugMarketChancePercent + cityPressureBonus, 1, 90);
            if (random.NextInt(100) >= nightlyChance) return;

            using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
            List<Unity.Mathematics.float3> cameraPositions = CctvCrimeCoverage.GetCameraPositions(EntityManager);
            var districtBuildings = new Dictionary<Entity, List<Entity>>();
            foreach (Entity building in buildings)
            {
                if (!EntityManager.HasComponent<Game.Areas.CurrentDistrict>(building)) continue;
                Entity district = EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(building).m_District;
                if (district == Entity.Null) continue;
                if (!districtBuildings.TryGetValue(district, out List<Entity> local))
                    districtBuildings[district] = local = new List<Entity>();
                local.Add(building);
            }
            if (districtBuildings.Count == 0) return;

            // Weight activity toward dense districts, while cameras and police
            // reduce the chance that the hotspot is chosen there.
            var weights = new Dictionary<Entity, int>();
            int totalExposure = 0;
            foreach (KeyValuePair<Entity, List<Entity>> item in districtBuildings)
            {
                int exposure = item.Value.Count;
                Entity sample = item.Value[random.NextInt(item.Value.Count)];
                if (EntityManager.HasComponent<Game.Objects.Transform>(sample) && CctvCrimeCoverage.Covers(EntityManager.GetComponentData<Game.Objects.Transform>(sample).m_Position, cameraPositions))
                    exposure = math.max(1, exposure / 3);
                if (CrimeAreaSystem.HasPoliceStation(item.Key)) exposure = math.max(1, exposure * 2 / 3);
                string districtName = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, sample);
                DrugMarketLedger.DistrictState districtState = DrugMarketLedger.GetDistrict(districtName);
                // Repeat hotspots attract modeled activity, while local response
                // gradually lowers pressure between nights.
                exposure = math.max(1, exposure * (100 + districtState.Pressure) / 100);
                weights[item.Key] = exposure;
                totalExposure += exposure;
            }
            Entity districtChoice = Entity.Null;
            List<Entity> selectedBuildings = null;
            int weightedPick = random.NextInt(math.max(1, totalExposure));
            foreach (KeyValuePair<Entity, List<Entity>> item in districtBuildings)
            {
                int exposure = weights[item.Key];
                if (weightedPick < exposure) { districtChoice = item.Key; selectedBuildings = item.Value; break; }
                weightedPick -= exposure;
            }
            if (selectedBuildings == null)
            {
                foreach (KeyValuePair<Entity, List<Entity>> item in districtBuildings) { districtChoice = item.Key; selectedBuildings = item.Value; break; }
            }
            if (selectedBuildings == null || selectedBuildings.Count == 0) return;
            Entity location = Entity.Null;
            var openStreetSites = new List<Entity>();
            foreach (Entity candidate in selectedBuildings)
            {
                if (!EntityManager.HasComponent<Game.Objects.Transform>(candidate)) continue;
                bool covered = CctvCrimeCoverage.Covers(EntityManager.GetComponentData<Game.Objects.Transform>(candidate).m_Position, cameraPositions);
                if (!covered) openStreetSites.Add(candidate);
            }
            if (openStreetSites.Count == 0) openStreetSites = selectedBuildings;
            location = openStreetSites[random.NextInt(openStreetSites.Count)];
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
            DrugOrganizationLedger.Organization organization = DrugOrganizationLedger.PickForArea(area, ref random);
            if (organization == null) return;
            if (!GangEconomyLedger.HasStock(organization))
            {
                CityBuzzFeed.Add("Drug market", "Crime Desk", area, $"{organization.Name} had no product to move in {area} after seizures and dried-up supply. The street market stayed quiet tonight.", frame);
                return;
            }
            string group = organization.Name;
            DrugMarketLedger.DistrictState currentDistrict = DrugMarketLedger.GetDistrict(area);
            string category = PickCategory(currentDistrict, ref random);

            var localBuyers = new List<Entity>();
            var unhousedBuyers = new List<Entity>();
            using NativeArray<Entity> candidates = m_BuyerQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity citizen in candidates)
            {
                Entity currentBuilding = EntityManager.GetComponentData<CurrentBuilding>(citizen).m_CurrentBuilding;
                if (currentBuilding == Entity.Null || !EntityManager.Exists(currentBuilding)
                    || !EntityManager.HasComponent<Game.Areas.CurrentDistrict>(currentBuilding)) continue;
                Citizen resident = EntityManager.GetComponentData<Citizen>(citizen);
                int age = (int)(resident.m_State & (CitizenFlags.AgeBit1 | CitizenFlags.AgeBit2));
                if (age < (int)CitizenAge.Adult) continue;
                if (EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(currentBuilding).m_District == districtChoice)
                {
                    localBuyers.Add(citizen);
                    Entity household = EntityManager.GetComponentData<HouseholdMember>(citizen).m_Household;
                    if (household != Entity.Null && EntityManager.Exists(household) && EntityManager.HasComponent<HomelessHousehold>(household))
                        unhousedBuyers.Add(citizen);
                }
            }
            int requested = math.max(1, localBuyers.Count / 70); // Typical market cohort is ~1.4% of local adult residents.
            // A larger seller network raises the market's sales capacity and the
            // modeled chance that exposed residents develop repeated-use patterns.
            int sellerCount = math.max(1, DrugOrganizationLedger.SellersInNetwork(organization, area));
            requested = math.min(math.max(requested, localBuyers.Count * math.min(16, sellerCount) / 650), sellerCount * random.NextInt(5, 12));
            int population = m_PopulationQuery.CalculateEntityCount();
            int attendanceCap = PopulationCap.MaxAttendees(population, Mod.Settings.MaxAttendancePercent);
            requested = math.min(requested, AttendanceLedger.Remaining(attendanceCap, frame));

            int buyers = 0;
            var modeledCohort = new List<Entity>(requested);
            if (requested > 0 && localBuyers.Count > 0)
            {
                SelectRandom(localBuyers, requested, modeledCohort, ref random);
                using NativeArray<Entity> selectedResidents = new NativeArray<Entity>(modeledCohort.ToArray(), Allocator.Temp);
                // Use the game's normal leisure routing so residents visibly
                // travel to the hotspot, but only select adults who are not
                // already assigned another outing.
                buyers = OutingStarter.Start(EntityManager, selectedResidents, modeledCohort.Count,
                    ref random, frame, kMarketDuration, location);
                AttendanceLedger.Add(buyers, frame + kMarketDuration);
                int supplyPressure = math.min(100, sellerCount * 7);
                for (int i = 0; i < buyers; i++)
                {
                    Entity citizen = modeledCohort[i];
                    Entity household = EntityManager.GetComponentData<HouseholdMember>(citizen).m_Household;
                    bool unhoused = household != Entity.Null && EntityManager.Exists(household) && EntityManager.HasComponent<HomelessHousehold>(household);
                    SubstanceRecoveryLedger.RecordMarketExposure(citizen, unhoused, supplyPressure, frame, ref random);
                }
            }
            int averageSpend = random.NextInt(35, 121);
            long profit = (long)buyers * averageSpend;
            int density = selectedBuildings.Count;
            int sellersUsed = buyers == 0 ? 0 : math.min(sellerCount, math.max(1, (buyers + 5) / 6));
            bool hasPolice = CrimeAreaSystem.HasPoliceStation(districtChoice);
            bool hasCamera = EntityManager.HasComponent<Game.Objects.Transform>(location) &&
                CctvCrimeCoverage.Covers(EntityManager.GetComponentData<Game.Objects.Transform>(location).m_Position, cameraPositions);
            DrugOrganizationLedger.Organization gangBuyer = organization.Type == "Cartel" && random.NextInt(100) < 58
                ? DrugOrganizationLedger.PickGangBuyer(area, organization, ref random) : null;
            int wholesaleUnits = gangBuyer == null ? 0 : random.NextInt(8, 41);
            long wholesaleValue = wholesaleUnits * random.NextInt(18, 56);
            if (gangBuyer != null)
            {
                int moved = GangEconomyLedger.Wholesale(organization, gangBuyer, wholesaleUnits, wholesaleValue);
                wholesaleValue = wholesaleUnits > 0 ? wholesaleValue * moved / wholesaleUnits : 0;
                wholesaleUnits = moved;
                if (moved == 0) gangBuyer = null;
            }
            DrugOrganizationLedger.RecordSale(organization, category, area, location, buyers, profit, gangBuyer, wholesaleUnits, wholesaleValue);
            GangEconomyLedger.OnStreetSale(organization, buyers, profit);
            DrugMarketLedger.Add(group, area, category, buyers, sellersUsed, profit + wholesaleValue, density, frame, location,
                gangBuyer?.Name ?? string.Empty, wholesaleUnits, wholesaleValue);
            DrugMarketLedger.RecordDistrictMarket(area, category, buyers, hasPolice, hasCamera, frame, frame + kMarketDuration);
            UnderworldOperations.StartPharmacyMarket(location, area, category, frame);
            string place = m_NameSystem.GetRenderedLabelName(location);
            if (string.IsNullOrWhiteSpace(place)) place = area;
            string wholesaleMessage = gangBuyer == null ? string.Empty : $" Wholesale supply: {gangBuyer.Name} purchased {wholesaleUnits} modeled units (${wholesaleValue:N0} estimated value).";
            string marketMessage = $"Fictional street-market report: {category} activity in {area}; {buyers} residents modeled as buyers, served by {sellersUsed} sellers. Estimated market value ${profit + wholesaleValue:N0}.{wholesaleMessage} Hotspot density: {density} buildings.";
            if (buyers > 0 && unhousedBuyers.Count > 0)
                marketMessage += $" Public-health tracking currently records {SubstanceRecoveryLedger.DependentCount} residents with elevated modeled dependence and {SubstanceRecoveryLedger.DepletedCount} with depleted fictional funds; outreach and recovery support are available in the Recovery tab.";
            if (buyers >= 5) PublicReactionLedger.Add("Reported nighttime street-market activity", 2);
            CityBuzzFeed.Add("Drug market", group, place, marketMessage, frame);
            DjAnnouncement.EnqueueCityUpdate("Drug market", group, place, marketMessage, location);
            if (settings.FamousPeopleEnabled && random.NextInt(100) < 55)
            {
                FamousSimRoster.EnsureResidents(EntityManager, m_BuyerQuery, m_NameSystem, ref random);
                if (FamousSimRoster.TryPick(EntityManager, ref random, out Entity commenter, out string commentName))
                {
                    string comment = random.NextInt(2) == 0
                        ? $"People are talking about reported {category.ToLowerInvariant()} activity near {place}. I hope the city connects anyone affected with support."
                        : $"Reports of {category.ToLowerInvariant()} activity near {place} are worrying. More outreach and prevention would help this neighborhood.";
                    CityBuzzFeed.AddSocial("Tweet", commentName, place, comment, frame, random.NextInt(40, 9000), random.NextInt(5, 1700), Entity.Null, imageKind: "building");
                    FamousSimRoster.RecordPost(commenter);
                }
            }
            AddLacedDrugHealthAlert(settings, organization, category, location, place, area, frame, ref random);
            AddEnforcementOutcome(organization, location, place, area, frame, hasPolice, hasCamera, ref random);
            Mod.log.Info($"Fictional Lively Skylines drug-market report in {area}: {buyers} modeled buyers, {wholesaleUnits} wholesale units sold to {gangBuyer?.Name ?? "no gang"}, estimated value ${profit + wholesaleValue:N0}.");
        }

        private static string PickCategory(DrugMarketLedger.DistrictState district, ref Random random)
        {
            // District demand has memory, but every report remains randomized.
            if (district != null && district.Markets > 0 && random.NextInt(100) < 48)
                return district.LeadingCategory;
            return s_MarketCategories[random.NextInt(s_MarketCategories.Length)];
        }

        private static void SelectRandom(List<Entity> source, int wanted, List<Entity> destination, ref Random random)
        {
            if (wanted <= 0 || source.Count == 0) return;
            var pool = new List<Entity>(source);
            for (int i = pool.Count - 1; i > 0; i--)
            {
                int swap = random.NextInt(i + 1);
                (pool[i], pool[swap]) = (pool[swap], pool[i]);
            }
            int added = 0;
            for (int i = 0; i < pool.Count && added < wanted; i++)
            {
                if (destination.Contains(pool[i])) continue;
                destination.Add(pool[i]);
                added++;
            }
        }

        private bool TryStartPharmacyMarket(uint frame, ref Random random)
        {
            var pharmacies = new List<Entity>();
            using (NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity company in companies)
                {
                    if (!EntityManager.HasComponent<Game.Buildings.PropertyRenter>(company)) continue;
                    Entity building = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property;
                    if (building == Entity.Null || !EntityManager.Exists(building)) continue;
                    string labels = (m_NameSystem.GetRenderedLabelName(company) + " " + m_NameSystem.GetRenderedLabelName(building)).ToLowerInvariant();
                    if (EntityManager.HasComponent<Game.Prefabs.PrefabRef>(company))
                    {
                        Entity prefab = EntityManager.GetComponentData<Game.Prefabs.PrefabRef>(company).m_Prefab;
                        labels += " " + m_NameSystem.GetRenderedLabelName(prefab).ToLowerInvariant();
                    }
                    if (labels.Contains("pharmacy") || labels.Contains("chemist") || labels.Contains("drugstore") || labels.Contains("drug store")) pharmacies.Add(building);
                }
            }
            if (pharmacies.Count == 0) return false;
            Entity location = pharmacies[random.NextInt(pharmacies.Count)];
            string place = m_NameSystem.GetRenderedLabelName(location);
            if (string.IsNullOrWhiteSpace(place)) place = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
            string[] categories = { "cannabis-type · fictional spray format", "stimulant-type", "opioid-type", "club-drug type", "unknown mixed supply" };
            string category = categories[random.NextInt(categories.Length)];
            UnderworldOperations.StartPharmacyMarket(location, place, category, frame);
            Mod.log.Info($"Fictional nighttime pharmacy-market report near {place} ({area}); no real company altered.");
            return true;
        }

        private void AddEnforcementOutcome(DrugOrganizationLedger.Organization organization, Entity location, string place,
            string area, uint frame, bool hasPolice, bool cameraCoverage, ref Random random)
        {
            int raidChance = (hasPolice ? 28 : 9) + (cameraCoverage ? 18 : 0);
            if (random.NextInt(100) >= raidChance) return;
            int arrests = random.NextInt(1, 5);
            int referrals = random.NextInt(2, 9);
            int replacedSellers = random.NextInt(0, 3);
            DrugMarketLedger.RecordEnforcement(arrests, referrals, replacedSellers, true);
            DrugMarketLedger.RecordDistrictResponse(area, referrals, hasPolice, cameraCoverage);
            organization.Sellers = math.max(0, organization.Sellers - replacedSellers);
            organization.LinkedCrimeReports += arrests;
            string update = $"Fictional market enforcement report near {place}, {area}: {arrests} sellers arrested, {referrals} public-health referrals, {replacedSellers} seller positions disrupted. Police presence: {(hasPolice ? "nearby" : "limited")}; camera coverage: {(cameraCoverage ? "yes" : "no")}.";
            DrugMarketLedger.AddEnforcementReport(organization.Name, area, update, frame);
            CityBuzzFeed.Add("Market enforcement", "City dispatch", $"{place} · {area}", update, frame);
            DjAnnouncement.EnqueueCityUpdate("Market enforcement", "City dispatch", $"{place} · {area}", update, location);
            if (replacedSellers > 0) organization.Sellers += replacedSellers;
        }

        private void AddLacedDrugHealthAlert(Setting settings, DrugOrganizationLedger.Organization organization, string category, Entity location, string place, string area, uint frame, ref Random random)
        {
            if (!settings.LacedDrugIncidentsEnabled || settings.LacedDrugIncidentChancePercent <= 0 || random.NextInt(100) >= math.clamp(settings.LacedDrugIncidentChancePercent, 0, 25)) return;
            DrugMarketLedger.RecordHealthCall(organization.Name, area, category, frame, "Public health services notified · fictional alert");
            PublicReactionLedger.Add("Public-health concern linked to an unknown drug supply", 7);
            Entity district = EntityManager.HasComponent<Game.Areas.CurrentDistrict>(location) ? EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(location).m_District : Entity.Null;
            bool hasPolice = CrimeAreaSystem.HasPoliceStation(district);
            Entity incident = EntityManager.CreateEntity();
            string response = "Public health services notified";
            string detail = $"Lively Skylines simulated public-health alert: possible harm involving an adulterated or unknown {category} supply was reported near a market hotspot. {response}. No specific substance, recipe, or resident is identified.";
            CityCrimeLedger.Record(incident, location, place, area, hasPolice, false, frame, detail, "Laced-drug harm alert", "Unidentified", response);
            CityBuzzFeed.AddCrime(incident, $"{place} · {area}", detail, frame, "Public health alert", "Overdose / health call");
            CityBuzzFeed.Add("Public health", organization.Name, $"{place} · {area}", $"Possible harm involving an adulterated or unknown {category} supply was reported near a market hotspot. Public health services were notified. This is a fictional Lively Skylines report.", frame);
            Mod.log.Info($"Lively Skylines simulated laced-drug public health alert near {place}; no substance or resident identified.");
        }
    }
}
