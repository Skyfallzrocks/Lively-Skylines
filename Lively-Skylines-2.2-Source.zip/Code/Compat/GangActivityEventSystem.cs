using System.Collections.Generic;
using Game;
using Game.Buildings;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Creates occasional, fictional gang/cartel area reports for the city feed.</summary>
    public partial class GangActivityEventSystem : GameSystemBase
    {
        private const float kReportTime = 21f / 24f;
        private const uint kActivityDuration = OutingStarter.FramesPerDay / 3u;
        private static readonly string[] s_Activities = { "members reported gathering", "territory activity reported", "vehicles seen circling the area", "police increased patrols after reports" };

        private EntityQuery m_BuildingQuery;
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private float m_PreviousTime = -1f;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_BuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Building>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.BikerGangEventsEnabled) return;
            float now = m_TimeSystem.normalizedTime;
            bool reachedReportTime = m_PreviousTime >= 0f && m_PreviousTime < kReportTime && now >= kReportTime;
            m_PreviousTime = now;
            if (reachedReportTime) TryReportActivity(settings);
        }

        private void TryReportActivity(Setting settings)
        {
            uint frame = m_SimulationSystem.frameIndex;
            var random = new Random(math.max(1u, frame * 2246822519u + 3266489917u));
            DrugOrganizationLedger.EnsureInitialRoster(ref random, frame);
            using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
            var named = new List<Entity>(buildings.Length);
            var uncovered = new List<Entity>();
            foreach (Entity building in buildings)
            {
                if (string.IsNullOrWhiteSpace(m_NameSystem.GetRenderedLabelName(building))) continue;
                named.Add(building);
                if (!EntityManager.HasComponent<Game.Areas.CurrentDistrict>(building)) continue;
                Entity district = EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(building).m_District;
                if (district != Entity.Null && !CrimeAreaSystem.HasPoliceStation(district)) uncovered.Add(building);
            }
            if (named.Count == 0) return;

            float recentRate = CityCrimeLedger.WeeklyPerThousand(frame);
            int baseChance = math.clamp(settings.BikerGangChancePercent / 2, 1, 12);
            int chance = math.clamp(baseChance + math.min(12, (int)(recentRate * 2f)) + (uncovered.Count > 0 ? 4 : 0), 1, 30);
            if (random.NextInt(100) >= chance) return;

            DrugOrganizationLedger.Organization organization = DrugOrganizationLedger.Pick(ref random);
            if (organization == null) return;
            var territoryBuildings = new List<Entity>();
            if (organization.Territory != "Unassigned turf")
                foreach (Entity building in named)
                    if (CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building) == organization.Territory) territoryBuildings.Add(building);
            Entity location = territoryBuildings.Count > 0
                ? territoryBuildings[random.NextInt(territoryBuildings.Count)]
                : uncovered.Count > 0 && random.NextInt(100) < 70
                ? uncovered[random.NextInt(uncovered.Count)]
                : named[random.NextInt(named.Count)];
            string place = m_NameSystem.GetRenderedLabelName(location);
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
            bool cartel = organization.Type == "Cartel";
            string type = cartel ? "Cartel report" : "Street gang report";
            string group = organization.Name;
            string activity = s_Activities[random.NextInt(s_Activities.Length)];
            string rival = organization.Rivals.Count > 0 ? organization.Rivals[random.NextInt(organization.Rivals.Count)] : null;
            if (!string.IsNullOrEmpty(rival) && random.NextInt(100) < 28) activity = $"rivalry with {rival} reported near the turf";
            int reportedMembers = random.NextInt(cartel ? 3 : 4, math.max((cartel ? 13 : 18) + 1, organization.Members + 1));
            uint endFrame = frame + kActivityDuration;

            DrugOrganizationLedger.RecordActivity(organization, area, location, activity);
            GangActivityLedger.Add(type, group, activity, area, reportedMembers, frame, endFrame, location);
            CityBuzzFeed.Add(type, "City report", $"{place} · {area}", $"{type}: {group}; {activity} near {place}. {reportedMembers} people reported. This is an in-game activity report.", frame);
            Mod.log.Info($"Lively Skylines {type}: {group} near {place} ({area}).");
        }
    }
}
