using System.Collections.Generic;
using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    // Gives a small roster of real city residents local-celebrity status. One may
    // randomly visit and post about a bar, shop, or other named city place.
    public partial class FamousVisitorSystem : GameSystemBase
    {
        private const float kVisitTime = 19f / 24f;
        private const uint kVisitDuration = OutingStarter.FramesPerDay / 16u;
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private EntityQuery m_CompanyQuery;
        private EntityQuery m_CitizenQuery;
        private EntityQuery m_PlaceQuery;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;
        private readonly List<Entity> m_Businesses = new List<Entity>();
        private float m_PreviousTime = -1f;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_PlaceQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Buildings.Building>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CandidateQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.FamousPeopleEnabled) return;

            uint frame = m_SimulationSystem.frameIndex;
            var rosterRandom = new Random(math.max(1u, frame ^ 0x4F1BBCDCu));
            FamousSimRoster.EnsureResidents(EntityManager, m_CitizenQuery, m_NameSystem, ref rosterRandom);

            float now = m_TimeSystem.normalizedTime;
            bool reachedVisitTime = m_PreviousTime >= 0f && m_PreviousTime < kVisitTime && now >= kVisitTime;
            m_PreviousTime = now;
            if (reachedVisitTime) TryStartVisit();
        }

        private void TryStartVisit()
        {
            uint frame = m_SimulationSystem.frameIndex;
            var random = new Random(math.max(1u, frame * 3266489917u + 0x51ed270bu));
            // Random evenings keep the feed active without making every sim a celebrity.
            if (random.NextInt(100) >= 80) return;

            if (!FamousSimRoster.TryPick(EntityManager, ref random, out Entity resident, out string famousName)) return;
            using NativeArray<Entity> places = m_PlaceQuery.ToEntityArray(Allocator.Temp);
            var candidates = new List<Entity>(places.Length);
            foreach (Entity place in places)
            {
                if (string.IsNullOrWhiteSpace(m_NameSystem.GetRenderedLabelName(place))) continue;
                candidates.Add(place);
            }
            if (candidates.Count == 0) return;

            CollectBusinesses();
            // Most creator updates spotlight an actual business, including bars;
            // other posts can still cover parks and city landmarks.
            bool shopPost = m_Businesses.Count > 0 && random.NextInt(100) < 85;
            Entity building = shopPost ? m_Businesses[random.NextInt(m_Businesses.Count)] : candidates[random.NextInt(candidates.Count)];
            Entity company = shopPost ? FindCompanyAt(building) : BarFinder.FindBarCompany(EntityManager, m_CompanyQuery, building);
            string placeName = m_NameSystem.GetRenderedLabelName(building);
            string brand = company != Entity.Null ? m_NameSystem.GetRenderedLabelName(company) : placeName;
            if (string.IsNullOrEmpty(placeName)) placeName = "a local spot";
            if (string.IsNullOrEmpty(brand)) brand = placeName;

            bool positive = random.NextInt(100) < 58;
            string[] positivePosts = shopPost
                ? new[] { $"Found {brand} at {placeName} and left with a new favorite. Go check them out!", $"Local shop find: {brand} at {placeName}. Definitely worth a visit.", $"I had a great stop at {brand} in {placeName}. Showing local shops some love!" }
                : new[] { $"Found {placeName} tonight and the vibe is unreal. #CityFinds #NightOut", $"Adding {placeName} to my favorites. Bring your friends! #LocalGem", $"If you are in town, check out {placeName}. Great people, great night. #ForYou" };
            string[] criticalPosts = shopPost
                ? new[] { $"I tried {brand} at {placeName}, but it wasn't for me. I'd skip this one.", $"Not a great visit to {brand} in {placeName}. I wouldn't make a special trip." }
                : new[] { $"Tried {placeName} tonight. It was not for me, but you can decide. #CityReview", $"Honest review: {placeName} needs a little work. #NightOut #MyTake" };
            string post = positive ? positivePosts[random.NextInt(positivePosts.Length)] : criticalPosts[random.NextInt(criticalPosts.Length)];
            string title = positive ? $"{famousName} posted about {placeName}" : $"{famousName} reviewed {placeName}";

            int likes = positive ? random.NextInt(1800, 48000) : random.NextInt(80, 4200);
            int dislikes = positive ? random.NextInt(40, 2200) : random.NextInt(1600, 36000);
            int population = m_PopulationQuery.CalculateEntityCount();
            int audience = math.min(math.max(1, population / 100), 10 + (likes + dislikes) / 100);
            int going = 0;
            int skipping = 0;
            if (positive && audience > 0)
            {
                int rawInterested = (audience * likes) / math.max(1, likes + dislikes);
                int cap = PopulationCap.MaxAttendees(population, Mod.Settings.MaxAttendancePercent);
                int target = math.min(rawInterested, AttendanceLedger.Remaining(cap, frame));
                using NativeArray<Entity> residents = m_CandidateQuery.ToEntityArray(Allocator.Temp);
                uint outing = OutingStarter.FramesPerDay / 16u;
                going = OutingStarter.Start(EntityManager, residents, target, ref random, frame, outing, building);
                AttendanceLedger.Add(going, frame + outing);
                skipping = audience - going;
            }
            else
            {
                // A critical review creates negative word of mouth: this audience
                // opts out instead of being sent to the reviewed place.
                skipping = audience;
            }

            DjAnnouncement.EnqueueFamousVisitor(famousName, placeName, brand, positive);
            ActiveEvents.Add(title, placeName, going, frame + kVisitDuration, building);
            FamousSimRoster.RecordPost(resident);
            if (shopPost)
                CityBuzzFeed.AddSocial("Tweet", famousName, placeName, post, frame, likes, dislikes, Entity.Null, going, skipping, "building");
            else
                CityBuzzFeed.AddVideo(famousName, placeName, post, frame, likes, dislikes, going, skipping, "person");
            Mod.log.Info($"Local celebrity sim {famousName} posted about {placeName}: {likes} likes, {dislikes} dislikes; {going} sims heading there and {skipping} skipping it.");
        }

        private void CollectBusinesses()
        {
            m_Businesses.Clear();
            using NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity shop in companies)
            {
                if (!EntityManager.HasComponent<Game.Buildings.PropertyRenter>(shop)) continue;
                Entity property = EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(shop).m_Property;
                if (property == Entity.Null || !EntityManager.Exists(property) || !EntityManager.HasComponent<Game.Buildings.Building>(property)) continue;
                if (string.IsNullOrWhiteSpace(m_NameSystem.GetRenderedLabelName(property))) continue;
                m_Businesses.Add(property);
            }
        }

        private Entity FindCompanyAt(Entity building)
        {
            using NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity company in companies)
            {
                if (EntityManager.GetComponentData<Game.Buildings.PropertyRenter>(company).m_Property == building) return company;
            }
            return Entity.Null;
        }
    }

    public static class FamousSimRoster
    {
        private struct Profile
        {
            public Entity Citizen;
            public string Name;
            public int Posts;
        }

        private const int kMaxProfiles = 100;
        private static readonly List<Profile> s_Profiles = new List<Profile>(kMaxProfiles);
        public static int Visits { get; private set; }
        public static int Count => s_Profiles.Count;

        // The UI consumes these as name|post-count rows.
        public static string Names
        {
            get
            {
                var rows = new string[s_Profiles.Count];
                for (int i = 0; i < s_Profiles.Count; i++)
                    rows[i] = $"{s_Profiles[i].Name}|{s_Profiles[i].Posts}";
                return string.Join("\n", rows);
            }
        }

        public static void EnsureResidents(EntityManager em, EntityQuery residents, NameSystem nameSystem, ref Random random)
        {
            int expected = residents.CalculateEntityCount();
            s_Profiles.RemoveAll(profile => !em.Exists(profile.Citizen));
            int target = math.min(kMaxProfiles, expected);
            if (s_Profiles.Count >= target) return;

            // City population changes are common during simulation. Keep every
            // surviving famous resident and only fill slots vacated by residents
            // who actually left or were removed from the city.
            var selected = new HashSet<Entity>();
            foreach (Profile profile in s_Profiles) selected.Add(profile.Citizen);
            var replacements = new List<Profile>();
            using NativeArray<Entity> citizens = residents.ToEntityArray(Allocator.Temp);
            foreach (Entity citizen in citizens)
            {
                if (selected.Contains(citizen)) continue;
                string name = nameSystem.GetRenderedLabelName(citizen);
                if (string.IsNullOrWhiteSpace(name)) continue;
                replacements.Add(new Profile { Citizen = citizen, Name = Clean(name), Posts = 0 });
            }
            for (int i = replacements.Count - 1; i > 0; i--)
            {
                int swap = random.NextInt(i + 1);
                Profile item = replacements[i];
                replacements[i] = replacements[swap];
                replacements[swap] = item;
            }
            for (int i = 0; i < replacements.Count && s_Profiles.Count < target; i++)
                s_Profiles.Add(replacements[i]);
        }

        public static bool TryPick(EntityManager em, ref Random random, out Entity citizen, out string name)
        {
            for (int attempt = 0; attempt < s_Profiles.Count; attempt++)
            {
                int index = random.NextInt(s_Profiles.Count);
                Profile profile = s_Profiles[index];
                if (!em.Exists(profile.Citizen)) continue;
                citizen = profile.Citizen;
                name = profile.Name;
                return true;
            }
            citizen = Entity.Null;
            name = "";
            return false;
        }

        public static void RecordPost(Entity citizen)
        {
            for (int i = 0; i < s_Profiles.Count; i++)
            {
                if (s_Profiles[i].Citizen != citizen) continue;
                Profile profile = s_Profiles[i];
                profile.Posts++;
                s_Profiles[i] = profile;
                Visits++;
                return;
            }
        }

        public static bool PublishShowTweet(EntityManager em, ref Random random, string place, string message, uint frame, int attendees = 0)
        {
            if (!TryPick(em, ref random, out Entity citizen, out string name)) return false;
            int likes = random.NextInt(500, 36000);
            int dislikes = random.NextInt(20, 2600);
            CityBuzzFeed.AddSocial("Tweet", name, place, message, frame, likes, dislikes, Entity.Null, attendees);
            RecordPost(citizen);
            return true;
        }

        public static void ResetVisits()
        {
            Visits = 0;
            s_Profiles.Clear();
            CityBuzzFeed.Clear();
        }

        private static string Clean(string value) => (value ?? "").Replace("|", " ").Replace("\r", " ").Replace("\n", " ");
    }
}
