using System.Collections.Generic;
using Game;
using Game.Buildings;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Per-bar management: prices, happy hour, bouncers, last call, live music, ID checks.</summary>
    public static class BarSceneLedger
    {
        public class Bar
        {
            public Entity Building;
            public string Name = "";
            public string Area = "";
            public int Price = 1;          // 0 cheap, 1 standard, 2 premium
            public bool HappyHour;
            public int Bouncers;           // 0-2
            public int LastCall = 1;       // 0 = 1 AM, 1 = 2 AM, 2 = 4 AM
            public bool LiveMusic;
            public bool StrictId = true;
            public int Popularity = 50;
            public int Rowdiness = 20;
            public int Tonight;
            public int LastNight;
            public int Total;
            public long Revenue;
            public long LastRevenue;
            public long TaxPaid;
            public int Fights, FightsStopped, Duis, Underage, Noise, Inspections, Violations;
            public int PromoBoost;
            public readonly List<string> Events = new List<string>();
            public void Log(string s) { Events.Insert(0, s.Replace("|", " ").Replace("~", " ").Replace("\n", " ")); if (Events.Count > 8) Events.RemoveAt(8); }
            public int Stars => math.clamp((Popularity - Rowdiness / 2 + (LiveMusic ? 10 : 0) + 30) / 20, 1, 5);
        }

        public static readonly Dictionary<Entity, Bar> All = new Dictionary<Entity, Bar>();
        public static int LiquorTax = 1;   // 0 none, 1 = 5%, 2 = 10%
        public static bool RideHome;
        public static long CityTaxTotal, LastNightTax, RideHomeSpent;
        public static int LastNightGuests, LastNightFights, LastNightDuis, NightsRun;
        public static string LastNightSummary = "No bar night settled yet. Bars open around 7 PM.";
        public static bool NightOpen;

        public static Bar Get(Entity building)
        {
            if (!All.TryGetValue(building, out Bar bar)) { bar = new Bar { Building = building }; All[building] = bar; }
            return bar;
        }

        public static int TaxPercent => LiquorTax == 0 ? 0 : LiquorTax == 1 ? 5 : 10;
        public static int MaxLastCall => CityPolicyLedger.IsActive("Noise Curfew") ? 0 : CityPolicyLedger.IsActive("Late-Night Licenses") ? 2 : 1;
        public static bool HappyHourBanned => CityPolicyLedger.IsActive("Happy Hour Ban");
        public static int MinBouncers => CityPolicyLedger.IsActive("Bar Security Mandate") ? 1 : 0;
        public static int EffLastCall(Bar b) => math.min(b.LastCall, MaxLastCall);
        public static bool EffHappy(Bar b) => b.HappyHour && !HappyHourBanned;
        public static int EffBouncers(Bar b) => math.max(b.Bouncers, MinBouncers);
    }

    public partial class BarSceneSystem : GameSystemBase
    {
        private SimulationSystem m_Simulation;
        private TimeSystem m_Time;
        private CitySystem m_CitySystem;
        private NameSystem m_NameSystem;
        private EntityQuery m_CompanyQuery;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;
        private float m_PrevTime = -1f;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_Simulation = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_Time = World.GetOrCreateSystemManaged<TimeSystem>();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
            m_CandidateQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            var settings = Mod.Settings;
            if (settings == null || !settings.Enabled) return;
            float now = m_Time.normalizedTime;
            float prev = m_PrevTime;
            m_PrevTime = now;
            if (prev < 0f) return;
            // Doors open around 7 PM; the night is settled around 5 AM.
            if (!BarSceneLedger.NightOpen && prev < 0.80f && now >= 0.80f) OpenNight(settings);
            if (BarSceneLedger.NightOpen && prev < 0.21f && now >= 0.21f) SettleNight();
        }

        private List<Entity> CollectBars()
        {
            var companies = new List<Entity>();
            BarFinder.CollectBarCompanies(EntityManager, m_CompanyQuery, companies);
            var buildings = new List<Entity>(companies.Count);
            foreach (Entity company in companies)
            {
                Entity building = EntityManager.GetComponentData<PropertyRenter>(company).m_Property;
                if (building == Entity.Null || !EntityManager.Exists(building) || !EntityManager.HasComponent<Game.Objects.Transform>(building)) continue;
                var bar = BarSceneLedger.Get(building);
                string name = m_NameSystem.GetRenderedLabelName(company);
                if (!string.IsNullOrWhiteSpace(name) && name.IndexOf("Assets.NAME", System.StringComparison.OrdinalIgnoreCase) < 0) bar.Name = name;
                if (string.IsNullOrEmpty(bar.Area)) bar.Area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                buildings.Add(building);
            }
            return buildings;
        }

        private void OpenNight(Setting settings)
        {
            BarSceneLedger.NightOpen = true;
            uint frame = m_Simulation.frameIndex;
            List<Entity> bars = CollectBars();
            if (bars.Count == 0) return;
            bars.Sort((a, b) => BarSceneLedger.Get(b).Popularity.CompareTo(BarSceneLedger.Get(a).Popularity));
            int population = m_PopulationQuery.CalculateEntityCount();
            int cap = PopulationCap.MaxAttendees(population, settings.MaxAttendancePercent);
            int remaining = AttendanceLedger.Remaining(cap, frame);
            using NativeArray<Entity> candidates = m_CandidateQuery.ToEntityArray(Allocator.Temp);
            var random = new Random(math.max(1u, frame * 1103515245u + 12345u));
            int taxPct = BarSceneLedger.TaxPercent;
            int totalStarted = 0;
            uint longest = 0;
            int limit = math.min(bars.Count, 30);
            for (int i = 0; i < limit && remaining > 0; i++)
            {
                var b = BarSceneLedger.Get(bars[i]);
                int lastCall = BarSceneLedger.EffLastCall(b);
                float mult = (b.Price == 0 ? 1.35f : b.Price == 2 ? 0.7f : 1f)
                    * (BarSceneLedger.EffHappy(b) ? 1.25f : 1f)
                    * (b.LiveMusic ? 1.2f : 1f)
                    * (lastCall == 0 ? 0.8f : lastCall == 2 ? 1.25f : 1f)
                    * (taxPct == 10 ? 0.85f : taxPct == 5 ? 0.95f : 1f)
                    * (b.StrictId ? 0.95f : 1.05f)
                    * (0.4f + (b.Popularity + b.PromoBoost) / 80f);
                int desired = math.clamp((int)((3 + population / 6000) * mult), 1, 40);
                int admitted = math.min(desired, remaining);
                uint duration = OutingStarter.FramesPerDay / (lastCall == 0 ? 6u : lastCall == 2 ? 3u : 4u);
                if (duration > longest) longest = duration;
                int started = OutingStarter.Start(EntityManager, candidates, admitted, ref random, frame, duration, bars[i]);
                AttendanceLedger.Add(started, frame + duration);
                b.Tonight = started;
                b.Total += started;
                remaining -= started;
                totalStarted += started;
            }
            if (totalStarted > 0)
            {
                ActiveEvents.Add("Bars open for the night", "", totalStarted, frame + longest);
                CityBuzzFeed.Add("Nightlife", "Lively Skylines", "Citywide", $"Doors are open: {totalStarted:N0} residents headed out to {math.min(bars.Count, limit)} bars tonight.", frame);
            }
        }

        private void SettleNight()
        {
            BarSceneLedger.NightOpen = false;
            uint frame = m_Simulation.frameIndex;
            var random = new Random(math.max(1u, frame * 2891336453u + 7u));
            long tax = 0; int guests = 0, fights = 0, duis = 0;
            bool lateTransit = CityPolicyLedger.IsActive("Late-Night Transit");
            int taxPct = BarSceneLedger.TaxPercent;
            int openBars = 0;
            var buildings = new List<Entity>(BarSceneLedger.All.Keys);
            foreach (Entity building in buildings)
            {
                var b = BarSceneLedger.All[building];
                if (!EntityManager.Exists(building)) { BarSceneLedger.All.Remove(building); continue; }
                int g = b.Tonight;
                b.LastNight = g;
                b.Tonight = 0;
                if (b.PromoBoost > 0) b.PromoBoost = math.max(0, b.PromoBoost - 5);
                if (g <= 0) { b.Popularity = math.max(5, b.Popularity - 1); continue; }
                openBars++;
                guests += g;
                bool happy = BarSceneLedger.EffHappy(b);
                int lastCall = BarSceneLedger.EffLastCall(b);
                int bouncers = BarSceneLedger.EffBouncers(b);
                float spend = (b.Price == 0 ? 18f : b.Price == 2 ? 45f : 28f) * (happy ? 0.85f : 1f) * (b.LiveMusic ? 1.1f : 1f);
                long revenue = (long)(g * spend * (0.85f + random.NextFloat() * 0.3f));
                long t = revenue * taxPct / 100;
                b.LastRevenue = revenue; b.Revenue += revenue; b.TaxPaid += t; tax += t;
                b.Rowdiness = math.clamp(12 + (int)(g * 0.6f) + (b.Price == 0 ? 15 : b.Price == 2 ? -8 : 0) + (happy ? 10 : 0) + lastCall * 9 - bouncers * 12 + (b.LiveMusic ? 3 : 0) + (b.StrictId ? 0 : 6), 0, 100);
                string place = string.IsNullOrEmpty(b.Name) ? "a local bar" : b.Name;
                // Fights.
                if (random.NextInt(100) < b.Rowdiness / 3)
                {
                    if (bouncers > 0 && random.NextInt(100) < bouncers * 35)
                    {
                        b.FightsStopped++; b.Log("Bouncers broke up a fight before police were needed.");
                    }
                    else
                    {
                        b.Fights++; fights++; b.Popularity = math.max(5, b.Popularity - 5);
                        Entity incident = EntityManager.CreateEntity();
                        CityCrimeLedger.Record(incident, building, place, b.Area, false, true, frame, $"A fight broke out at closing time at {place}.", "Bar fight", "Unidentified");
                        b.Log("A fight broke out at closing time. Police were called.");
                    }
                }
                // Drunk driving.
                float duiChance = g * (lastCall + 1) * 0.6f * (BarSceneLedger.RideHome ? 0.3f : 1f) * (lateTransit ? 0.6f : 1f);
                if (random.NextInt(100) < math.min(40, (int)duiChance))
                {
                    b.Duis++; duis++;
                    Entity incident = EntityManager.CreateEntity();
                    CityCrimeLedger.Record(incident, building, place, b.Area, false, true, frame, $"A patron left {place} and was stopped for drunk driving.", "DUI", "Bar patron");
                    b.Log("A patron was stopped for drunk driving after leaving.");
                }
                // Underage drinking.
                if (!b.StrictId && random.NextInt(100) < 15)
                {
                    b.Underage++; BarCaseLedger.Record(building);
                    b.Log("Teens got served with fake IDs. The venue picked up a case.");
                    CityBuzzFeed.Add("Bars · underage", "Crime Desk", place, $"Teens were served at {place} after lax ID checks.", frame);
                }
                // Noise.
                if (lastCall >= 1 && b.Rowdiness > 40 && random.NextInt(100) < 20 + lastCall * 8)
                {
                    b.Noise++; PublicReactionLedger.Add("Noise from late-night bars", 1);
                    b.Log("Neighbors filed a noise complaint.");
                }
                if (b.LiveMusic && random.NextInt(100) < 12) b.Log("A local band packed the room tonight.");
                int target = 40 + (b.LiveMusic ? 10 : 0) + (happy ? 8 : 0) + (b.Price == 0 ? 8 : b.Price == 2 ? -4 : 0) + bouncers * 2 - b.Rowdiness / 6;
                b.Popularity = math.clamp((int)(b.Popularity * 0.8f + target * 0.2f), 5, 100);
            }
            long rideCost = BarSceneLedger.RideHome ? 150L * openBars : 0L;
            BarSceneLedger.RideHomeSpent += rideCost;
            BarSceneLedger.CityTaxTotal += tax;
            BarSceneLedger.LastNightTax = tax;
            BarSceneLedger.LastNightGuests = guests;
            BarSceneLedger.LastNightFights = fights;
            BarSceneLedger.LastNightDuis = duis;
            BarSceneLedger.NightsRun++;
            PayCity(tax - rideCost);
            BarSceneLedger.LastNightSummary = guests > 0
                ? $"Last night {guests:N0} residents went out. Liquor tax brought in ${tax:N0}{(rideCost > 0 ? $", ride-home vouchers cost ${rideCost:N0}" : "")}. {fights} fight(s), {duis} DUI stop(s)."
                : "Last night was quiet. No one went out to the bars.";
            if (guests > 0) CityBuzzFeed.Add("Nightlife · last call", "Nightlife Now", "Citywide", BarSceneLedger.LastNightSummary, frame);
        }

        private void PayCity(long net)
        {
            if (net == 0) return;
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<Game.City.PlayerMoney>(city)) return;
            var money = EntityManager.GetComponentData<Game.City.PlayerMoney>(city);
            if (money.m_Unlimited) return;
            int amount = (int)math.clamp(net, -int.MaxValue, int.MaxValue);
            if (amount > 0) money.Add(amount); else money.Subtract(-amount);
            EntityManager.SetComponentData(city, money);
        }
    }
}
