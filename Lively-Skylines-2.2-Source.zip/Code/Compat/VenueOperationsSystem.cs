using System.Collections.Generic;
using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    public static class VenueOperations
    {
        private struct Request { public Entity Building; public bool Raid; }
        private struct Operation { public string Status; public uint EndFrame; }
        private static readonly Queue<Request> s_Requests = new Queue<Request>();
        private static readonly Dictionary<Entity, Operation> s_Operations = new Dictionary<Entity, Operation>();

        public static void QueueRaid(Entity building) { if (building != Entity.Null) s_Requests.Enqueue(new Request { Building = building, Raid = true }); }
        public static void QueueClose(Entity building) { if (building != Entity.Null) s_Requests.Enqueue(new Request { Building = building, Raid = false }); }
        public static bool TryDequeue(out Entity building, out bool raid)
        {
            if (s_Requests.Count == 0) { building = Entity.Null; raid = false; return false; }
            Request request = s_Requests.Dequeue(); building = request.Building; raid = request.Raid; return true;
        }
        public static void Set(Entity building, string status, uint endFrame = 0) => s_Operations[building] = new Operation { Status = status, EndFrame = endFrame };
        public static string Status(Entity building, uint frame)
        {
            if (!s_Operations.TryGetValue(building, out Operation operation)) return "Open · no active operation";
            if (operation.EndFrame > frame) return $"{operation.Status} · {((operation.EndFrame - frame) * 24f / OutingStarter.FramesPerDay):0.#} in-game hours left";
            if (operation.Status.StartsWith("Raid active")) return operation.Status.Replace("Raid active", "Raid complete");
            return operation.Status;
        }
        public static List<Entity> ActiveRaids(uint frame)
        {
            var active = new List<Entity>();
            foreach (KeyValuePair<Entity, Operation> item in s_Operations)
                if (item.Value.EndFrame > frame && item.Value.Status.StartsWith("Raid active")) active.Add(item.Key);
            return active;
        }
    }

    /// <summary>Runs per-venue closure and two-hour, ten-officer raid simulations.</summary>
    public partial class VenueOperationsSystem : GameSystemBase
    {
        private const uint kRaidDuration = OutingStarter.FramesPerDay / 12u;
        private EntityQuery m_CompanyQuery;
        private EntityQuery m_CitizenQuery;
        private SimulationSystem m_Simulation;
        private NameSystem m_NameSystem;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_Simulation = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 16;

        protected override void OnUpdate()
        {
            uint frame = m_Simulation.frameIndex;
            while (VenueOperations.TryDequeue(out Entity building, out bool raid))
            {
                if (!EntityManager.Exists(building)) continue;
                if (raid) StartRaid(building, frame);
                else CloseVenue(building, frame, "The city closed this entertainment venue.");
            }
        }

        private void StartRaid(Entity building, uint frame)
        {
            Entity company = BarFinder.FindBarCompany(EntityManager, m_CompanyQuery, building);
            if (company == Entity.Null) { VenueOperations.Set(building, "Venue is no longer open"); return; }
            uint endFrame = frame + kRaidDuration;
            VenueOperations.Set(building, "Raid active · 10 officers dispatched", endFrame);
            string place = SafeName(company, building);
            DjAnnouncement.EnqueueCityUpdate("Venue raid", "City dispatch", place, $"A simulated ten-officer raid is active at {place} for about two in-game hours.", building);

            var random = new Random(math.max(1u, frame * 747796405u + (uint)building.Index * 2891336453u));
            using NativeArray<Entity> citizens = m_CitizenQuery.ToEntityArray(Allocator.Temp);
            var eligibleTeens = new List<Entity>();
            foreach (Entity citizenEntity in citizens)
            {
                if (!EntityManager.HasComponent<Citizen>(citizenEntity)) continue;
                if (EntityManager.GetComponentData<CurrentBuilding>(citizenEntity).m_CurrentBuilding != building) continue;
                Citizen citizen = EntityManager.GetComponentData<Citizen>(citizenEntity);
                int age = (int)(citizen.m_State & (CitizenFlags.AgeBit1 | CitizenFlags.AgeBit2));
                if (age == (int)CitizenAge.Teen) eligibleTeens.Add(citizenEntity);
            }
            if (eligibleTeens.Count == 0 || random.NextInt(100) >= 45)
            {
                VenueOperations.Set(building, eligibleTeens.Count == 0 ? "Raid active · no underage drinker found" : "Raid active · no charge issued", endFrame);
                return;
            }

            Entity subject = eligibleTeens[random.NextInt(eligibleTeens.Count)];
            string residentName = m_NameSystem.GetRenderedLabelName(subject);
            if (string.IsNullOrWhiteSpace(residentName)) residentName = "an unnamed teen resident";
            Entity incident = EntityManager.CreateEntity();
            string detail = $"A real teen resident, {residentName}, was charged with underage drinking during a Lively Skylines venue raid. The venue was closed by the city.";
            BarCaseLedger.Record(building);
            CityCrimeLedger.Record(incident, building, place, CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building), true, true, frame, detail, "Underage drinking charge", residentName, "Ten-officer venue raid reported");
            CityBuzzFeed.AddCrime(incident, place, detail, frame, "Underage drinking charge", "Underage drinking");
            VenueOperations.Set(building, "Venue closed · underage drinking charge issued");
            CloseVenue(building, frame, detail);
        }

        private void CloseVenue(Entity building, uint frame, string message)
        {
            Entity company = BarFinder.FindBarCompany(EntityManager, m_CompanyQuery, building);
            if (company != Entity.Null && !EntityManager.HasComponent<Deleted>(company)) EntityManager.AddComponent<Deleted>(company);
            VenueOperations.Set(building, "Closed by city");
            string place = company != Entity.Null ? SafeName(company, building) : "Entertainment venue";
            CityBuzzFeed.Add("Venue action", "City dispatch", place, message, frame);
            DjAnnouncement.EnqueueCityUpdate("Venue closure", "City dispatch", place, message, building);
        }

        private string SafeName(Entity company, Entity building)
        {
            string name = company != Entity.Null ? m_NameSystem.GetRenderedLabelName(company) : m_NameSystem.GetRenderedLabelName(building);
            return string.IsNullOrWhiteSpace(name) ? "Entertainment venue" : name;
        }
    }
}
