using System;
using System.Collections.Generic;
using System.Reflection;
using Colossal.UI.Binding;
using Game;
using Game.Prefabs;
using Game.Tools;
using Game.UI;

namespace BarRush
{
    /// <summary>Registers the distinct imported camera props with placement and shared CCTV systems.</summary>
    public partial class CctvPlacementUISystem : UISystemBase
    {
        private const string kGroup = "BarRush";
        private ToolSystem m_ToolSystem;
        private ObjectToolSystem m_ObjectTool;
        private PrefabSystem m_PrefabSystem;
        private ObjectPrefab m_CameraPrefab;
        private ObjectPrefab m_FixedCameraPrefab;
        private ObjectPrefab m_AlprPrefab;
        private Unity.Entities.Entity m_PoliceGroupEntity = Unity.Entities.Entity.Null;
        private readonly HashSet<Unity.Entities.Entity> m_PoliceMenuRegistered = new HashSet<Unity.Entities.Entity>();
        private string m_Status = "Restart Cities: Skylines II after installing the CCTV asset package.";
        private string m_FixedStatus = "Import your normal camera as an Object asset named Lively Fixed CCTV, then restart the game.";
        private string m_AlprStatus = "Import an Object asset named Lively ALPR Camera, then restart the game.";
        private AlprPassBySystem m_AlprSystem;
        private int m_DiscoveryTicks;
        private static readonly PropertyInfo s_PrefabsProperty = typeof(PrefabSystem).GetProperty(
            "prefabs", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        private static readonly FieldInfo s_RenderBoundsField = typeof(RenderPrefab).GetField(
            "m_Bounds", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        private static readonly FieldInfo s_BoundsMinField = s_RenderBoundsField?.FieldType.GetField("min");
        private static readonly FieldInfo s_BoundsMaxField = s_RenderBoundsField?.FieldType.GetField("max");

        protected override void OnCreate()
        {
            base.OnCreate();
            m_ToolSystem = World.GetOrCreateSystemManaged<ToolSystem>();
            m_ObjectTool = World.GetOrCreateSystemManaged<ObjectToolSystem>();
            m_PrefabSystem = World.GetOrCreateSystemManaged<PrefabSystem>();
            m_AlprSystem = World.GetOrCreateSystemManaged<AlprPassBySystem>();
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "cctvStatus", () => m_Status));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "fixedCctvStatus", () => m_FixedStatus));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "alprStatus", () => FindAlprPrefab() == null ? m_AlprStatus : m_AlprSystem.Status));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "cctvAvailable", () => FindCameraPrefab() != null));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "fixedCctvAvailable", () => FindFixedCameraPrefab() != null));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "alprAvailable", () => FindAlprPrefab() != null));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "alprTotalReads", () => m_AlprSystem.TotalReads));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "alprFlaggedReads", () => m_AlprSystem.FlaggedReads));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "alprPassRows", () => m_AlprSystem.Rows));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "cctvPlacementActive", () => m_ToolSystem != null && m_ToolSystem.activeTool == m_ObjectTool));
            AddBinding(new TriggerBinding(kGroup, "placeCctv", ActivatePlacement));
            AddBinding(new TriggerBinding(kGroup, "placeFixedCctv", ActivateFixedPlacement));
            AddBinding(new TriggerBinding(kGroup, "placeAlprCctv", ActivateAlprPlacement));
            AddBinding(new TriggerBinding(kGroup, "cancelCctvPlacement", CancelPlacement));
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 16;

        protected override void OnUpdate()
        {
            // Discover/register independently of the CCTV page's value bindings so every
            // camera contributes to the shared coverage system throughout the city session.
            if (++m_DiscoveryTicks < 8) return;
            m_DiscoveryTicks = 0;
            FindCameraPrefab();
            FindFixedCameraPrefab();
            FindAlprPrefab();
        }

        private ObjectPrefab FindCameraPrefab()
        {
            if (m_CameraPrefab != null)
            {
                RegisterCameraPrefab(m_CameraPrefab);
                return m_CameraPrefab;
            }
            if (m_PrefabSystem == null || s_PrefabsProperty == null) return null;
            IEnumerable<PrefabBase> prefabs;
            try { prefabs = s_PrefabsProperty.GetValue(m_PrefabSystem) as IEnumerable<PrefabBase>; }
            catch (Exception) { return null; }
            if (prefabs == null) return null;

            ObjectPrefab best = null;
            int bestScore = 0;
            foreach (PrefabBase prefab in prefabs)
            {
                if (!(prefab is ObjectPrefab objectPrefab) || prefab.name == null) continue;
                string name = prefab.name.Replace("_", " ").Replace("-", " ");
                if (IsFixedCameraName(name)) continue;
                // Prefer a deliberately named replacement over old generic "source"
                // imports. Keep the asset-token fallback only for legacy saves.
                // Only bind the explicitly named imports. Old generic `source` imports can
                // point at a different camera mesh and make the placement button show the
                // wrong or nearly invisible prop.
                int score = name.IndexOf("Lively Mobile CCTV", StringComparison.OrdinalIgnoreCase) >= 0 ? 5 :
                    name.IndexOf("Mobile CCTV", StringComparison.OrdinalIgnoreCase) >= 0 ? 4 :
                    (name.IndexOf("MobileCCTV", StringComparison.OrdinalIgnoreCase) >= 0 ||
                     PrefabMatchesAsset(prefab, "MobileCCTV")) ? 3 : 0;
                if (score > bestScore) { best = objectPrefab; bestScore = score; }
            }
            if (best != null)
            {
                m_CameraPrefab = best;
                RegisterCameraPrefab(m_CameraPrefab);
                if (m_PoliceMenuRegistered.Count == 0)
                    m_Status = $"Camera ready: {best.name}. {VisualSizeNote(m_CameraPrefab, "MobileCCTV.fbx")}";
                return m_CameraPrefab;
            }
            m_Status = "Mobile CCTV asset not loaded. Import it as a separately named Object asset, then restart the game.";
            return null;
        }

        private ObjectPrefab FindFixedCameraPrefab()
        {
            if (m_FixedCameraPrefab != null)
            {
                RegisterCameraPrefab(m_FixedCameraPrefab);
                return m_FixedCameraPrefab;
            }
            if (m_PrefabSystem == null || s_PrefabsProperty == null) return null;
            IEnumerable<PrefabBase> prefabs;
            try { prefabs = s_PrefabsProperty.GetValue(m_PrefabSystem) as IEnumerable<PrefabBase>; }
            catch (Exception) { return null; }
            if (prefabs == null) return null;

            ObjectPrefab best = null;
            int bestScore = 0;
            foreach (PrefabBase prefab in prefabs)
            {
                if (!(prefab is ObjectPrefab objectPrefab) || prefab.name == null) continue;
                string name = prefab.name.Replace("_", " ").Replace("-", " ");
                int score = name.IndexOf("Lively Fixed CCTV", StringComparison.OrdinalIgnoreCase) >= 0 ? 5 :
                    (name.IndexOf("Fixed CCTV", StringComparison.OrdinalIgnoreCase) >= 0 ||
                     name.IndexOf("Standard CCTV", StringComparison.OrdinalIgnoreCase) >= 0) ? 4 :
                    (name.IndexOf("FixedCCTV", StringComparison.OrdinalIgnoreCase) >= 0 ||
                     PrefabMatchesAsset(prefab, "FixedCCTV")) ? 3 : 0;
                if (score > bestScore) { best = objectPrefab; bestScore = score; }
            }
            if (best == null) return null;
            m_FixedCameraPrefab = best;
            RegisterCameraPrefab(m_FixedCameraPrefab);
            m_FixedStatus = $"Standard camera ready: {best.name}. {VisualSizeNote(m_FixedCameraPrefab, "FixedCCTV.fbx")}";
            return m_FixedCameraPrefab;
        }

        private static bool IsFixedCameraName(string name) =>
            name.IndexOf("Lively Fixed CCTV", StringComparison.OrdinalIgnoreCase) >= 0 ||
            name.IndexOf("Fixed CCTV", StringComparison.OrdinalIgnoreCase) >= 0 ||
            name.IndexOf("Standard CCTV", StringComparison.OrdinalIgnoreCase) >= 0 ||
            name.IndexOf("FixedCCTV", StringComparison.OrdinalIgnoreCase) >= 0;

        private ObjectPrefab FindAlprPrefab()
        {
            if (m_AlprPrefab != null)
            {
                RegisterCameraPrefab(m_AlprPrefab);
                if (m_PrefabSystem.TryGetEntity(m_AlprPrefab, out Unity.Entities.Entity cachedAlprEntity))
                    CctvCrimeCoverage.RegisterAlprPrefab(cachedAlprEntity);
                return m_AlprPrefab;
            }
            if (m_PrefabSystem == null || s_PrefabsProperty == null) return null;
            IEnumerable<PrefabBase> prefabs;
            try { prefabs = s_PrefabsProperty.GetValue(m_PrefabSystem) as IEnumerable<PrefabBase>; }
            catch (Exception) { return null; }
            if (prefabs == null) return null;
            ObjectPrefab best = null;
            int bestScore = 0;
            foreach (PrefabBase prefab in prefabs)
            {
                if (!(prefab is ObjectPrefab objectPrefab) || prefab.name == null) continue;
                string name = prefab.name.Replace("_", " ").Replace("-", " ");
                int score = name.IndexOf("Lively ALPR Camera", StringComparison.OrdinalIgnoreCase) >= 0 ? 5 :
                    name.IndexOf("ALPR Camera", StringComparison.OrdinalIgnoreCase) >= 0 ? 4 :
                    (name.IndexOf("ALPRCamera", StringComparison.OrdinalIgnoreCase) >= 0 ||
                     PrefabMatchesAsset(prefab, "ALPRCamera")) ? 3 : 0;
                if (score > bestScore) { best = objectPrefab; bestScore = score; }
            }
            if (best == null) return null;
            m_AlprPrefab = best;
            RegisterCameraPrefab(m_AlprPrefab);
            if (m_PrefabSystem.TryGetEntity(m_AlprPrefab, out Unity.Entities.Entity selectedAlprEntity))
                CctvCrimeCoverage.RegisterAlprPrefab(selectedAlprEntity);
            m_AlprStatus = $"ALPR camera ready: {best.name}. {VisualSizeNote(m_AlprPrefab, "ALPRCamera.fbx")}";
            return m_AlprPrefab;
        }

        private static bool PrefabMatchesAsset(PrefabBase prefab, string assetToken)
        {
            if (prefab == null || prefab.asset == null || string.IsNullOrEmpty(assetToken)) return false;
            var asset = prefab.asset;
            return ContainsAssetToken(asset.path, assetToken) ||
                ContainsAssetToken(asset.subPath, assetToken) ||
                ContainsAssetToken(asset.name, assetToken) ||
                ContainsAssetToken(asset.uniqueName, assetToken) ||
                ContainsAssetToken(asset.identifier, assetToken) ||
                ContainsAssetToken(asset.uri, assetToken);
        }

        private static bool ContainsAssetToken(string value, string token) =>
            !string.IsNullOrEmpty(value) && value.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0;

        private static float GetVisualHeight(ObjectPrefab prefab)
        {
            if (!(prefab is StaticObjectPrefab staticPrefab) || staticPrefab.m_Meshes == null || s_RenderBoundsField == null)
                return 0f;
            float height = 0f;
            foreach (ObjectMeshInfo meshInfo in staticPrefab.m_Meshes)
            {
                if (meshInfo?.m_Mesh is RenderPrefab renderPrefab)
                {
                    try
                    {
                        object bounds = s_RenderBoundsField.GetValue(renderPrefab);
                        Unity.Mathematics.float3 min = (Unity.Mathematics.float3)s_BoundsMinField.GetValue(bounds);
                        Unity.Mathematics.float3 max = (Unity.Mathematics.float3)s_BoundsMaxField.GetValue(bounds);
                        height = Math.Max(height, max.y - min.y);
                    }
                    catch (Exception) { }
                }
            }
            return height;
        }

        private static string VisualSizeNote(ObjectPrefab prefab, string importAsset)
        {
            float height = GetVisualHeight(prefab);
            if (height <= 0f) return "Mesh size could not be read; test the placement preview before committing.";
            if (height < 0.25f)
                return $"This imported mesh is only {height * 100f:0.#} cm tall, so it will be nearly invisible in game. Reimport {importAsset} as a Static Object and name it for this camera before placing.";
            return $"Mesh height: {height:0.##} m. Choose Place, then click the ground. Use Bulldoze to remove it.";
        }

        private void RegisterCameraPrefab(ObjectPrefab prefab)
        {
            if (prefab == null || !m_PrefabSystem.TryGetEntity(prefab, out Unity.Entities.Entity prefabEntity)) return;
            CctvCrimeCoverage.RegisterCameraPrefab(prefabEntity);
            RegisterInPoliceMenu(prefabEntity);
        }

        /// <summary>
        /// The imported camera is a static prop, so it has no native Police service menu entry.
        /// Add the game's UIObjectData to its prefab entity and copy the category used by an
        /// existing Police station. The toolbar menu is composed of nested groups, so this avoids
        /// guessing from display names and targets the same category as the visible Police assets.
        /// </summary>
        private void RegisterInPoliceMenu(Unity.Entities.Entity prefabEntity)
        {
            if (m_PoliceMenuRegistered.Contains(prefabEntity) || m_PrefabSystem == null || !World.EntityManager.Exists(prefabEntity)) return;
            Unity.Entities.Entity policeGroup = FindPoliceGroup();
            if (policeGroup == Unity.Entities.Entity.Null)
            {
                if (m_FixedCameraPrefab != null && prefabEntity == GetPrefabEntity(m_FixedCameraPrefab))
                    m_FixedStatus = "Camera is loaded, but no Police asset category could be resolved. Use the CCTV page placement button.";
                else if (m_AlprPrefab != null && prefabEntity == GetPrefabEntity(m_AlprPrefab))
                    m_AlprStatus = "Camera is loaded, but no Police asset category could be resolved. Use the CCTV page placement button.";
                else
                    m_Status = "Camera is loaded, but no Police asset category could be resolved. Use the CCTV page placement button.";
                return;
            }

            var entityManager = World.EntityManager;
            var menuData = new UIObjectData { m_Group = policeGroup, m_Priority = 0 };
            if (entityManager.HasComponent<UIObjectData>(prefabEntity))
                entityManager.SetComponentData(prefabEntity, menuData);
            else
                entityManager.AddComponentData(prefabEntity, menuData);

            m_PoliceGroupEntity = policeGroup;
            m_PoliceMenuRegistered.Add(prefabEntity);
            string registrationStatus = "Camera registered in the Police asset category. Select it to place; use Bulldoze to remove it.";
            if (m_FixedCameraPrefab != null && prefabEntity == GetPrefabEntity(m_FixedCameraPrefab))
                m_FixedStatus = registrationStatus;
            else if (m_AlprPrefab != null && prefabEntity == GetPrefabEntity(m_AlprPrefab))
                m_AlprStatus = registrationStatus;
            else
                m_Status = registrationStatus;
        }

        private Unity.Entities.Entity GetPrefabEntity(ObjectPrefab prefab) =>
            prefab != null && m_PrefabSystem.TryGetEntity(prefab, out Unity.Entities.Entity entity) ? entity : Unity.Entities.Entity.Null;

        private Unity.Entities.Entity FindPoliceGroup()
        {
            var entityManager = World.EntityManager;
            if (m_PoliceGroupEntity != Unity.Entities.Entity.Null && entityManager.Exists(m_PoliceGroupEntity))
                return m_PoliceGroupEntity;
            if (m_PrefabSystem == null || s_PrefabsProperty == null) return Unity.Entities.Entity.Null;
            IEnumerable<PrefabBase> prefabs;
            try { prefabs = s_PrefabsProperty.GetValue(m_PrefabSystem) as IEnumerable<PrefabBase>; }
            catch (Exception) { return Unity.Entities.Entity.Null; }
            if (prefabs == null) return Unity.Entities.Entity.Null;

            // Match the precise group on a real Police building. This is the category the
            // Police panel already uses for its placeable assets.
            foreach (PrefabBase prefab in prefabs)
            {
                if (!(prefab is BuildingPrefab) || !m_PrefabSystem.TryGetEntity(prefab, out Unity.Entities.Entity buildingEntity)) continue;
                if (!entityManager.HasComponent<PoliceStationData>(buildingEntity) || !entityManager.HasComponent<UIObjectData>(buildingEntity)) continue;
                Unity.Entities.Entity group = entityManager.GetComponentData<UIObjectData>(buildingEntity).m_Group;
                if (group != Unity.Entities.Entity.Null && entityManager.Exists(group))
                    return m_PoliceGroupEntity = group;
            }
            return Unity.Entities.Entity.Null;
        }

        private void ActivatePlacement()
        {
            ObjectPrefab prefab = FindCameraPrefab();
            if (prefab == null) return;
            if (!m_ObjectTool.TrySetPrefab(prefab))
            {
                m_Status = "The game rejected the CCTV prefab for object placement. Check the asset's Asset Editor type.";
                return;
            }
            m_ToolSystem.activeTool = m_ObjectTool;
            m_Status = $"CCTV placement active. {VisualSizeNote(prefab, "MobileCCTV.fbx")} Press Esc to cancel; use Bulldoze to remove it.";
        }

        private void ActivateFixedPlacement()
        {
            ObjectPrefab prefab = FindFixedCameraPrefab();
            if (prefab == null)
            {
                m_FixedStatus = "Standard camera asset not loaded. Import it as an Object asset named Lively Fixed CCTV, then restart the game.";
                return;
            }
            if (!m_ObjectTool.TrySetPrefab(prefab))
            {
                m_FixedStatus = "The game rejected the standard CCTV prefab for object placement. Check that the imported asset is an Object prop.";
                return;
            }
            m_ToolSystem.activeTool = m_ObjectTool;
            m_FixedStatus = $"Standard CCTV placement active. {VisualSizeNote(prefab, "FixedCCTV.fbx")} Press Esc to cancel; use Bulldoze to remove it.";
        }

        private void ActivateAlprPlacement()
        {
            ObjectPrefab prefab = FindAlprPrefab();
            if (prefab == null)
            {
                m_AlprStatus = "ALPR asset not loaded. Import it as an Object named Lively ALPR Camera, then restart the game.";
                return;
            }
            if (!m_ObjectTool.TrySetPrefab(prefab))
            {
                m_AlprStatus = "The game rejected the ALPR prefab. Confirm it was imported as an Object prop.";
                return;
            }
            m_ToolSystem.activeTool = m_ObjectTool;
            m_AlprStatus = $"ALPR placement active. {VisualSizeNote(prefab, "ALPRCamera.fbx")} Place it near a road for modeled traffic reads.";
        }

        private void CancelPlacement()
        {
            if (m_ToolSystem != null && m_ToolSystem.activeTool == m_ObjectTool)
                m_ToolSystem.activeTool = null;
            m_Status = "CCTV placement cancelled. Use the bulldozer to remove placed cameras.";
        }
    }
}
