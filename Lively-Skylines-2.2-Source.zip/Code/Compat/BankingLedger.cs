using System;
using System.Collections.Generic;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Session-level, fictional city banking model attached to real city building entities.</summary>
    public static class BankingLedger
    {
        public sealed class Bank
        {
            public Entity Building;
            public string Name;
            public string Area;
            public long Reserves = 2840000;
            public long EquityExposure;
            public float Rate = 6.4f;
            public bool RescueEnabled = true;
            public int DefaultTermMonths = 24;
            public int GraceMonths = 2;
            public bool RequireAudit = true;
            public bool SecureWithCollateral = false;
            public bool ProtectPayroll = true;
            public float OriginationFeePercent = 1f;
            public int Rescued;
        }

        public sealed class Business
        {
            public Entity Building;
            public string Name;
            public string Area;
            public string Kind;
            public long Debt;
            public long MonthlyLoss;
            public int Jobs;
            public int CashDays;
            public int Rating;
            public string Grade;
            public string Status;
            public bool Rescued;
        }

        public sealed class Loan
        {
            public string Business;
            public long Amount;
            public long Balance;
            public float Rate;
            public int TermMonths;
            public int PaidPercent;
            public string Status;
            public uint LastPaymentFrame;
            public int GraceRemaining;
            public int MissedPayments;
            public Bank Lender;
            public bool PayrollProtected;
            public int MonthsElapsed;
            public bool ChargedOff;
        }

        private static readonly List<Bank> s_Banks = new List<Bank>();
        private static readonly List<Business> s_Businesses = new List<Business>();
        private static readonly List<Loan> s_Loans = new List<Loan>();
        private static Bank s_SelectedBank;
        private static long s_TotalIssued;
        private static int s_Distressed;
        private static int s_JobsSaved;

        public static Bank SelectedBank => s_SelectedBank;
        public static string MayorBankName => s_SelectedBank?.Name ?? "No bank selected";
        public static int BankCount => s_Banks.Count;
        public static int DistressedCount => s_Distressed;
        public static int RescuedCount { get; private set; }
        public static string DefaultRate => (s_SelectedBank?.Rate ?? 6.4f).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture);
        public static bool RescueEnabled => s_SelectedBank == null || s_SelectedBank.RescueEnabled;
        public static long Reserves => s_SelectedBank?.Reserves ?? 0;
        public static long LoansOutstanding
        {
            get { long total = 0; foreach (Loan loan in s_Loans) if (loan.Status != "PAID") total += loan.Balance; return total; }
        }
        public static string Stats => $"{Reserves}|{LoansOutstanding}|{s_Distressed}|{DefaultRate}|{RescuedCount}|{s_Loans.Count}|{s_JobsSaved}";
        public static string SelectedBankSettings => s_SelectedBank == null ? "24|2|1|0|1|1" : $"{s_SelectedBank.DefaultTermMonths}|{s_SelectedBank.GraceMonths}|{(s_SelectedBank.RequireAudit ? 1 : 0)}|{(s_SelectedBank.SecureWithCollateral ? 1 : 0)}|{(s_SelectedBank.ProtectPayroll ? 1 : 0)}|{s_SelectedBank.OriginationFeePercent.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)}";

        public static void RegisterBank(Entity building, string name, string area)
        {
            if (building == Entity.Null) return;
            foreach (Bank existing in s_Banks) if (existing.Building == building) { existing.Name = name; existing.Area = area; return; }
            var bank = new Bank { Building = building, Name = Clean(name), Area = Clean(area) };
            s_Banks.Add(bank);
            if (s_SelectedBank == null) s_SelectedBank = bank;
        }

        public static void DesignateBank(Entity building, string name, string area, uint frame)
        {
            if (building == Entity.Null) return;
            RegisterBank(building, name, area);
            foreach (Bank bank in s_Banks) if (bank.Building == building) s_SelectedBank = bank;
            CityBuzzFeed.Add("Bank opened", "City finance", name, $"{name} was designated as a modeled city bank at its existing city address. Banking activity is simulated by Lively Skylines.", frame);
        }

        public static void SelectBank(int index)
        {
            if (index >= 0 && index < s_Banks.Count) s_SelectedBank = s_Banks[index];
        }

        public static string BankRows
        {
            get
            {
                var rows = new List<string>();
                for (int i = 0; i < s_Banks.Count; i++)
                {
                    Bank bank = s_Banks[i];
                    rows.Add($"{i}|{Safe(bank.Name)}|{Safe(bank.Area)}|{bank.Reserves}|{LoansFor(bank)}|{bank.Rate.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)}|{(bank.RescueEnabled ? 1 : 0)}|{(bank == s_SelectedBank ? 1 : 0)}");
                }
                return string.Join("\n", rows);
            }
        }

        public static void RefreshBusinesses(IEnumerable<Business> businesses)
        {
            s_Businesses.Clear();
            s_Distressed = 0;
            foreach (Business business in businesses)
            {
                Loan loan = FindLoan(business.Name);
                if (loan != null) business.Status = loan.Status == "DEFAULT" ? "Bankrupt" : loan.Status == "DEFAULT RISK" ? "DEFAULT RISK" : loan.Status;
                if (s_ClosedBusinesses.Contains(business.Name)) business.Status = "Closed";
                else if (s_CounterOffers.Contains(business.Name) && loan == null) business.Status = "Counter-offer";
                if (business.Rescued || IsRescued(business.Building)) business.Rescued = true;
                if (!business.Rescued && business.Status != "Stable") s_Distressed++;
                s_Businesses.Add(business);
            }
        }

        private static readonly HashSet<Entity> s_RescuedBuildings = new HashSet<Entity>();
        private static readonly HashSet<string> s_ClosedBusinesses = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private static readonly HashSet<string> s_CounterOffers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private static bool IsRescued(Entity building) => s_RescuedBuildings.Contains(building);

        public static string BusinessRows
        {
            get
            {
                var rows = new List<string>();
                for (int i = 0; i < s_Businesses.Count; i++)
                {
                    Business b = s_Businesses[i];
                    rows.Add($"{i}|{Safe(b.Name)}|{Safe(b.Area)}|{Safe(b.Kind)}|{b.Debt}|{b.MonthlyLoss}|{Safe(b.Grade)}|{Safe(b.Status)}|{b.Jobs}|{b.CashDays}|{(b.Rescued ? 1 : 0)}");
                }
                return string.Join("\n", rows);
            }
        }

        public static string LoanRows
        {
            get
            {
                var rows = new List<string>();
                int start = Math.Max(0, s_Loans.Count - 50);
                for (int i = s_Loans.Count - 1; i >= start; i--)
                {
                    Loan loan = s_Loans[i];
                    long monthly = MonthlyPayment(loan);
                    rows.Add($"{i}|{Safe(loan.Business)}|{loan.Amount}|{loan.Rate.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)}|{loan.PaidPercent}|{loan.Status}|{loan.Balance}|{loan.TermMonths}|{monthly}|{loan.GraceRemaining}|{loan.MissedPayments}");
                }
                return string.Join("\n", rows);
            }
        }

        public static string CreditRows
        {
            get
            {
                var rows = new List<string>();
                foreach (Business b in s_Businesses) rows.Add($"{Safe(b.Name)}|{Safe(b.Area)}|{Safe(b.Grade)}|{b.Rating}|{Safe(b.Status)}|{b.Debt}|{b.Jobs}");
                return string.Join("\n", rows);
            }
        }

        public static void OfferLoan(int businessIndex, int amount, uint frame)
        {
            if (s_SelectedBank == null || businessIndex < 0 || businessIndex >= s_Businesses.Count) return;
            Business business = s_Businesses[businessIndex];
            if (amount <= 0 || s_SelectedBank.Reserves < amount)
            {
                CityBuzzFeed.Add("Loan declined", "City finance", business.Name, "The selected bank does not have enough modeled reserves to fund this loan.", frame);
                return;
            }
            Loan existing = FindLoan(business.Name);
            if (existing != null && existing.Status != "PAID")
            {
                CityBuzzFeed.Add("Loan declined", "City finance", business.Name, "This business already has an open modeled loan. Restructure it or make payments before borrowing again.", frame);
                return;
            }
            long fee = (long)(amount * s_SelectedBank.OriginationFeePercent / 100f);
            s_SelectedBank.Reserves -= amount;
            s_SelectedBank.Reserves += fee;
            s_TotalIssued += amount;
            s_Loans.Add(new Loan { Business = business.Name, Amount = amount, Balance = amount, Rate = s_SelectedBank.Rate, TermMonths = s_SelectedBank.DefaultTermMonths, GraceRemaining = s_SelectedBank.GraceMonths, Status = "ON TRACK", LastPaymentFrame = frame, Lender = s_SelectedBank, PayrollProtected = s_SelectedBank.ProtectPayroll });
            business.Status = "Recovering";
            s_ClosedBusinesses.Remove(business.Name);
            s_CounterOffers.Remove(business.Name);
            business.Rescued = true;
            s_RescuedBuildings.Add(business.Building);
            RescuedCount++;
            s_JobsSaved += business.Jobs;
            CityBuzzFeed.Add("Business loan approved", "City finance", business.Name, $"{s_SelectedBank.Name} approved a modeled ${amount:N0} loan at {s_SelectedBank.Rate:0.0}% APR over {s_SelectedBank.DefaultTermMonths} months with {s_SelectedBank.GraceMonths} grace months. Modeled origination fee: ${fee:N0}. The loan is recorded in the city loan book; the underlying business asset is unchanged.", frame);
            PublicReactionLedger.Add("Local business loan approved", -1);
        }

        public static void RescueBusiness(int businessIndex, int option, int requestedAmount, uint frame)
        {
            if (s_SelectedBank == null || !s_SelectedBank.RescueEnabled || businessIndex < 0 || businessIndex >= s_Businesses.Count) return;
            Business business = s_Businesses[businessIndex];
            if (option == 6)
            {
                business.Status = "Counter-offer";
                s_CounterOffers.Add(business.Name);
                CityBuzzFeed.Add("Rescue counter-offer", "City finance", business.Name, $"{business.Name} requested a revised modeled rescue package from {s_SelectedBank.Name}. A city finance review is now pending.", frame);
                return;
            }
            if (option == 7)
            {
                business.Status = "Closed";
                s_ClosedBusinesses.Add(business.Name);
                s_CounterOffers.Remove(business.Name);
                business.CashDays = 0;
                CityBuzzFeed.Add("Business rescue declined", "City finance", business.Name, $"{s_SelectedBank.Name} declined a rescue package for {business.Name}. The business is marked closed in the mod's financial simulation; the underlying city building remains unchanged.", frame);
                PublicReactionLedger.Add("Business closure after failed rescue", 3);
                return;
            }
            long amount = Math.Max(5000, Math.Min(500000, requestedAmount));
            if (option == 2) amount = Math.Min(amount, 75000);
            if (option == 3) amount = Math.Min(amount, 200000);
            if (s_SelectedBank.Reserves < amount)
            {
                CityBuzzFeed.Add("Rescue plan declined", "City finance", business.Name, "The selected bank does not have enough modeled reserves for this rescue plan.", frame);
                return;
            }
            if (s_SelectedBank.RequireAudit && business.Rating < 420)
            {
                CityBuzzFeed.Add("Rescue review paused", "City finance", business.Name, $"{s_SelectedBank.Name} requires an independent audit before approving a package for a business with a modeled credit score below 420. Disable the audit covenant or improve the city's business record to continue.", frame);
                return;
            }
            if (s_SelectedBank.SecureWithCollateral && amount > Math.Max(10000, business.Debt * 3 / 2))
            {
                CityBuzzFeed.Add("Rescue review paused", "City finance", business.Name, $"The requested ${amount:N0} package exceeds the modeled collateral limit for {business.Name}. Lower the offer or remove the collateral condition.", frame);
                return;
            }
            s_SelectedBank.Reserves -= amount;
            if (option == 0)
            {
                AddLoan(business, amount, s_SelectedBank.Rate, s_SelectedBank.DefaultTermMonths, frame);
            }
            else if (option == 1)
            {
                Loan existing = FindLoan(business.Name);
                if (existing != null)
                {
                    existing.Amount += amount;
                    existing.Balance += amount;
                    existing.Rate = Math.Max(1f, s_SelectedBank.Rate - 0.8f);
                    existing.TermMonths = Math.Max(36, s_SelectedBank.DefaultTermMonths);
                    existing.GraceRemaining = s_SelectedBank.GraceMonths;
                    existing.MissedPayments = 0;
                    existing.Status = "ON TRACK";
                    existing.LastPaymentFrame = frame;
                }
                else AddLoan(business, amount, Math.Max(1f, s_SelectedBank.Rate - 0.8f), Math.Max(36, s_SelectedBank.DefaultTermMonths), frame);
            }
            else if (option == 2)
            {
                // Grant / subsidy is a direct transfer, not debt.
                business.CashDays = Math.Max(business.CashDays, 45);
            }
            else
            {
                if (option == 3)
                {
                    // A modeled equity stake is booked as an asset instead of a loan.
                    s_SelectedBank.EquityExposure += amount;
                    business.CashDays = Math.Max(business.CashDays, 35);
                }
                else if (option == 4)
                {
                    Loan existing = FindLoan(business.Name);
                    if (existing != null)
                    {
                        long forgiven = Math.Min(existing.Balance, amount / 2);
                        existing.Balance -= forgiven;
                        existing.Amount = Math.Max(existing.Balance, existing.Amount - forgiven);
                        existing.Status = existing.Balance == 0 ? "PAID" : "ON TRACK";
                    }
                    else AddLoan(business, amount * 2 / 3, s_SelectedBank.Rate, s_SelectedBank.DefaultTermMonths, frame);
                    business.CashDays = Math.Max(business.CashDays, 28);
                }
                else if (option == 5)
                {
                    business.MonthlyLoss = business.MonthlyLoss * 65 / 100;
                    business.CashDays = Math.Max(business.CashDays, 30);
                    business.Jobs = Math.Max(1, business.Jobs * 9 / 10);
                }
            }
            business.Status = "Recovering";
            s_ClosedBusinesses.Remove(business.Name);
            s_CounterOffers.Remove(business.Name);
            business.Rescued = true;
            business.CashDays = Math.Max(business.CashDays, 30);
            s_RescuedBuildings.Add(business.Building);
            RescuedCount++;
            s_JobsSaved += business.Jobs;
            string[] plans = { "Bridge loan", "Restructure debt", "Grant / subsidy", "City equity stake", "Partial forgiveness", "Merge with company" };
            string plan = plans[Math.Max(0, Math.Min(option, plans.Length - 1))];
            CityBuzzFeed.Add("Business rescue approved", "City finance", business.Name, $"{s_SelectedBank.Name} approved a modeled {plan.ToLowerInvariant()} for ${amount:N0}. The plan is recorded in the city loan book; the city building asset is unchanged.", frame);
            PublicReactionLedger.Add($"Business rescue · {plan}", -3);
        }

        public static void ApplySetting(int setting, int value)
        {
            if (s_SelectedBank == null) return;
            if (setting == 0) s_SelectedBank.Rate = Math.Max(1f, Math.Min(20f, value / 10f));
            if (setting == 1) s_SelectedBank.RescueEnabled = value != 0;
            if (setting == 2) s_SelectedBank.DefaultTermMonths = Math.Max(6, Math.Min(60, value));
            if (setting == 3) s_SelectedBank.GraceMonths = Math.Max(0, Math.Min(12, value));
            if (setting == 4) s_SelectedBank.RequireAudit = value != 0;
            if (setting == 5) s_SelectedBank.SecureWithCollateral = value != 0;
            if (setting == 6) s_SelectedBank.ProtectPayroll = value != 0;
            if (setting == 7) s_SelectedBank.OriginationFeePercent = Math.Max(0f, Math.Min(5f, value / 10f));
        }

        public static void Advance(uint frame)
        {
            foreach (Loan loan in s_Loans)
            {
                if (loan.Status == "PAID" || frame < loan.LastPaymentFrame || frame - loan.LastPaymentFrame < OutingStarter.FramesPerDay * 30u) continue;
                loan.LastPaymentFrame = frame;
                if (loan.GraceRemaining > 0)
                {
                    loan.GraceRemaining--;
                    loan.MonthsElapsed++;
                    CityBuzzFeed.Add("Loan grace period", "City finance", loan.Business, $"A scheduled payment was deferred under the modeled grace period. {loan.GraceRemaining} grace month(s) remain.", frame);
                    continue;
                }
                Business business = FindBusiness(loan.Business);
                long payment = MonthlyPayment(loan);
                if (business != null && (business.CashDays <= (loan.PayrollProtected ? 1 : 3) || business.MonthlyLoss > payment * 2))
                {
                    loan.MissedPayments++;
                    loan.Status = loan.MissedPayments >= 6 && !loan.PayrollProtected ? "DEFAULT" : loan.MissedPayments >= 3 ? "DEFAULT RISK" : "LATE";
                    if (loan.PayrollProtected && business != null) business.CashDays = Math.Max(1, business.CashDays);
                    if (loan.Status == "DEFAULT") s_ClosedBusinesses.Add(loan.Business);
                    if (loan.Status == "DEFAULT" && !loan.ChargedOff && loan.Lender != null)
                    {
                        loan.ChargedOff = true;
                        long loss = loan.Balance * (loan.Lender.SecureWithCollateral ? 3 : 6) / 10;
                        loan.Lender.Reserves -= loss;
                        s_Defaults++;
                        CityBuzzFeed.Add("Loan written off", "City finance", loan.Business, $"{loan.Lender.Name} wrote off ${loss:N0} after {loan.Business} defaulted.{(loan.Lender.SecureWithCollateral ? " Collateral recovered part of the balance." : "")}", frame);
                    }
                    CityBuzzFeed.Add(loan.Status == "LATE" ? "Loan payment missed" : "Loan default warning", "City finance", loan.Business, $"The modeled monthly payment of ${payment:N0} exceeds the business's current repayment capacity. Missed payments: {loan.MissedPayments}. The loan remains in the city loan book for review.", frame);
                    continue;
                }
                long interest = Math.Max(1, loan.Balance * (long)loan.Rate / 1200L);
                long principal = Math.Max(0, payment - interest);
                loan.Balance = Math.Max(0, loan.Balance - principal);
                loan.MonthsElapsed++;
                loan.PaidPercent = loan.Amount > 0 ? (int)Math.Min(100, (loan.Amount - loan.Balance) * 100 / loan.Amount) : 100;
                loan.MissedPayments = 0;
                loan.Status = loan.Balance == 0 ? "PAID" : "ON TRACK";
                if (loan.Lender != null) loan.Lender.Reserves += Math.Min(payment, loan.Balance + interest);
                CityBuzzFeed.Add("Loan payment posted", "City finance", loan.Business, loan.Status == "PAID" ? "The modeled loan has been repaid in full." : $"A modeled monthly payment of ${payment:N0} posted (${interest:N0} interest, ${principal:N0} principal). Remaining balance: ${loan.Balance:N0}.", frame);
            }
        }

        // ===================== City treasury: deposits, bonds, credit rating, grants =====================
        public sealed class Bond { public long Amount; public float Rate; public int MonthsLeft; }
        private static readonly List<Bond> s_Bonds = new List<Bond>();
        private static long s_CityDeposits;
        private static int s_Defaults;
        private static bool s_GrantFund;
        private static int s_GrantsGiven;
        private static uint s_LastTreasuryFrame;
        private static long s_CityMoney;
        private static int s_BankFailures;
        private const float kDepositRate = 3.0f;
        private const long kGrantFundMonthly = 20000;

        public static void EnsureFallbackBank()
        {
            if (s_SelectedBank != null) return;
            var bank = new Bank { Building = Entity.Null, Name = "City Treasury Bank", Area = "City Hall" };
            s_Banks.Add(bank);
            s_SelectedBank = bank;
        }

        public static long BondsOutstanding { get { long n = 0; foreach (Bond b in s_Bonds) n += b.Amount; return n; } }

        public static int CreditScore(int anger)
        {
            double score = 72 + Math.Min(15.0, s_CityMoney / 150000.0) - BondsOutstanding / 120000.0 * 3.0 - s_Defaults * 2.5 - anger / 8.0 - s_BankFailures * 8;
            if (s_SelectedBank != null && s_SelectedBank.Reserves > 1000000) score += 4;
            return (int)Math.Max(20, Math.Min(99, score));
        }

        public static string CreditGrade(int score) => score >= 90 ? "AAA" : score >= 82 ? "AA" : score >= 74 ? "A" : score >= 66 ? "BBB" : score >= 58 ? "BB" : score >= 50 ? "B" : "CCC";
        public static float BondRate(int score) => Math.Max(3f, Math.Min(12f, 3.2f + (90 - score) * 0.09f));

        /// <summary>action: 1 deposit, 2 withdraw, 3 issue bond, 4 repay oldest bond early, 5 toggle grant fund.</summary>
        public static void TreasuryAction(int action, int amount, uint frame, int anger, Func<int, bool> charge, Action<long> pay)
        {
            EnsureFallbackBank();
            Bank bank = s_SelectedBank;
            amount = Math.Max(0, amount);
            switch (action)
            {
                case 1:
                    if (amount <= 0 || !charge(amount)) { CityBuzzFeed.Add("Deposit failed", "City finance", bank.Name, "The city does not have enough money for that deposit.", frame); return; }
                    s_CityDeposits += amount; bank.Reserves += amount;
                    CityBuzzFeed.Add("City deposit", "City finance", bank.Name, $"The city deposited ${amount:N0} at {bank.Name}, earning {kDepositRate:0.0}% a year. The money is locked in the bank until withdrawn.", frame);
                    break;
                case 2:
                    long take = Math.Min(amount, s_CityDeposits);
                    if (take <= 0) return;
                    if (bank.Reserves < take) { CityBuzzFeed.Add("Withdrawal delayed", "City finance", bank.Name, $"{bank.Name} lacks the reserves to return ${take:N0} right now. Too much is tied up in loans.", frame); return; }
                    s_CityDeposits -= take; bank.Reserves -= take; pay(take);
                    CityBuzzFeed.Add("City withdrawal", "City finance", bank.Name, $"The city withdrew ${take:N0} from {bank.Name}.", frame);
                    break;
                case 3:
                    if (amount <= 0) return;
                    if (s_Bonds.Count >= 6) { CityBuzzFeed.Add("Bond sale blocked", "City finance", "City Hall", "The city already has six bond issues outstanding. Repay one before borrowing again.", frame); return; }
                    int score = CreditScore(anger);
                    float rate = BondRate(score);
                    s_Bonds.Add(new Bond { Amount = amount, Rate = rate, MonthsLeft = 24 });
                    pay(amount);
                    CityBuzzFeed.Add("Municipal bonds sold", "City finance", "City Hall", $"The city sold ${amount:N0} in 2-year bonds at {rate:0.0}% ({CreditGrade(score)} rating). Interest of ${(long)(amount * rate / 1200f):N0} is due every month, plus the full amount at maturity.", frame);
                    PublicReactionLedger.Add("City took on new bond debt", 1);
                    break;
                case 4:
                    if (s_Bonds.Count == 0) return;
                    Bond oldest = s_Bonds[0];
                    int cost = (int)Math.Min(int.MaxValue, oldest.Amount * 102 / 100);
                    if (!charge(cost)) { CityBuzzFeed.Add("Early repayment failed", "City finance", "City Hall", $"Repaying the bond early needs ${cost:N0} including a 2% call premium.", frame); return; }
                    s_Bonds.RemoveAt(0);
                    CityBuzzFeed.Add("Bonds repaid early", "City finance", "City Hall", $"The city repaid ${oldest.Amount:N0} of bonds early, paying a 2% premium to stop future interest.", frame);
                    break;
                case 5:
                    s_GrantFund = !s_GrantFund;
                    CityBuzzFeed.Add(s_GrantFund ? "Small-business grant fund opened" : "Small-business grant fund closed", "City finance", "City Hall",
                        s_GrantFund ? $"The city will spend ${kGrantFundMonthly:N0} a month rescuing the two most distressed local businesses." : "Monthly small-business grants have stopped.", frame);
                    break;
            }
        }

        /// <summary>Monthly city cash flow from the treasury: + deposit interest, - bond interest/principal, - grants.</summary>
        public static long TakeTreasuryCashflow(uint frame, long cityMoney)
        {
            s_CityMoney = cityMoney;
            EnsureFallbackBank();
            if (s_LastTreasuryFrame == 0 || frame < s_LastTreasuryFrame) { s_LastTreasuryFrame = frame; return 0; }
            if (frame - s_LastTreasuryFrame < OutingStarter.FramesPerDay * 30u) return 0;
            s_LastTreasuryFrame = frame;
            Bank bank = s_SelectedBank;
            long net = 0;
            long interest = (long)(s_CityDeposits * kDepositRate / 1200f);
            if (interest > 0) { bank.Reserves -= interest; net += interest; }
            // The bank earns its lending spread on reserves it holds.
            bank.Reserves += (long)(Math.Max(0, bank.Reserves) * Math.Max(0f, bank.Rate - kDepositRate) / 2400f);
            for (int i = s_Bonds.Count - 1; i >= 0; i--)
            {
                Bond b = s_Bonds[i];
                net -= (long)(b.Amount * b.Rate / 1200f);
                b.MonthsLeft--;
                if (b.MonthsLeft <= 0) { net -= b.Amount; s_Bonds.RemoveAt(i); CityBuzzFeed.Add("Bonds matured", "City finance", "City Hall", $"${b.Amount:N0} of city bonds matured and were repaid in full.", frame); }
            }
            if (s_GrantFund)
            {
                net -= kGrantFundMonthly;
                int helped = 0;
                foreach (Business biz in s_Businesses)
                {
                    if (helped >= 2) break;
                    if (biz.Rescued || biz.Status == "Stable" || biz.Status == "Closed") continue;
                    biz.CashDays = Math.Max(biz.CashDays, 45); biz.Status = "Recovering"; biz.Rescued = true;
                    s_RescuedBuildings.Add(biz.Building); RescuedCount++; s_JobsSaved += biz.Jobs; s_GrantsGiven++; helped++;
                    CityBuzzFeed.Add("Small-business grant", "City finance", biz.Name, $"{biz.Name} received a city grant, protecting {biz.Jobs} jobs.", frame);
                }
            }
            // Bank failure if reserves run out.
            if (bank.Reserves < 0)
            {
                long lost = s_CityDeposits * 3 / 10;
                s_CityDeposits -= lost; s_BankFailures++;
                bank.Reserves = 500000;
                CityBuzzFeed.Add("Bank failure", "City finance", bank.Name, $"{bank.Name} ran out of reserves after loan losses. The city lost ${lost:N0} of its deposits and the bank was recapitalized at $500,000.", frame);
                PublicReactionLedger.Add($"{bank.Name} failed", 8);
            }
            return net;
        }

        public static string TreasuryRow(int anger)
        {
            int score = CreditScore(anger);
            long coupons = 0; foreach (Bond b in s_Bonds) coupons += (long)(b.Amount * b.Rate / 1200f);
            long reserves = s_SelectedBank?.Reserves ?? 0, loans = s_SelectedBank != null ? LoansFor(s_SelectedBank) : 0;
            int liquidity = (int)Math.Max(0, Math.Min(100, (reserves + 1) * 100 / Math.Max(1, reserves + loans + s_CityDeposits)));
            var bonds = new List<string>();
            foreach (Bond b in s_Bonds) bonds.Add($"{b.Amount}~{b.Rate.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)}~{b.MonthsLeft}");
            return $"{score}|{CreditGrade(score)}|{BondRate(score).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)}|{s_CityDeposits}|{(long)(s_CityDeposits * kDepositRate / 1200f)}|{BondsOutstanding}|{coupons}|{(s_GrantFund ? 1 : 0)}|{s_GrantsGiven}|{s_Defaults}|{liquidity}|{s_BankFailures}|{s_CityMoney}|{string.Join(";", bonds)}|{Safe(s_SelectedBank?.Name ?? "City Treasury Bank")}";
        }

        private static Loan FindLoan(string name)
        {
            for (int i = s_Loans.Count - 1; i >= 0; i--) if (string.Equals(s_Loans[i].Business, name, StringComparison.OrdinalIgnoreCase) && s_Loans[i].Status != "PAID") return s_Loans[i];
            return null;
        }

        private static Business FindBusiness(string name)
        {
            foreach (Business business in s_Businesses) if (string.Equals(business.Name, name, StringComparison.OrdinalIgnoreCase)) return business;
            return null;
        }

        private static void AddLoan(Business business, long amount, float rate, int term, uint frame)
        {
            if (business == null || s_SelectedBank == null || amount <= 0) return;
            s_Loans.Add(new Loan { Business = business.Name, Amount = amount, Balance = amount, Rate = rate, TermMonths = Math.Max(1, term), GraceRemaining = s_SelectedBank.GraceMonths, Status = "ON TRACK", LastPaymentFrame = frame, Lender = s_SelectedBank, PayrollProtected = s_SelectedBank.ProtectPayroll });
        }

        private static long MonthlyPayment(Loan loan)
        {
            if (loan == null || loan.Balance <= 0) return 0;
            int months = Math.Max(1, loan.TermMonths - loan.MonthsElapsed);
            double monthlyRate = Math.Max(0.0001, loan.Rate / 1200.0);
            double payment = loan.Balance * monthlyRate / (1.0 - Math.Pow(1.0 + monthlyRate, -months));
            return Math.Max(500, (long)Math.Ceiling(payment));
        }

        private static long LoansFor(Bank bank)
        {
            long sum = 0;
            foreach (Loan loan in s_Loans) if (loan.Status != "PAID") sum += loan.Balance;
            return sum;
        }

        private static string Safe(string text) => (text ?? "").Replace("|", " ").Replace("\n", " ").Replace("\r", " ");
        private static string Clean(string text) => string.IsNullOrWhiteSpace(text) ? "City business" : Safe(text);
    }
}
