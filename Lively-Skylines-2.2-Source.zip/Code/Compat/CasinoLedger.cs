using System.Collections.Generic;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Session casino registrations backed by actual city building entities.</summary>
    public static class CasinoLedger
    {
        public sealed class Casino
        {
            public Entity Building;
            public string Name;
            public string District;
            public bool Open = true;
            public int Security = 2;
            public int GamingFloor = 2;
            public int Marketing = 1;
            public bool AllDay;
            public int LastVisitors;
            public int TotalVisitors;
            public long ModeledRevenue;
            public int SafetyReports;
            public uint LastSessionFrame;
            public string LastReport = "No session run yet.";
            // ---- Gaming floor & operations ----
            public int Slots = 2, Tables = 1, Poker, Sportsbook;
            public bool Hotel, Shows, ResponsibleGaming, Aml = true;
            public int Reputation = 50;
            public float AtRisk;
            public int AtRiskAlerted;
            public long CityProfit, LastNet, Handle, BiggestJackpot;
            public int Jackpots, Whales, CheatersCaught, Robberies, LaunderingBlocked, LaunderingMissed, Fines;
            public readonly List<string> Events = new List<string>();
            public void Log(string text) { Events.Insert(0, text.Replace("|", " ").Replace("~", " ")); if (Events.Count > 8) Events.RemoveAt(Events.Count - 1); }
        }

        private static readonly List<Casino> s_Casinos = new List<Casino>();
        public static IReadOnlyList<Casino> All => s_Casinos;
        public static int Count => s_Casinos.Count;

        public static bool Contains(Entity building)
        {
            for (int i = 0; i < s_Casinos.Count; i++) if (s_Casinos[i].Building == building) return true;
            return false;
        }

        public static bool TryCreate(Entity building, string name, string district)
        {
            if (building == Entity.Null || Contains(building)) return false;
            s_Casinos.Add(new Casino { Building = building, Name = name ?? "City casino", District = district ?? "City district" });
            return true;
        }

        public static Casino Get(int index) => index >= 0 && index < s_Casinos.Count ? s_Casinos[index] : null;
    }
}
