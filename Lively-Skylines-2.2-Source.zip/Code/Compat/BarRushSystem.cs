using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    public partial class BarRushSystem : GameSystemBase
    {
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;
        private float m_PreviousTime = -1f;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_CandidateQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            RequireForUpdate(m_CandidateQuery);
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            var settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.MidnightRushEnabled) return;
            float now = m_TimeSystem.normalizedTime;
            bool crossedMidnight = m_PreviousTime > 0.75f && now < 0.25f;
            m_PreviousTime = now;
            if (crossedMidnight) StartRush(settings);
        }

        private void StartRush(Setting settings)
        {
            if (settings.RushPercent <= 0) return;
            uint frame = m_SimulationSystem.frameIndex;
            var random = new Random(math.max(1u, frame * 2654435761u));
            uint baseOuting = OutingStarter.FramesPerDay / 12u;
            uint outing = baseOuting + (uint)(baseOuting * (settings.StayLongerPercent / 100f));
            using NativeArray<Entity> candidates = m_CandidateQuery.ToEntityArray(Allocator.Temp);
            int wanted = (candidates.Length * settings.RushPercent) / 100;
            int population = m_PopulationQuery.CalculateEntityCount();
            int cap = PopulationCap.MaxAttendees(population, settings.MaxAttendancePercent);
            int allowed = math.min(wanted, AttendanceLedger.Remaining(cap, frame));
            int started = OutingStarter.Start(EntityManager, candidates, allowed, ref random, frame, outing);
            AttendanceLedger.Add(started, frame + outing);
            if (started > 0)
            {
                ActiveEvents.Add("Midnight bar rush", "", started, frame + outing);
                CityBuzzFeed.Add("Nightlife", "Lively Skylines", "Citywide", $"The midnight bar rush brought {started:N0} sims out tonight.", frame);
            }
            Mod.log.Info($"Midnight bar rush: started {started} outings (wanted {wanted}, cap {cap}, population {population}).");
        }
    }
}
