using System.Collections.Generic;
using System.Reflection;
using Game.Common;
using Game.Net;
using Game.Prefabs;
using Game.Simulation;
using Game.Tools;
using Colossal.Serialization.Entities;
using Unity.Collections;
using UnityEngine;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Serializable marker so a closed road can be toggled open after loading a save.</summary>
    public struct ClosedRoadMarker : IComponentData, IQueryTypeParameter, IEmptySerializable { }

    /// <summary>
    /// Closes a selected road segment to vehicle pathfinding and requests a
    /// police patrol at its nearer endpoint. Clicking a closed segment reopens it.
    /// </summary>
    public partial class ShutDownRoadToolSystem : ToolBaseSystem
    {
        public override string toolID => "BarRush.ShutDownRoad";

        private PrefabBase m_UIPrefab;
        // `PrefabSystem.prefabs` is public in the current game version. The old
        // lookup only searched non-public properties, so it always returned
        // null and caused ToolSystem.activePrefab to throw when this tool was
        // selected from the road palette.
        private static readonly PropertyInfo s_PrefabsProperty = typeof(PrefabSystem).GetProperty(
            "prefabs", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

        // ToolUISystem asks the active tool for a prefab whenever it changes.
        // Returning null here crashes the game's toolbar/tool UI (including
        // when this tool is cancelled), even though this tool places no prefab.
        // Supply a real network prefab solely to satisfy that UI contract.
        public override PrefabBase GetPrefab()
        {
            if (m_UIPrefab != null) return m_UIPrefab;
            if (m_PrefabSystem == null || s_PrefabsProperty == null) return null;
            IEnumerable<PrefabBase> prefabs;
            try
            {
                prefabs = s_PrefabsProperty.GetValue(m_PrefabSystem) as IEnumerable<PrefabBase>;
            }
            catch (TargetInvocationException)
            {
                return null;
            }
            if (prefabs == null) return null;
            PrefabBase fallback = null;
            foreach (PrefabBase prefab in prefabs)
            {
                if (prefab == null) continue;
                if (fallback == null) fallback = prefab;
                if (prefab is NetPrefab)
                {
                    m_UIPrefab = prefab;
                    break;
                }
            }
            if (m_UIPrefab == null) m_UIPrefab = fallback;
            return m_UIPrefab;
        }

        public override bool TrySetPrefab(PrefabBase prefab) => false;

        public bool IsReady => GetPrefab() != null;

        protected override void OnCreate()
        {
            base.OnCreate();
            requireNet = Layer.Road;
            applyMode = ApplyMode.Apply;
            m_ToolSystem = World.GetOrCreateSystemManaged<ToolSystem>();
            if (!m_ToolSystem.tools.Contains(this)) m_ToolSystem.tools.Add(this);
        }

        public override void InitializeRaycast()
        {
            base.InitializeRaycast();
            // Keep the click target on visible road network geometry, including
            // the sub-elements returned by the road tool raycaster.
            m_ToolRaycastSystem.typeMask = TypeMask.Net;
            m_ToolRaycastSystem.netLayerMask = Layer.Road;
            m_ToolRaycastSystem.collisionMask = CollisionMask.OnGround | CollisionMask.Overground;
            m_ToolRaycastSystem.raycastFlags |= RaycastFlags.SubElements;
        }

        protected override void OnDestroy()
        {
            if (m_ToolSystem != null)
            {
                if (m_ToolSystem.activeTool == this) m_ToolSystem.activeTool = null;
                m_ToolSystem.tools.Remove(this);
            }
            base.OnDestroy();
        }

        protected override JobHandle OnUpdate(JobHandle inputDeps)
        {
            JobHandle dependencies = base.OnUpdate(inputDeps);
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.RoadClosuresEnabled)
            {
                if (m_ToolSystem.activeTool == this) m_ToolSystem.activeTool = null;
                return dependencies;
            }
            if (m_ToolSystem.activeTool != this || applyAction == null || !applyAction.WasPressedThisFrame())
                return dependencies;

            if (!GetRaycastResult(out Entity hitEntity, out RaycastHit hit) || hitEntity == Entity.Null)
            {
                ShutDownRoadState.SetStatus("No road was hit. Click directly on a road segment.");
                return dependencies;
            }

            Entity edgeEntity = ResolveRoadEdge(hitEntity, hit.m_HitPosition);
            if (edgeEntity == Entity.Null || !EntityManager.HasComponent<Edge>(edgeEntity))
            {
                ShutDownRoadState.SetStatus("The clicked object was not a road segment. Try clicking the road surface, away from an intersection.");
                Mod.log.Info($"Shut Down Road raycast did not resolve to an edge. Hit entity {hitEntity.Index}:{hitEntity.Version}.");
                return dependencies;
            }

            if (!EntityManager.HasBuffer<Game.Net.SubLane>(edgeEntity))
            {
                ShutDownRoadState.SetStatus("That road has no lane links to close.");
                return dependencies;
            }

            DynamicBuffer<Game.Net.SubLane> subLanes = EntityManager.GetBuffer<Game.Net.SubLane>(edgeEntity);
            bool closing = !EntityManager.HasComponent<ClosedRoadMarker>(edgeEntity);
            int carLanes = 0;
            if (closing)
            {
                for (int i = 0; i < subLanes.Length; i++)
                {
                    Entity laneEntity = subLanes[i].m_SubLane;
                    if (laneEntity == Entity.Null || !EntityManager.Exists(laneEntity) || !EntityManager.HasComponent<Game.Net.CarLane>(laneEntity)) continue;
                    Game.Net.CarLane lane = EntityManager.GetComponentData<Game.Net.CarLane>(laneEntity);
                    // A Forbidden flag by itself is not enough: the lane graph also
                    // needs a self access restriction and an explicit no-entry state.
                    lane.m_AccessRestriction = laneEntity;
                    lane.m_Flags |= Game.Net.CarLaneFlags.Forbidden;
                    lane.m_Flags &= ~Game.Net.CarLaneFlags.AllowEnter;
                    lane.m_BlockageStart = 0;
                    lane.m_BlockageEnd = byte.MaxValue;
                    EntityManager.SetComponentData(laneEntity, lane);
                    MarkLaneAndOwnerPathfindUpdated(laneEntity);
                    carLanes++;
                }
                if (carLanes == 0)
                {
                    ShutDownRoadState.SetStatus("No vehicle lanes were found on that segment.");
                    return dependencies;
                }
                EntityManager.AddComponent<ClosedRoadMarker>(edgeEntity);
            }
            else
            {
                for (int i = 0; i < subLanes.Length; i++)
                {
                    Entity laneEntity = subLanes[i].m_SubLane;
                    if (laneEntity == Entity.Null || !EntityManager.Exists(laneEntity) || !EntityManager.HasComponent<Game.Net.CarLane>(laneEntity)) continue;
                    Game.Net.CarLane lane = EntityManager.GetComponentData<Game.Net.CarLane>(laneEntity);
                    if (lane.m_AccessRestriction == laneEntity)
                        lane.m_AccessRestriction = Entity.Null;
                    lane.m_Flags &= ~Game.Net.CarLaneFlags.Forbidden;
                    lane.m_Flags |= Game.Net.CarLaneFlags.AllowEnter;
                    lane.m_BlockageStart = byte.MaxValue;
                    lane.m_BlockageEnd = 0;
                    EntityManager.SetComponentData(laneEntity, lane);
                    MarkLaneAndOwnerPathfindUpdated(laneEntity);
                    carLanes++;
                }
                EntityManager.RemoveComponent<ClosedRoadMarker>(edgeEntity);
                // Migrate segments that were altered by the previous version,
                // which removed their road routing methods instead of blocking lanes.
                for (int i = 0; i < subLanes.Length; i++)
                {
                    Game.Net.SubLane lane = subLanes[i];
                    lane.m_PathMethods |= Game.Pathfind.PathMethod.Road;
                    subLanes[i] = lane;
                }
            }

            Edge edge = EntityManager.GetComponentData<Edge>(edgeEntity);
            Entity endpoint = FindNearestEndpoint(edge, hit.m_HitPosition);
            if (endpoint == Entity.Null)
            {
                ShutDownRoadState.SetStatus("Could not find a road endpoint.");
                return dependencies;
            }

            RequestPatrol(endpoint);
            ShutDownRoadState.SetStatus(closing
                ? $"Road closed to vehicle traffic across {carLanes} lanes. Police patrol requested at the road end."
                : "Road reopened to vehicle traffic. Police patrol requested at the road end.");
            Mod.log.Info($"Shut Down Road {(closing ? "closed" : "reopened")} edge {edgeEntity.Index}:{edgeEntity.Version}; {carLanes} vehicle lanes.");
            m_ToolSystem.activeTool = null;
            return dependencies;
        }

        private Entity ResolveRoadEdge(Entity hitEntity, float3 hitPosition)
        {
            if (EntityManager.HasComponent<Edge>(hitEntity)) return hitEntity;
            if (EntityManager.HasComponent<Composition>(hitEntity))
            {
                Entity edge = EntityManager.GetComponentData<Composition>(hitEntity).m_Edge;
                if (edge != Entity.Null && EntityManager.Exists(edge) && EntityManager.HasComponent<Edge>(edge)) return edge;
            }
            if (EntityManager.HasBuffer<ConnectedEdge>(hitEntity))
            {
                DynamicBuffer<ConnectedEdge> connected = EntityManager.GetBuffer<ConnectedEdge>(hitEntity, true);
                Entity nearest = Entity.Null;
                float nearestDistance = float.MaxValue;
                for (int i = 0; i < connected.Length; i++)
                {
                    Entity edge = connected[i].m_Edge;
                    if (edge == Entity.Null || !EntityManager.Exists(edge) || !EntityManager.HasComponent<Edge>(edge)) continue;
                    Edge data = EntityManager.GetComponentData<Edge>(edge);
                    if (data.m_Start == hitEntity || data.m_End == hitEntity) return edge;
                    float distance = EdgeEndpointDistance(data, hitPosition);
                    if (distance < nearestDistance) { nearestDistance = distance; nearest = edge; }
                }
                if (nearest != Entity.Null) return nearest;
            }
            return Entity.Null;
        }

        private float EdgeEndpointDistance(Edge edge, float3 position)
        {
            float distance = float.MaxValue;
            if (EntityManager.Exists(edge.m_Start) && EntityManager.HasComponent<Game.Net.Node>(edge.m_Start))
                distance = math.min(distance, math.distancesq(EntityManager.GetComponentData<Game.Net.Node>(edge.m_Start).m_Position, position));
            if (EntityManager.Exists(edge.m_End) && EntityManager.HasComponent<Game.Net.Node>(edge.m_End))
                distance = math.min(distance, math.distancesq(EntityManager.GetComponentData<Game.Net.Node>(edge.m_End).m_Position, position));
            return distance;
        }

        private Entity FindNearestEndpoint(Game.Net.Edge edge, float3 hitPosition)
        {
            Entity nearest = Entity.Null;
            float nearestDistance = float.MaxValue;
            CheckEndpoint(edge.m_Start, hitPosition, ref nearest, ref nearestDistance);
            CheckEndpoint(edge.m_End, hitPosition, ref nearest, ref nearestDistance);
            return nearest;
        }

        private void CheckEndpoint(Entity node, float3 hitPosition, ref Entity nearest, ref float nearestDistance)
        {
            if (node == Entity.Null || !EntityManager.Exists(node) || !EntityManager.HasComponent<Game.Net.Node>(node)) return;
            float distance = math.distancesq(EntityManager.GetComponentData<Game.Net.Node>(node).m_Position, hitPosition);
            if (distance < nearestDistance)
            {
                nearestDistance = distance;
                nearest = node;
            }
        }

        private void RequestPatrol(Entity endpoint)
        {
            var request = new PolicePatrolRequest { m_Target = endpoint, m_Priority = 100f };
            if (EntityManager.HasComponent<PolicePatrolRequest>(endpoint))
                EntityManager.SetComponentData(endpoint, request);
            else
                EntityManager.AddComponentData(endpoint, request);
        }

        private void MarkLaneAndOwnerPathfindUpdated(Entity lane)
        {
            MarkPathfindUpdated(lane);
            if (lane == Entity.Null || !EntityManager.Exists(lane) || !EntityManager.HasComponent<Owner>(lane)) return;
            Entity owner = EntityManager.GetComponentData<Owner>(lane).m_Owner;
            if (owner == Entity.Null || !EntityManager.Exists(owner)) return;
            MarkPathfindUpdated(owner);
            if (!EntityManager.HasComponent<Edge>(owner)) return;
            Edge edge = EntityManager.GetComponentData<Edge>(owner);
            MarkPathfindUpdated(edge.m_Start);
            MarkPathfindUpdated(edge.m_End);
        }

        private void MarkPathfindUpdated(Entity entity)
        {
            if (entity == Entity.Null || !EntityManager.Exists(entity)) return;
            if (!EntityManager.HasComponent<PathfindUpdated>(entity)) EntityManager.AddComponent<PathfindUpdated>(entity);
            if (!EntityManager.HasComponent<Updated>(entity)) EntityManager.AddComponent<Updated>(entity);
        }
    }
}
