using Game.City;
using Game;
using Game.Simulation;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Temporarily raises city tourism attractiveness so vanilla tourism can bring visitors for a major show.</summary>
    [UpdateAfter(typeof(TourismSystem))]
    [UpdateBefore(typeof(TouristSpawnSystem))]
    public partial class MajorActTourismSystem : GameSystemBase
    {
        private static uint s_ActiveUntil;
        private CitySystem m_CitySystem;
        private bool m_HasApplied;
        private Entity m_AppliedCity;
        private int m_LastAppliedValue;
        private int m_LastBaseValue;

        public static void Start(uint frame, uint duration)
        {
            uint until = frame + duration;
            if (until > s_ActiveUntil) s_ActiveUntil = until;
        }

        protected override void OnCreate()
        {
            base.OnCreate();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<Tourism>(city))
            {
                m_HasApplied = false;
                return;
            }

            uint frame = World.GetOrCreateSystemManaged<SimulationSystem>().frameIndex;
            if (Mod.Settings == null || !Mod.Settings.Enabled || frame >= s_ActiveUntil)
            {
                Restore(city);
                return;
            }

            Tourism tourism = EntityManager.GetComponentData<Tourism>(city);
            int baseline = tourism.m_Attractiveness;
            if (m_HasApplied && city == m_AppliedCity && baseline == m_LastAppliedValue)
                baseline = m_LastBaseValue;
            int boost = math.max(25, baseline / 2);
            tourism.m_Attractiveness = baseline + boost;
            EntityManager.SetComponentData(city, tourism);
            m_HasApplied = true;
            m_AppliedCity = city;
            m_LastBaseValue = baseline;
            m_LastAppliedValue = tourism.m_Attractiveness;
        }

        private void Restore(Entity city)
        {
            if (m_HasApplied && city == m_AppliedCity && EntityManager.HasComponent<Tourism>(city))
            {
                Tourism tourism = EntityManager.GetComponentData<Tourism>(city);
                if (tourism.m_Attractiveness == m_LastAppliedValue)
                {
                    tourism.m_Attractiveness = m_LastBaseValue;
                    EntityManager.SetComponentData(city, tourism);
                }
            }
            m_HasApplied = false;
        }
    }
}
