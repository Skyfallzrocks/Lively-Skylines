using System.Collections.Generic;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Recent fictional gang and cartel activity reports shown in Lively Skylines.</summary>
    public static class GangActivityLedger
    {
        public struct Entry
        {
            public string Type;
            public string Group;
            public string Activity;
            public string Area;
            public int Members;
            public uint Frame;
            public uint EndFrame;
            public Entity Location;
        }

        private const int kMaxEntries = 30;
        private static readonly List<Entry> s_Entries = new List<Entry>();

        public static void Add(string type, string group, string activity, string area, int members, uint frame, uint endFrame, Entity location)
        {
            s_Entries.Insert(0, new Entry
            {
                Type = Clean(type), Group = Clean(group), Activity = Clean(activity), Area = Clean(area),
                Members = members, Frame = frame, EndFrame = endFrame, Location = location,
            });
            if (s_Entries.Count > kMaxEntries) s_Entries.RemoveRange(kMaxEntries, s_Entries.Count - kMaxEntries);
        }

        public static List<Entry> Recent(uint frame)
        {
            uint retention = OutingStarter.FramesPerDay * 7u;
            var result = new List<Entry>(s_Entries.Count);
            foreach (Entry entry in s_Entries)
                if (frame < entry.Frame || frame - entry.Frame <= retention) result.Add(entry);
            return result;
        }

        private static string Clean(string value) => (value ?? "Unknown").Replace("|", "/").Replace("\r", " ").Replace("\n", " ");
    }
}
