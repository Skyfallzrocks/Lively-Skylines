using System;
using System.Collections.Generic;
using Game;
using Game.Simulation;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>City surveillance program: cameras help solve cases and deter violence, but cost money and trust.</summary>
    public static class SurveillanceLedger
    {
        public static int Cameras, Alpr;
        public static int Monitoring;        // 0 none, 1 day staff, 2 24/7 center
        public static bool Facial;
        public static int Retention = 1;     // 0 = 7 days, 1 = 30 days, 2 = 90 days
        public static bool Audits, Signage;
        public static int Coverage;          // percent of the city that is watched
        public static int SolvedMonth, SolvedTotal, Breaches, Lawsuits, Months, Privacy;
        public static long LastCost, LastIncome, TotalCost, TotalIncome;
        public static int ViolenceOffset;
        public static string LastSummary = "No month settled yet. Place cameras and the first review comes after 30 in-game days.";
        public static readonly List<string> Events = new List<string>();

        public static void Log(string s)
        {
            Events.Insert(0, (s ?? "").Replace("|", " ").Replace("~", " ").Replace("\n", " "));
            if (Events.Count > 10) Events.RemoveAt(10);
        }

        public static long Upkeep()
        {
            return Cameras * 120L + Alpr * 260L
                + (Monitoring == 1 ? 6000L : Monitoring == 2 ? 14000L : 0L)
                + (Facial ? 9000L : 0L)
                + (Retention == 1 ? Cameras * 30L : Retention == 2 ? Cameras * 90L : 0L)
                + (Audits ? 3500L : 0L);
        }

        public static string Row()
        {
            return $"{Cameras}|{Alpr}|{Monitoring}|{(Facial ? 1 : 0)}|{Retention}|{(Audits ? 1 : 0)}|{(Signage ? 1 : 0)}|{Coverage}|{SolvedMonth}|{SolvedTotal}|{LastCost}|{LastIncome}|{Privacy}|{Breaches}|{Lawsuits}|{Months}|{Upkeep()}|{-ViolenceOffset}|{(LastSummary ?? "").Replace("|", " ")}|{string.Join("~", Events)}";
        }

        /// <summary>code: 0 monitoring level, 1 facial recognition, 2 retention, 3 privacy audits, 4 public signage.</summary>
        public static void Action(int code, int value, Func<int, bool> charge)
        {
            switch (code)
            {
                case 0:
                {
                    int target = math.clamp(value, 0, 2);
                    if (target == Monitoring) return;
                    if (target > Monitoring)
                    {
                        int cost = 25000 * (target - Monitoring);
                        if (!charge(cost)) { Log($"Setting up the monitoring center needs ${cost:N0} in city funds."); return; }
                        Log(target == 2 ? "A 24/7 monitoring center opened." : "Daytime camera monitors were hired.");
                    }
                    else Log(target == 0 ? "Live camera monitoring was shut down." : "Monitoring cut back to daytime only.");
                    Monitoring = target;
                    break;
                }
                case 1:
                    if (!Facial)
                    {
                        if (!charge(60000)) { Log("Facial recognition software needs $60,000 in city funds."); return; }
                        Facial = true; Log("Facial recognition was switched on across the camera network.");
                    }
                    else { Facial = false; Log("Facial recognition was switched off."); }
                    break;
                case 2:
                    Retention = math.clamp(value, 0, 2);
                    Log($"Footage is now kept for {(Retention == 0 ? 7 : Retention == 1 ? 30 : 90)} days.");
                    break;
                case 3:
                    Audits = !Audits;
                    Log(Audits ? "Independent privacy audits were funded." : "Privacy audits were cancelled.");
                    break;
                case 4:
                    if (Signage) return;
                    if (!charge(20000)) { Log("Public camera signage needs $20,000 in city funds."); return; }
                    Signage = true; Log("Signs went up telling residents where cameras are.");
                    break;
            }
        }
    }

    public partial class SurveillanceSystem : GameSystemBase
    {
        private SimulationSystem m_Simulation;
        private CitySystem m_CitySystem;
        private uint m_LastMonth;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_Simulation = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 256;

        protected override void OnUpdate()
        {
            var settings = Mod.Settings;
            if (settings == null || !settings.Enabled) return;
            uint frame = m_Simulation.frameIndex;
            SurveillanceLedger.Cameras = CctvCrimeCoverage.GetCameraPositions(EntityManager).Count;
            SurveillanceLedger.Alpr = CctvCrimeCoverage.GetAlprPositions(EntityManager).Count;
            int population = CrimeAreaSystem.CityPopulation;
            float need = math.max(10f, population / 800f);
            float cov = math.saturate((SurveillanceLedger.Cameras + SurveillanceLedger.Alpr * 1.5f) / need);
            SurveillanceLedger.Coverage = (int)(cov * 100f);
            SurveillanceLedger.ViolenceOffset = -math.min(6, (int)math.round(cov * (1.5f + SurveillanceLedger.Monitoring * 1.5f + (SurveillanceLedger.Facial ? 1.5f : 0f))));
            if (m_LastMonth == 0) { m_LastMonth = frame; return; }
            if (frame - m_LastMonth < OutingStarter.FramesPerDay * 30u) return;
            m_LastMonth = frame;
            Settle(frame, population, cov);
        }

        private void Settle(uint frame, int population, float cov)
        {
            int cams = SurveillanceLedger.Cameras, alpr = SurveillanceLedger.Alpr;
            SurveillanceLedger.Months++;
            if (cams + alpr == 0)
            {
                SurveillanceLedger.SolvedMonth = 0; SurveillanceLedger.LastCost = 0; SurveillanceLedger.LastIncome = 0; SurveillanceLedger.Privacy = 0;
                SurveillanceLedger.LastSummary = "No cameras are placed, so nothing was watched this month.";
                return;
            }
            var random = new Unity.Mathematics.Random(math.max(1u, frame * 747796405u + 2891336453u));
            bool bodycams = CityPolicyLedger.IsActive("Body Cameras");
            bool oversight = CityPolicyLedger.IsActive("Police Oversight Board");
            float weekly = CityCrimeLedger.WeeklyPerThousand(frame) * population / 1000f;
            float rate = 0.12f + SurveillanceLedger.Monitoring * 0.12f + SurveillanceLedger.Retention * 0.07f + (SurveillanceLedger.Facial ? 0.12f : 0f) + (bodycams ? 0.04f : 0f);
            rate = math.min(0.8f, rate);
            float expected = weekly * 4.3f * cov * rate;
            int solved = (int)expected + (random.NextFloat() < expected - (int)expected ? 1 : 0);
            long income = solved * 350L;
            long upkeep = SurveillanceLedger.Upkeep();
            long extra = 0;
            int events = 0;
            // Privacy pressure.
            float privacy = cams / 35f + alpr / 8f + (SurveillanceLedger.Facial ? 3f : 0f) + (SurveillanceLedger.Retention == 2 ? 2f : SurveillanceLedger.Retention == 1 ? 0.5f : 0f) + SurveillanceLedger.Monitoring * 0.5f;
            if (SurveillanceLedger.Audits) privacy *= 0.6f;
            if (SurveillanceLedger.Signage) privacy *= 0.7f;
            int points = (int)math.round(privacy);
            SurveillanceLedger.Privacy = points;
            if (points > 0) PublicReactionLedger.Add("Surveillance and privacy concerns", points);
            // Data breach.
            float breachChance = (2 + SurveillanceLedger.Retention * 3 + cams / 50f + (SurveillanceLedger.Facial ? 3f : 0f)) * (SurveillanceLedger.Audits ? 0.4f : 1f);
            if (random.NextInt(100) < (int)breachChance)
            {
                long cost = 25000 + random.NextInt(0, 95001);
                extra += cost; SurveillanceLedger.Breaches++; events++;
                PublicReactionLedger.Add("Camera footage data breach", 4);
                SurveillanceLedger.Log($"A data breach leaked camera footage. Fines and cleanup cost ${cost:N0}.");
                CityBuzzFeed.Add("Surveillance · breach", "Harbor Daily", "Citywide", $"Hackers leaked camera footage from the city network. The cleanup and fines cost ${cost:N0}.", frame);
            }
            // Wrongful identification.
            if (SurveillanceLedger.Facial)
            {
                float chance = (8 + cams / 20f) * (oversight ? 0.5f : 1f);
                if (random.NextInt(100) < (int)chance)
                {
                    long cost = 15000 + random.NextInt(0, 45001);
                    extra += cost; SurveillanceLedger.Lawsuits++; events++;
                    PublicReactionLedger.Add("Wrongful facial-recognition arrest", 3);
                    SurveillanceLedger.Log($"Facial recognition misidentified a resident. The city settled a lawsuit for ${cost:N0}.");
                    CityBuzzFeed.Add("Surveillance · lawsuit", "Harbor Daily", "Citywide", $"A resident was wrongly arrested after a facial-recognition match. The city paid ${cost:N0} to settle.", frame);
                }
            }
            if (solved > 0) SurveillanceLedger.Log($"Footage helped solve {solved} case{(solved == 1 ? "" : "s")} this month.");
            SurveillanceLedger.SolvedMonth = solved;
            SurveillanceLedger.SolvedTotal += solved;
            SurveillanceLedger.LastIncome = income;
            SurveillanceLedger.LastCost = upkeep + extra;
            SurveillanceLedger.TotalIncome += income;
            SurveillanceLedger.TotalCost += upkeep + extra;
            PayCity(income - upkeep - extra);
            SurveillanceLedger.LastSummary = $"Month {SurveillanceLedger.Months}: footage helped solve {solved} case(s) worth ${income:N0} in fines. Upkeep ${upkeep:N0}{(extra > 0 ? $", breaches and settlements ${extra:N0}" : "")}. Coverage {SurveillanceLedger.Coverage}%.";
            CityBuzzFeed.Add("City surveillance · monthly review", "City dispatch", "Citywide", SurveillanceLedger.LastSummary, frame);
        }

        private void PayCity(long net)
        {
            if (net == 0) return;
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<Game.City.PlayerMoney>(city)) return;
            var money = EntityManager.GetComponentData<Game.City.PlayerMoney>(city);
            if (money.m_Unlimited) return;
            int amount = (int)math.clamp(net, -(long)int.MaxValue, (long)int.MaxValue);
            if (amount > 0) money.Add(amount); else money.Subtract(-amount);
            EntityManager.SetComponentData(city, money);
        }
    }
}
