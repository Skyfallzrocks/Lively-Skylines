using System;
using System.Collections.Generic;
using System.Text;
using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Random = Unity.Mathematics.Random;

namespace BarRush
{
    /// <summary>City youth centers on real buildings: teens visit in the evening, gang recruitment drops nearby.</summary>
    public static class YouthCenterLedger
    {
        public sealed class Center
        {
            public int Id; public Entity Building; public string Name; public string Area; public float X, Z;
            public bool Sports, JobTraining, LateNight;
            public int Visits, VisitsToday, Graduates;
        }
        public static readonly List<Center> Centers = new List<Center>();
        public const int kOpenCost = 60000;
        public static int MonthlyCost { get { int c = 0; foreach (var x in Centers) c += 6000 + (x.LateNight ? 3000 : 0) + (x.JobTraining ? 2500 : 0) + (x.Sports ? 1500 : 0); return c; } }
        public static int CrimeOffset => -Math.Min(4, Centers.Count + CountLate() / 2);
        private static int CountLate() { int n = 0; foreach (var c in Centers) if (c.LateNight) n++; return n; }
        public static string Status = "Open a youth center in a district to give teens somewhere to go.";
        public static bool InArea(string area) { foreach (var c in Centers) if (c.Area == area) return true; return false; }
        public static Center Get(int id) { foreach (var c in Centers) if (c.Id == id) return c; return null; }
    }

    /// <summary>Resident house parties: real sims gather at homes at night; noise, neighbors, police.</summary>
    public static class HousePartyLedger
    {
        public sealed class Party
        {
            public int Id; public Entity Home; public string Address; public string Area; public string Host; public float X, Z;
            public int Guests; public int Noise; public string Vibe; public uint Start, End; public string Status = "Going strong";
            public bool Complaint; public bool Famous;
        }
        public static readonly List<Party> Active = new List<Party>();
        public static readonly List<string> Recent = new List<string>();
        public static int Total, ShutDown, Complaints;
        public static int Policy = 1; // 0 let them be, 1 warn on complaints, 2 shut down on complaints
        public static readonly Queue<(int id, int action)> Actions = new Queue<(int, int)>();
        public static void Finish(Party p, string how)
        {
            Active.Remove(p);
            Recent.Insert(0, $"{p.Address}~{p.Area}~{p.Guests}~{p.Vibe}~{how}");
            if (Recent.Count > 8) Recent.RemoveAt(Recent.Count - 1);
        }
    }

    public partial class CommunityLifeSystem : GameSystemBase
    {
        private SimulationSystem m_SimulationSystem;
        private NameSystem m_NameSystem;
        private Game.Simulation.CitySystem m_CitySystem;
        private TimeSystem m_TimeSystem;
        private EntityQuery m_CitizenQuery, m_HomeQuery, m_BuildingQuery;
        private uint m_LastVisitDay = uint.MaxValue, m_LastPartyCheck, m_LastMonthFrame;
        private int m_NextId = 1;
        public static readonly Queue<(int kind, int a, int b)> Requests = new Queue<(int, int, int)>();
        private static readonly string[] s_Vibes = { "House music", "Backyard BBQ", "Birthday bash", "Game night", "Rooftop hangout", "Karaoke", "College party", "Dinner party" };

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CitySystem = World.GetOrCreateSystemManaged<Game.Simulation.CitySystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(), ComponentType.ReadOnly<HouseholdMember>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_HomeQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Buildings.Building>(), ComponentType.ReadOnly<Game.Buildings.ResidentialProperty>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_BuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Buildings.Building>(), ComponentType.ReadOnly<Game.Objects.Transform>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 256;

        private bool Charge(int amount)
        {
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<Game.City.PlayerMoney>(city)) return false;
            var money = EntityManager.GetComponentData<Game.City.PlayerMoney>(city);
            if (!money.m_Unlimited && money.money < amount) return false;
            if (!money.m_Unlimited) { money.Subtract(amount); EntityManager.SetComponentData(city, money); }
            return true;
        }

        protected override void OnUpdate()
        {
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled) return;
            uint frame = m_SimulationSystem.frameIndex;
            var random = new Random(math.max(1u, frame * 1103515245u + 12345u));
            HandleRequests(frame, ref random);
            HandlePartyActions(frame);
            float now = m_TimeSystem.normalizedTime;
            uint day = frame / OutingStarter.FramesPerDay;
            // Youth center evening visits (after school, ~16:00).
            if (YouthCenterLedger.Centers.Count > 0 && now >= 0.66f && m_LastVisitDay != day) { m_LastVisitDay = day; YouthVisits(frame, ref random); }
            // Monthly running costs.
            if (m_LastMonthFrame == 0 || frame < m_LastMonthFrame) m_LastMonthFrame = frame;
            else if (frame - m_LastMonthFrame >= OutingStarter.FramesPerDay * 30u)
            {
                m_LastMonthFrame = frame;
                int cost = YouthCenterLedger.MonthlyCost;
                if (cost > 0) { Charge(cost); CityBuzzFeed.Add("Youth centers", "City finance", "City Hall", $"Youth centers cost the city ${cost:N0} this month.", frame); }
            }
            // House parties: start in the evening, mostly on weekends.
            if (frame - m_LastPartyCheck >= OutingStarter.FramesPerDay / 24u || frame < m_LastPartyCheck)
            {
                m_LastPartyCheck = frame;
                UpdateParties(frame, now, day, ref random);
            }
        }

        // ---- Requests from the UI ------------------------------------------------------------
        private void HandleRequests(uint frame, ref Random random)
        {
            while (Requests.Count > 0)
            {
                var (kind, a, b) = Requests.Dequeue();
                if (kind == 1) OpenCenter(frame, ref random);
                else if (kind == 2)
                {
                    var c = YouthCenterLedger.Get(a);
                    if (c == null) continue;
                    if (b == 1) c.Sports = !c.Sports; else if (b == 2) c.JobTraining = !c.JobTraining; else if (b == 3) c.LateNight = !c.LateNight;
                    else if (b == 4) { YouthCenterLedger.Centers.Remove(c); YouthCenterLedger.Status = $"{c.Name} closed."; CityBuzzFeed.Add("Youth centers", "Harbor Daily", c.Area, $"{c.Name} closed its doors.", frame); PublicReactionLedger.Add("Youth center closed", 2); }
                }
                else if (kind == 3) HousePartyLedger.Policy = math.clamp(a, 0, 2);
            }
        }

        private void OpenCenter(uint frame, ref Random random)
        {
            if (YouthCenterLedger.Centers.Count >= 6) { YouthCenterLedger.Status = "The city can run up to six youth centers."; return; }
            // Put the center in the district where street gangs hold the most turf, else anywhere.
            string target = GangEconomyLedger.HottestDistrict();
            using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
            Entity pick = Entity.Null; string area = ""; int start = buildings.Length > 0 ? random.NextInt(buildings.Length) : 0;
            for (int k = 0; k < buildings.Length; k++)
            {
                Entity b = buildings[(start + k) % buildings.Length];
                if (EntityManager.HasComponent<Game.Buildings.ResidentialProperty>(b)) continue;
                bool used = false; foreach (var c in YouthCenterLedger.Centers) if (c.Building == b) used = true;
                if (used) continue;
                string a = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, b);
                if (string.IsNullOrWhiteSpace(a)) a = "City district";
                if (target != null && a != target && k < buildings.Length - 1) { if (pick == Entity.Null) { pick = b; area = a; } continue; }
                if (YouthCenterLedger.InArea(a) && k < buildings.Length - 1) continue;
                pick = b; area = a; break;
            }
            if (pick == Entity.Null) { YouthCenterLedger.Status = "No building was available for a youth center."; return; }
            if (!Charge(YouthCenterLedger.kOpenCost)) { YouthCenterLedger.Status = $"Not enough city money. A youth center costs ${YouthCenterLedger.kOpenCost:N0} to open."; return; }
            var pos = EntityManager.GetComponentData<Game.Objects.Transform>(pick).m_Position;
            string label = m_NameSystem.GetRenderedLabelName(pick);
            var center = new YouthCenterLedger.Center { Id = m_NextId++, Building = pick, Area = area, X = pos.x, Z = pos.z, Sports = true,
                Name = $"{(string.IsNullOrWhiteSpace(label) ? area : label)} Youth Center".Replace("|", " ") };
            YouthCenterLedger.Centers.Add(center);
            YouthCenterLedger.Status = $"{center.Name} opened in {area} for ${YouthCenterLedger.kOpenCost:N0}.";
            CityBuzzFeed.Add("Community · youth center", "Harbor Daily", area, $"{center.Name} opened in {area} with sports leagues, tutoring and a safe place to hang out after school.", frame);
            PublicReactionLedger.Add("New youth center opened", -3);
        }

        private void YouthVisits(uint frame, ref Random random)
        {
            using NativeArray<Entity> citizens = m_CitizenQuery.ToEntityArray(Allocator.Temp);
            var teens = new List<Entity>();
            foreach (Entity e in citizens)
            {
                Citizen c = EntityManager.GetComponentData<Citizen>(e);
                int age = (int)(c.m_State & (CitizenFlags.AgeBit1 | CitizenFlags.AgeBit2));
                if (age == (int)CitizenAge.Teen) teens.Add(e);
            }
            foreach (var center in YouthCenterLedger.Centers)
            {
                center.VisitsToday = 0;
                if (teens.Count == 0 || !EntityManager.Exists(center.Building)) continue;
                int want = math.clamp(teens.Count / (8 * YouthCenterLedger.Centers.Count), 3, 40) + (center.Sports ? 6 : 0) + (center.LateNight ? 4 : 0);
                var pick = new NativeArray<Entity>(teens.ToArray(), Allocator.Temp);
                int started = OutingStarter.Start(EntityManager, pick, want, ref random, frame, OutingStarter.FramesPerDay / (center.LateNight ? 4u : 6u), center.Building);
                pick.Dispose();
                center.VisitsToday = started; center.Visits += started;
                if (center.JobTraining && random.NextInt(100) < 30) center.Graduates++;
            }
            GangEconomyLedger.YouthCentersWeaken(YouthCenterLedger.Centers, frame);
        }

        // ---- House parties ----------------------------------------------------------------------
        private void UpdateParties(uint frame, float now, uint day, ref Random random)
        {
            // End parties that are over.
            for (int i = HousePartyLedger.Active.Count - 1; i >= 0; i--)
            {
                var p = HousePartyLedger.Active[i];
                if (frame >= p.End) { HousePartyLedger.Finish(p, "Wrapped up"); continue; }
                // Noise complaints from neighbors late at night.
                if (!p.Complaint && p.Noise >= 60 && random.NextInt(100) < p.Noise / 2)
                {
                    p.Complaint = true; HousePartyLedger.Complaints++;
                    bool curfew = CityPolicyLedger.IsActive("Noise Curfew");
                    int policy = curfew ? 2 : HousePartyLedger.Policy;
                    if (policy == 2) { p.Status = "Shut down by police"; HousePartyLedger.ShutDown++; HousePartyLedger.Finish(p, "Shut down after noise complaint"); CityBuzzFeed.Add("House party", "Crime Desk", p.Area, $"Police shut down a {p.Vibe.ToLowerInvariant()} at {p.Address} after neighbors complained.{(curfew ? " The Noise Curfew is in force." : "")}", frame); PublicReactionLedger.Add("Party shut down by police", 1); continue; }
                    if (policy == 1) { p.Noise = math.max(30, p.Noise - 30); p.Status = "Warned by police · turned it down"; CityBuzzFeed.Add("House party", "Crime Desk", p.Area, $"Officers asked the hosts at {p.Address} to turn the music down after a noise complaint.", frame); }
                    else { PublicReactionLedger.Add("Neighbors upset over a loud party", 2); p.Status = "Neighbors are complaining"; }
                }
                // Rare trouble at big parties becomes a real crime report (and a getaway chase).
                if (p.Guests >= 25 && random.NextInt(1000) < 15)
                {
                    Entity incident = EntityManager.CreateEntity();
                    CityCrimeLedger.Record(incident, p.Home, p.Address, p.Area, CrimeAreaSystem.HasPoliceStation(Entity.Null), false, frame,
                        $"A fight broke out at a house party at {p.Address}.", "Assault at a house party", "Party guest");
                    p.Status = "Fight reported";
                }
            }
            // New parties: evenings (after ~19:00), more on weekend nights.
            bool evening = now >= 0.79f || now < 0.08f;
            if (!evening || HousePartyLedger.Active.Count >= 5) return;
            int weekday = (int)(day % 7u);
            int chance = weekday >= 5 ? 45 : 14;
            if (random.NextInt(100) >= chance) return;
            using NativeArray<Entity> homes = m_HomeQuery.ToEntityArray(Allocator.Temp);
            if (homes.Length == 0) return;
            Entity home = homes[random.NextInt(homes.Length)];
            foreach (var x in HousePartyLedger.Active) if (x.Home == home) return;
            string address = m_NameSystem.GetRenderedLabelName(home);
            if (string.IsNullOrWhiteSpace(address)) address = "a city home";
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, home);
            if (string.IsNullOrWhiteSpace(area)) area = "City district";
            using NativeArray<Entity> citizens = m_CitizenQuery.ToEntityArray(Allocator.Temp);
            int want = random.NextInt(8, 41);
            uint duration = OutingStarter.FramesPerDay / (uint)random.NextInt(5, 9);
            int population = math.max(1, citizens.Length);
            int cap = PopulationCap.MaxAttendees(population, settings2());
            want = math.min(want, AttendanceLedger.Remaining(cap, frame));
            if (want <= 0) return;
            int guests = OutingStarter.Start(EntityManager, citizens, want, ref random, frame, duration, home);
            if (guests <= 0) return;
            AttendanceLedger.Add(guests, frame + duration);
            var pos = EntityManager.GetComponentData<Game.Objects.Transform>(home).m_Position;
            string vibe = s_Vibes[random.NextInt(s_Vibes.Length)];
            var party = new HousePartyLedger.Party { Id = m_NextId++, Home = home, Address = address.Replace("|", " "), Area = area.Replace("|", " "), X = pos.x, Z = pos.z,
                Guests = guests, Vibe = vibe, Noise = math.clamp(guests * 2 + (vibe == "House music" || vibe == "College party" ? 30 : 0) + random.NextInt(0, 20), 10, 100),
                Start = frame, End = frame + duration, Famous = random.NextInt(100) < 12, Host = "Local residents" };
            HousePartyLedger.Active.Add(party); HousePartyLedger.Total++;
            CityBuzzFeed.Add("House party", "Nightlife Now", $"{party.Address} · {area}", $"{guests} residents are heading to a {vibe.ToLowerInvariant()} at {party.Address} in {area}.{(party.Famous ? " A famous local creator was spotted on the guest list." : "")}", frame);
        }

        private static int settings2() => Mod.Settings != null ? Mod.Settings.MaxAttendancePercent : 10;

        private void HandlePartyActions(uint frame)
        {
            while (HousePartyLedger.Actions.Count > 0)
            {
                var (id, action) = HousePartyLedger.Actions.Dequeue();
                HousePartyLedger.Party p = null; foreach (var x in HousePartyLedger.Active) if (x.Id == id) p = x;
                if (p == null) continue;
                if (action == 1) { p.Noise = math.max(20, p.Noise - 35); p.Status = "Warned by police · turned it down"; CityBuzzFeed.Add("House party", "Crime Desk", p.Area, $"Police asked the party at {p.Address} to keep it down.", frame); }
                else if (action == 2) { HousePartyLedger.ShutDown++; HousePartyLedger.Finish(p, "Shut down by police"); CityBuzzFeed.Add("House party", "Crime Desk", p.Area, $"Police broke up the {p.Vibe.ToLowerInvariant()} at {p.Address}. {p.Guests} guests were sent home.", frame); PublicReactionLedger.Add("Police broke up a house party", 1); }
            }
        }

        // ---- UI rows ------------------------------------------------------------------------------
        public static string Rows(uint frame)
        {
            var sb = new StringBuilder();
            foreach (var c in YouthCenterLedger.Centers)
                sb.Append("Y|").Append(c.Id).Append('|').Append(c.Name).Append('|').Append(c.Area).Append('|').Append(c.Visits).Append('|').Append(c.VisitsToday).Append('|')
                  .Append(c.Sports ? 1 : 0).Append('|').Append(c.JobTraining ? 1 : 0).Append('|').Append(c.LateNight ? 1 : 0).Append('|').Append(c.Graduates).Append('\n');
            sb.Append("YS|").Append(YouthCenterLedger.MonthlyCost).Append('|').Append(YouthCenterLedger.CrimeOffset).Append('|').Append(YouthCenterLedger.Status.Replace("|", " ")).Append('\n');
            foreach (var p in HousePartyLedger.Active)
                sb.Append("H|").Append(p.Id).Append('|').Append(p.Address).Append('|').Append(p.Area).Append('|').Append(p.Guests).Append('|').Append(p.Noise).Append('|')
                  .Append(p.Vibe).Append('|').Append(p.Status.Replace("|", " ")).Append('|').Append(frame < p.End ? p.End - frame : 0u).Append('|').Append(p.Famous ? 1 : 0).Append('\n');
            foreach (var r in HousePartyLedger.Recent) sb.Append("HR|").Append(r).Append('\n');
            sb.Append("HS|").Append(HousePartyLedger.Total).Append('|').Append(HousePartyLedger.ShutDown).Append('|').Append(HousePartyLedger.Complaints).Append('|').Append(HousePartyLedger.Policy).Append('\n');
            return sb.ToString();
        }
    }
}
