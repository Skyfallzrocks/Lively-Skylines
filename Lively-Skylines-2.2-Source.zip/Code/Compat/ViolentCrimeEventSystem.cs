using Game;
using Game.Areas;
using Game.Buildings;
using Game.Citizens;
using Game.City;
using Game.Companies;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>
    /// Generates clearly identified Lively Skylines story incidents. The base game
    /// only exposes robbery as a native crime type, so these reports are not
    /// presented as native game crime events.
    /// </summary>
    public partial class ViolentCrimeEventSystem : GameSystemBase
    {
        private static readonly float[] s_NightIncidentTimes = { 20f / 24f, 22f / 24f, 0f, 2f / 24f, 4f / 24f };
        private const int kStabbingFine = 50000;
        private const int kShootingFine = 100000;
        private static readonly string[] s_IncidentTypes =
        {
            "Aggravated Assault",
            "Criminal Homicide (Murder and Non-Negligent Manslaughter)",
            "Manslaughter by Negligence",
            "Robbery",
            "Rape",
            "Fondling/Sexual Assault",
            "Incest",
            "Statutory Rape",
            "Domestic Violence",
            "Dating Violence",
            "Stalking",
            "Hate Crime (Bias-Motivated)",
            "Burglary",
            "Arson",
            "Larceny/Theft",
            "Motor Vehicle Theft",
            "Grand Larceny / Grand Theft",
            "Petit Larceny / Petty Theft",
            "Burglary of Vehicles",
            "Shoplifting",
            "Smash-and-grab",
            "Identity Theft",
            "Credit Card Fraud",
            "Embezzlement",
            "Tax Fraud / Tax Evasion",
            "Counterfeiting",
            "Insurance Fraud",
            "Graffiti / Vandalism",
            "Shooting",
            "Stabbing",
        };

        private EntityQuery m_BuildingQuery;
        private EntityQuery m_CitizenQuery;
        private EntityQuery m_CompanyQuery;
        private EntityQuery m_ParkedCarQuery;
        private EntityQuery m_HomelessCitizenQuery;
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private CitySystem m_CitySystem;
        private float m_PreviousTime = -1f;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_BuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Building>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_HomelessCitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<HouseholdMember>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
            m_ParkedCarQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Vehicles.ParkedCar>(),
                ComponentType.ReadOnly<Game.Vehicles.PersonalCar>(), ComponentType.ReadOnly<Game.Objects.Transform>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            SeenBetterDaysGraffitiBridge.Update(World, EntityManager, m_SimulationSystem.frameIndex);
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.ViolentCrimeEventsEnabled || !settings.CrimeReportsEnabled) return;

            float now = m_TimeSystem.normalizedTime;
            bool reachedIncidentTime = false;
            if (m_PreviousTime >= 0f)
            {
                bool wrappedToNewDay = now < m_PreviousTime;
                foreach (float incidentTime in s_NightIncidentTimes)
                {
                    if (wrappedToNewDay ? (incidentTime > m_PreviousTime || incidentTime <= now)
                        : (m_PreviousTime < incidentTime && now >= incidentTime))
                    { reachedIncidentTime = true; break; }
                }
            }
            m_PreviousTime = now;
            if (reachedIncidentTime) TryCreateIncident(settings);
        }

        private void TryCreateIncident(Setting settings)
        {
            uint frame = m_SimulationSystem.frameIndex;
            var random = new Random(math.max(1u, frame * 747796405u + 2891336453u));
            FamousSimRoster.EnsureResidents(EntityManager, m_CitizenQuery, m_NameSystem, ref random);
            using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
            if (buildings.Length == 0) return;

            // A no-police area has a higher chance, while the overall chance also
            // responds modestly to reports already observed in this city.
            var candidates = new System.Collections.Generic.List<Entity>(buildings.Length);
            var uncovered = new System.Collections.Generic.List<Entity>();
            foreach (Entity building in buildings)
            {
                candidates.Add(building);
                if (!EntityManager.HasComponent<CurrentDistrict>(building)) continue;
                Entity district = EntityManager.GetComponentData<CurrentDistrict>(building).m_District;
                if (district != Entity.Null && !CrimeAreaSystem.HasPoliceStation(district)) uncovered.Add(building);
            }
            if (candidates.Count == 0) return;

            bool hasUncovered = uncovered.Count > 0;
            Entity location = hasUncovered && random.NextInt(100) < 70
                ? uncovered[random.NextInt(uncovered.Count)]
                : candidates[random.NextInt(candidates.Count)];

            float recentRate = CityCrimeLedger.WeeklyPerThousand(frame);
            int rateBonus = math.min(10, (int)(recentRate * 2f));
            int noPoliceBonus = hasUncovered ? 3 : 0;
            int chance = math.clamp(settings.ViolentCrimeChancePercent * 2 + rateBonus + noPoliceBonus + CityPolicyLedger.ViolentCrimeChanceOffset + GangEconomyLedger.ViolenceOffset + YouthCenterLedger.CrimeOffset + SurveillanceLedger.ViolenceOffset, 1, 65);
            if (random.NextInt(100) >= chance) return;

            string type = s_IncidentTypes[random.NextInt(s_IncidentTypes.Length)];
            Entity affectedHomelessResident = Entity.Null;
            if (type == "Stabbing" && TryPickHomelessResident(ref random, out affectedHomelessResident, out Entity encampment))
                location = encampment;
            if (type == "Shoplifting" && !TryPickStore(ref random, buildings, out location)) return;
            Entity smashGrabVehicle = Entity.Null;
            if (type == "Smash-and-grab" && !TryPickParkedCar(ref random, out smashGrabVehicle, out location)) return;
            // A placed mobile CCTV camera strongly discourages this modeled incident
            // inside its 180 m coverage area. The game's native crime simulation is untouched.
            if (CctvCrimeCoverage.Covers(EntityManager,
                EntityManager.GetComponentData<Game.Objects.Transform>(location).m_Position) && random.NextInt(100) < 75)
                return;
            bool shooting = type == "Shooting";
            bool stabbing = type == "Stabbing";
            int assessed = shooting ? kShootingFine : stabbing ? kStabbingFine : 0;
            string place = type == "Smash-and-grab" ? $"Parked car near {m_NameSystem.GetRenderedLabelName(location)}" : m_NameSystem.GetRenderedLabelName(location);
            if (string.IsNullOrWhiteSpace(place)) place = "City district";
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
            Entity districtEntity = EntityManager.HasComponent<CurrentDistrict>(location)
                ? EntityManager.GetComponentData<CurrentDistrict>(location).m_District : Entity.Null;
            bool hasPolice = CrimeAreaSystem.HasPoliceStation(districtEntity);

            int paid = 0;
            int outstanding = assessed;
            Entity city = m_CitySystem.City;
            if (city != Entity.Null && EntityManager.Exists(city) && EntityManager.HasComponent<PlayerMoney>(city))
            {
                PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
                if (money.m_Unlimited) outstanding = 0;
                else
                {
                    paid = math.min(assessed, math.max(0, money.money));
                    if (paid > 0) money.Subtract(paid);
                    EntityManager.SetComponentData(city, money);
                    outstanding = assessed - paid;
                }
            }

            string fineText = assessed > 0 ? moneyText(assessed, paid, outstanding) : "No city fine was assessed.";
            string businessLossText = string.Empty;
            bool businessClosed = false;
            if (type == "Robbery" || type == "Burglary" || type == "Burglary of Vehicles" || type == "Smash-and-grab")
            {
                Entity business = FindCompanyAt(location);
                if (business != Entity.Null)
                {
                    long loss = type == "Smash-and-grab" ? 80000 : type == "Robbery" ? 55000 : 40000;
                    businessLossText = CrimeCompanySwapSystem.RecordBusinessCrimeLoss(EntityManager, location, business, loss, out businessClosed);
                }
            }
            string affectedDescription = affectedHomelessResident != Entity.Null
                ? " An unhoused resident was reported injured; emergency services were requested. No identity or graphic details are published."
                : string.Empty;
            string detail = type == "Shoplifting"
                ? $"Lively Skylines simulated incident · suspected shoplifting reported at a local store. {fineText}"
                : type == "Smash-and-grab"
                    ? $"Lively Skylines simulated incident · smash-and-grab reported at a parked personal vehicle. Vehicle and building assets are unchanged. {businessLossText} {fineText}"
                    : $"Lively Skylines simulated incident · {type} reported.{affectedDescription} {businessLossText} {fineText}";
            // A dedicated entity key lets the existing report-hide control hide
            // both this report and its linked public response without pretending
            // the game created a native CrimeEvent entity.
            Entity incident = EntityManager.CreateEntity();
            string responseStatus = hasPolice ? "Police response reported" : "No nearby station · response delayed";
            CityCrimeLedger.Record(incident, location, place, area, hasPolice, false, frame, detail, type, "Unidentified", responseStatus);
            string report = affectedHomelessResident != Entity.Null
                ? $"A stabbing was reported near {place} in {area}. An unhoused resident was reported injured and emergency services were requested. The report does not identify the resident or describe injuries. {responseStatus}. This is a fictional city-simulation incident."
                : $"{type} reported at {place}, {area}. {businessLossText} {fineText}";
            CityBuzzFeed.AddCrime(incident, $"{place} · {area}", report, frame, "Lively Skylines report", type);
            if (businessClosed)
                CityBuzzFeed.Add("Business closure", "City dispatch", $"{place} · {area}",
                    $"A business at {place} has closed after repeated robbery and break-in losses exceeded its modeled operating reserves. The building remains in place; only its current company has closed.", frame);
            if (type == "Graffiti / Vandalism")
            {
                SeenBetterDaysGraffitiBridge.Tag(location, frame);
                string graffitiNotice = $"A graffiti / vandalism incident was reported at {place}, {area}.";
                CityBuzzFeed.Add("Graffiti report", "City dispatch", $"{place} · {area}", graffitiNotice, frame);
                DjAnnouncement.EnqueueCityUpdate("Graffiti / vandalism", "City dispatch", $"{place} · {area}", graffitiNotice, location);
            }
            if (assessed > 0)
            {
                CityBuzzFeed.Add("City fine", "City finance", place, $"{type} incident fine: {fineText}", frame);
                DjAnnouncement.EnqueueFineNotice(place, $"The city was fined after a reported {type.ToLowerInvariant()} at {place}. {fineText}");
            }

            if (settings.CrimeTweetsEnabled && settings.FamousPeopleEnabled &&
                FamousSimRoster.TryPick(EntityManager, ref random, out Entity resident, out string famousName))
            {
                string response = $"Reports of {type.ToLowerInvariant()} at {place}. I hope everyone affected gets support and the report is handled carefully.";
                int likes = random.NextInt(500, 22000);
                int dislikes = random.NextInt(20, 3500);
                CityBuzzFeed.AddSocial("Tweet", famousName, $"{place} · {area}", response, frame,
                    likes, dislikes, incident);
                FamousSimRoster.RecordPost(resident);
            }

            Mod.log.Info($"Lively Skylines simulated {type.ToLowerInvariant()} reported at {place} ({area}); assessed ${assessed:N0}, collected ${paid:N0}, outstanding ${outstanding:N0}.");
        }

        private bool TryPickHomelessResident(ref Random random, out Entity resident, out Entity location)
        {
            resident = Entity.Null;
            location = Entity.Null;
            using NativeArray<Entity> citizens = m_HomelessCitizenQuery.ToEntityArray(Allocator.Temp);
            var candidates = new System.Collections.Generic.List<Entity>();
            foreach (Entity citizen in citizens)
            {
                Entity household = EntityManager.GetComponentData<HouseholdMember>(citizen).m_Household;
                if (household == Entity.Null || !EntityManager.Exists(household) || !EntityManager.HasComponent<HomelessHousehold>(household)) continue;
                candidates.Add(citizen);
            }
            if (candidates.Count == 0) return false;
            resident = candidates[random.NextInt(candidates.Count)];
            if (EntityManager.HasComponent<CurrentBuilding>(resident))
            {
                Entity currentBuilding = EntityManager.GetComponentData<CurrentBuilding>(resident).m_CurrentBuilding;
                if (currentBuilding != Entity.Null && EntityManager.Exists(currentBuilding)) location = currentBuilding;
            }
            if (location == Entity.Null)
            {
                using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
                if (buildings.Length > 0) location = buildings[random.NextInt(buildings.Length)];
            }
            return location != Entity.Null;
        }

        private bool TryPickStore(ref Random random, NativeArray<Entity> fallbackBuildings, out Entity store)
        {
            store = Entity.Null;
            var candidates = new System.Collections.Generic.List<Entity>();
            using NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity company in companies)
            {
                Entity building = EntityManager.GetComponentData<PropertyRenter>(company).m_Property;
                if (building == Entity.Null || !EntityManager.Exists(building) || BarFinder.IsBar(EntityManager, company)) continue;
                candidates.Add(building);
            }
            if (candidates.Count > 0) { store = candidates[random.NextInt(candidates.Count)]; return true; }
            if (fallbackBuildings.Length == 0) return false;
            store = fallbackBuildings[random.NextInt(fallbackBuildings.Length)];
            return true;
        }

        private Entity FindCompanyAt(Entity building)
        {
            using NativeArray<Entity> companies = m_CompanyQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity company in companies)
                if (EntityManager.HasComponent<PropertyRenter>(company)
                    && EntityManager.GetComponentData<PropertyRenter>(company).m_Property == building)
                    return company;
            return Entity.Null;
        }

        private bool TryPickParkedCar(ref Random random, out Entity vehicle, out Entity location)
        {
            vehicle = Entity.Null;
            location = Entity.Null;
            using NativeArray<Entity> cars = m_ParkedCarQuery.ToEntityArray(Allocator.Temp);
            if (cars.Length == 0) return false;
            vehicle = cars[random.NextInt(cars.Length)];
            location = vehicle;
            return true;
        }

        private static string moneyText(int assessed, int paid, int outstanding)
            => $"City fine assessed: ${assessed:N0}; ${paid:N0} collected; ${outstanding:N0} outstanding.";
    }
}
