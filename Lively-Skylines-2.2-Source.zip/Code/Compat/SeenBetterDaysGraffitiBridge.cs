using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Game;
using Unity.Entities;

namespace BarRush
{
    /// <summary>
    /// Optional compatibility with Seen Better Days. It uses that mod's own tracked
    /// overlay renderer so the selected building can be restored without touching
    /// the rest of the city. Urban Tags decals are preferred when that asset pack is
    /// loaded; Seen Better Days' automatic graffiti decals are the fallback.
    /// </summary>
    internal static class SeenBetterDaysGraffitiBridge
    {
        private sealed class TagRecord
        {
            public Entity Building;
            public uint ExpiresAt;
            public uint NextAttempt;
            public bool Applied;
            public bool ReportedFailure;
        }

        private const uint kTagDuration = OutingStarter.FramesPerDay * 7u;
        private const uint kRetryInterval = OutingStarter.FramesPerDay / 4u;
        private static readonly List<TagRecord> s_Tags = new List<TagRecord>();
        private static uint s_LastFrame;
        private static bool s_HasFrame;

        public static void Tag(Entity building, uint frame)
        {
            SyncFrame(frame);
            if (building == Entity.Null) return;
            foreach (TagRecord existing in s_Tags)
            {
                if (existing.Building != building) continue;
                existing.ExpiresAt = frame + kTagDuration;
                existing.NextAttempt = frame;
                return;
            }
            s_Tags.Add(new TagRecord { Building = building, ExpiresAt = frame + kTagDuration, NextAttempt = frame });
        }

        public static void Update(World world, EntityManager entityManager, uint frame)
        {
            SyncFrame(frame);
            for (int i = s_Tags.Count - 1; i >= 0; i--)
            {
                TagRecord tag = s_Tags[i];
                if (!entityManager.Exists(tag.Building))
                {
                    s_Tags.RemoveAt(i);
                    continue;
                }

                if (frame >= tag.ExpiresAt)
                {
                    if (tag.Applied) Restore(world, tag.Building);
                    s_Tags.RemoveAt(i);
                    continue;
                }

                if (tag.Applied || frame < tag.NextAttempt) continue;
                tag.NextAttempt = frame + kRetryInterval;
                if (ApplyGraffiti(world, tag.Building, frame, out string message))
                {
                    tag.Applied = true;
                    Mod.log.Info($"Seen Better Days graffiti overlay applied to tagged building {tag.Building.Index}.");
                }
                else if (!tag.ReportedFailure && !string.IsNullOrWhiteSpace(message))
                {
                    tag.ReportedFailure = true;
                    Mod.log.Info($"Seen Better Days graffiti overlay was not applied to building {tag.Building.Index}: {message}");
                }
            }
        }

        private static bool ApplyGraffiti(World world, Entity building, uint frame, out string message)
        {
            message = null;
            try
            {
                if (!TryGetSeenBetterDays(world, out Assembly assembly, out object renderer, out object harness, out object detailSystem))
                {
                    message = "Seen Better Days is not loaded yet.";
                    return false;
                }
                PropertyInfo detailEnabled = detailSystem?.GetType().GetProperty("Enabled", BindingFlags.Public | BindingFlags.Instance);
                if (detailEnabled != null && !(bool)detailEnabled.GetValue(detailSystem))
                {
                    message = "Seen Better Days decal detail is disabled in its settings.";
                    return false;
                }

                Type rendererType = renderer.GetType();
                PropertyInfo availableProperty = rendererType.GetProperty("IsAvailable", BindingFlags.Public | BindingFlags.Instance);
                if (availableProperty == null || !(bool)availableProperty.GetValue(renderer))
                {
                    message = "Seen Better Days' building decal renderer is unavailable.";
                    return false;
                }

                Type profileType = assembly.GetType("SeenBetterDays.Data.BuildingVisualProfile");
                Type stateType = assembly.GetType("SeenBetterDays.Data.VisualState");
                if (profileType == null || stateType == null)
                {
                    message = "The installed Seen Better Days version has no compatible visual profile API.";
                    return false;
                }

                MethodInfo debug = profileType.GetMethod("Debug", BindingFlags.Public | BindingFlags.Static);
                object profile = debug?.Invoke(null, new[] { Enum.Parse(stateType, "Neglected"), (object)StableSeed(building, frame) });
                if (profile == null)
                {
                    message = "Seen Better Days' visual profile could not be created.";
                    return false;
                }

                foreach (string family in new[] { "Weathering", "Dirt", "Stain", "Crack", "Moss", "Rust", "Graffiti" })
                {
                    FieldInfo field = profileType.GetField(family, BindingFlags.Public | BindingFlags.Instance);
                    if (field != null) field.SetValue(profile, family == "Graffiti" ? 0.18f : 0f);
                }
                FieldInfo seedField = profileType.GetField("Seed", BindingFlags.Public | BindingFlags.Instance);
                seedField?.SetValue(profile, StableSeed(building, frame));

                FieldInfo forcedDecal = rendererType.GetField("ForcedDecal", BindingFlags.NonPublic | BindingFlags.Instance);
                object previousDecal = forcedDecal?.GetValue(renderer);
                object urbanTagDecal = FindUrbanTagDecal(harness, assembly, building);
                if (forcedDecal != null) forcedDecal.SetValue(renderer, urbanTagDecal);

                try
                {
                    MethodInfo apply = FindApplyMethod(rendererType, profileType);
                    if (apply == null)
                    {
                        message = "Seen Better Days' tracked decal apply method is unavailable.";
                        return false;
                    }
                    object[] args = { building, profile, 0, null };
                    bool applied = (bool)apply.Invoke(renderer, args);
                    message = args[3] as string;
                    if (!applied && string.IsNullOrWhiteSpace(message)) message = "No compatible graffiti decal could be placed on this building.";
                    return applied && (int)args[2] > 0;
                }
                finally
                {
                    if (forcedDecal != null) forcedDecal.SetValue(renderer, previousDecal);
                }
            }
            catch (Exception exception)
            {
                message = exception.GetBaseException().Message;
                return false;
            }
        }

        private static MethodInfo FindApplyMethod(Type rendererType, Type profileType)
        {
            foreach (MethodInfo method in rendererType.GetMethods(BindingFlags.Public | BindingFlags.Instance))
            {
                if (method.Name != "Apply") continue;
                ParameterInfo[] parameters = method.GetParameters();
                if (parameters.Length == 4 && parameters[0].ParameterType == typeof(Entity)
                    && parameters[1].ParameterType == profileType.MakeByRefType()) return method;
            }
            return null;
        }

        private static object FindUrbanTagDecal(object harness, Assembly assembly, Entity building)
        {
            if (harness == null) return null;
            Type harnessType = assembly.GetType("SeenBetterDays.Systems.BuildingOverlayTestSystem");
            object catalog = harnessType?.GetProperty("Catalog", BindingFlags.Public | BindingFlags.Instance)?.GetValue(harness);
            IList decals = catalog?.GetType().GetProperty("BuildingCapable", BindingFlags.Public | BindingFlags.Instance)?.GetValue(catalog) as IList;
            if (decals == null) return null;

            var matches = new List<object>();
            foreach (object decal in decals)
            {
                string name = decal?.GetType().GetProperty("Name")?.GetValue(decal) as string;
                bool affectsBuildings = decal != null && (bool)(decal.GetType().GetProperty("AffectsBuildings")?.GetValue(decal) ?? false);
                if (affectsBuildings && !string.IsNullOrWhiteSpace(name)
                    && name.IndexOf("RZZirrah Tag", StringComparison.OrdinalIgnoreCase) >= 0) matches.Add(decal);
            }
            return matches.Count == 0 ? null : matches[(int)((uint)building.Index % (uint)matches.Count)];
        }

        private static bool TryGetSeenBetterDays(World world, out Assembly assembly, out object renderer, out object harness, out object detailSystem)
        {
            assembly = null;
            renderer = null;
            harness = null;
            detailSystem = null;
            foreach (Assembly candidate in AppDomain.CurrentDomain.GetAssemblies())
                if (candidate.GetName().Name == "SeenBetterDays") { assembly = candidate; break; }
            if (assembly == null) return false;

            Type harnessType = assembly.GetType("SeenBetterDays.Systems.BuildingOverlayTestSystem");
            Type detailType = assembly.GetType("SeenBetterDays.Systems.DecalDetailSystem");
            if (harnessType == null || detailType == null) return false;
            harness = world.GetExistingSystemManaged(harnessType);
            detailSystem = world.GetExistingSystemManaged(detailType);
            if (harness == null) return false;
            renderer = harnessType.GetProperty("DecalRenderer", BindingFlags.Public | BindingFlags.Instance)?.GetValue(harness);
            return renderer != null;
        }

        private static void Restore(World world, Entity building)
        {
            try
            {
                if (!TryGetSeenBetterDays(world, out Assembly assembly, out object renderer, out object harness, out object detailSystem)) return;
                if (detailSystem != null)
                {
                    MethodInfo rebuild = assembly.GetType("SeenBetterDays.Systems.DecalDetailSystem")
                        ?.GetMethod("RebuildNow", BindingFlags.Public | BindingFlags.Instance);
                    if (rebuild != null)
                    {
                        object[] args = { building, null };
                        if ((bool)rebuild.Invoke(detailSystem, args)) return;
                    }
                }

                // Fallback still removes only this building's Seen Better Days overlays.
                renderer.GetType().GetMethod("RemoveIncludingUntracked", BindingFlags.Public | BindingFlags.Instance)
                    ?.Invoke(renderer, new object[] { building });
            }
            catch (Exception exception)
            {
                Mod.log.Warn($"Could not restore Seen Better Days appearance for tagged building {building.Index}: {exception.GetBaseException().Message}");
            }
        }

        private static uint StableSeed(Entity building, uint frame)
        {
            uint seed = unchecked((uint)building.Index * 747796405u + (uint)building.Version * 2891336453u + frame);
            return seed == 0 ? 1u : seed;
        }

        private static void SyncFrame(uint frame)
        {
            if (s_HasFrame && frame < s_LastFrame) s_Tags.Clear();
            s_HasFrame = true;
            s_LastFrame = frame;
        }
    }
}
