using System.Collections.Generic;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Session-only fictional money laundering and enforcement outcomes linked to city addresses.</summary>
    public static class UnderworldOperations
    {
        private static readonly Dictionary<Entity, string> s_Laundering = new Dictionary<Entity, string>();
        private static readonly Dictionary<Entity, string> s_Pharmacy = new Dictionary<Entity, string>();
        private static readonly Dictionary<Entity, string> s_House = new Dictionary<Entity, string>();
        private static readonly Dictionary<Entity, uint> s_LaunderStart = new Dictionary<Entity, uint>();
        private static int s_Raids;
        private static int s_Proceeds;
        private static int s_Searches;
        private static int s_NothingFound;

        public static string Status(Dictionary<Entity, string> ledger, Entity location, string fallback)
            => ledger.TryGetValue(location, out string status) ? status : fallback;

        public static void StartLaundering(Entity location, string place, uint frame)
        {
            s_Laundering[location] = "Simulated operation active";
            s_LaunderStart[location] = frame;
            CityBuzzFeed.Add("Money laundering lead", "City intelligence", place,
                "Fictional Lively Skylines lead: a modeled laundering operation is active at this address. The real business is unchanged.", frame);
        }

        public static string RaidLaundering(Entity location, string place, uint frame, bool found, int recovered)
        {
            s_Raids++;
            s_Proceeds += recovered;
            PublicReactionLedger.Add("Financial-crime raid and city spending", 3);
            s_Laundering[location] = found ? $"Simulated operation disrupted · ${recovered:N0} recovered" : "Raid complete · no evidence found";
            s_LaunderStart.Remove(location);
            string result = found ? $"Simulated police units were dispatched to {place}; the fictional operation was disrupted and ${recovered:N0} in modeled assets were recovered." : $"Simulated police units searched {place} and found no evidence. The real business is unchanged.";
            CityBuzzFeed.Add("Money laundering raid", "City dispatch", place, result, frame);
            return result;
        }

        public static void LeaveLaundering(Entity location, string place, uint frame)
        {
            s_Laundering[location] = "Operation left active";
            CityBuzzFeed.Add("Money laundering lead", "City intelligence", place,
                "The fictional lead was left under observation; no action was taken and the business is unchanged.", frame);
        }

        public static void StartPharmacyMarket(Entity location, string place, string product, uint frame)
        {
            s_Pharmacy[location] = $"Simulated market active · {product}";
            PublicReactionLedger.Add("Nighttime drug-market concerns", 3);
            CityBuzzFeed.Add("Drug market", "City intelligence", place,
                $"Fictional market report: modeled {product} activity near {place}. This does not describe or accuse the real pharmacy.", frame);
        }

        public static string RaidPharmacy(Entity location, string place, uint frame, bool found)
        {
            s_Raids++;
            PublicReactionLedger.Add("Drug-market raid", 2);
            s_Pharmacy[location] = found ? "Simulated shop disrupted" : "Raid complete · nothing found";
            string result = found
                ? $"Fictional enforcement report: a modeled illegal drug-market front was disrupted near {place}. No real pharmacy or company was changed."
                : $"Fictional enforcement report: officers searched the modeled lead at {place} and found nothing. The real pharmacy is unchanged.";
            CityBuzzFeed.Add("Drug market enforcement", "City dispatch", place, result, frame);
            return result;
        }

        public static string SearchHouse(Entity location, string place, uint frame, string finding)
        {
            s_Searches++;
            if (finding == "Nothing found") s_NothingFound++;
            if (finding != "Nothing found") PublicReactionLedger.Add("Police search reported a contraband or hazardous item", 3);
            s_House[location] = finding == "Nothing found" ? "Search complete · nothing found" : $"Search complete · {finding} reported";
            string result = finding == "Nothing found"
                ? $"Fictional police search at {place}: nothing found. The residence is unchanged."
                : $"Fictional police search report at {place}: {finding} reported. No item is depicted or described; the residence is unchanged.";
            CityBuzzFeed.Add("Police search", "City dispatch", place, result, frame);
            return result;
        }

        public static string LaunderingStatus(Entity location, uint frame)
        {
            if (!s_Laundering.TryGetValue(location, out string status)) return "No active lead";
            if (s_LaunderStart.TryGetValue(location, out uint started))
            {
                uint elapsed = frame >= started ? frame - started : 0;
                long modeledFlow = (long)elapsed * 25000 / OutingStarter.FramesPerDay;
                return $"{status} · ${modeledFlow:N0} modeled throughflow";
            }
            return status;
        }
        public static string PharmacyStatus(Entity location) => Status(s_Pharmacy, location, "No modeled market activity");
        public static string HouseStatus(Entity location) => Status(s_House, location, "No search reported");
        public static string Summary => $"{s_Raids}|{s_Proceeds}|{s_Searches}|{s_NothingFound}";
    }
}
