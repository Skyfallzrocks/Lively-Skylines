using System.Collections.Generic;
using System.Globalization;
using System;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Session-only fictional drug-market activity and estimated profits.</summary>
    public static class DrugMarketLedger
    {
        public struct Entry
        {
            public string Group;
            public string Area;
            public string Category;
            public int Buyers;
            public int Sellers;
            public long EstimatedProfit;
            public int Density;
            public uint Frame;
            public Entity Location;
            public string GangBuyer;
            public int WholesaleUnits;
            public long WholesaleValue;
        }

        public struct HealthCall
        {
            public string Group;
            public string Area;
            public string Category;
            public uint Frame;
            public string Response;
        }

        public struct EnforcementReport
        {
            public string Group;
            public string Area;
            public string Message;
            public uint Frame;
        }

        public sealed class DistrictState
        {
            public string Area;
            public int Pressure;
            public int Markets;
            public int Buyers;
            public int Support;
            public int PoliceResponses;
            public int CameraObservations;
            public string Trend = "No recent activity";
            public string LeadingCategory = "No trend";
            public uint LastActivityFrame;
            public uint ActiveUntilFrame;
        }

        private const int kMaxEntries = 50;
        private static readonly List<Entry> s_Entries = new List<Entry>();
        private static readonly List<HealthCall> s_HealthCallEntries = new List<HealthCall>();
        private static readonly List<EnforcementReport> s_EnforcementEntries = new List<EnforcementReport>();
        private static readonly Dictionary<string, DistrictState> s_Districts = new Dictionary<string, DistrictState>();
        private static int s_HealthCalls;
        private static int s_Raids, s_Arrests, s_Referrals, s_SellersReplaced;
        private static readonly string[] s_ProductCategories = CreateProductCategories();

        public static string[] ProductCategories => s_ProductCategories;
        public static string ProductCategoryRows => string.Join("\n", s_ProductCategories);

        private static string[] CreateProductCategories()
        {
            // Fictional street names are randomized once per game session and reused in every report.
            string[] first = { "Silver", "Velvet", "Neon", "Midnight", "Glass", "Quiet", "Amber", "Blue", "Hollow", "Electric", "Soft", "Crimson" };
            string[] second = { "Orchid", "Static", "Comet", "Lantern", "Echo", "Bloom", "Harbor", "Signal", "Mirage", "Garden", "Riddle", "Rain" };
            var random = new System.Random(unchecked(Environment.TickCount * 397 ^ Guid.NewGuid().GetHashCode()));
            var used = new HashSet<string>();
            var result = new string[6];
            for (int i = 0; i < result.Length; i++)
            {
                string name;
                do { name = $"{first[random.Next(first.Length)]} {second[random.Next(second.Length)]}"; }
                while (!used.Add(name));
                result[i] = name;
            }
            return result;
        }

        public static int AveragePressure
        {
            get
            {
                if (s_Districts.Count == 0) return 0;
                int total = 0;
                foreach (DistrictState state in s_Districts.Values) total += state.Pressure;
                return total / s_Districts.Count;
            }
        }

        public static DistrictState GetDistrict(string area)
        {
            area = Clean(area);
            if (!s_Districts.TryGetValue(area, out DistrictState state))
                s_Districts[area] = state = new DistrictState { Area = area };
            return state;
        }

        public static void RecordDistrictMarket(string area, string category, int buyers, bool police, bool camera, uint frame, uint activeUntil)
        {
            DistrictState state = GetDistrict(area);
            state.Markets++;
            state.Buyers += buyers;
            state.LastActivityFrame = frame;
            state.ActiveUntilFrame = activeUntil;
            if (police) state.PoliceResponses++;
            if (camera) state.CameraObservations++;
            int change = 8 + math.min(18, buyers / 2) - (police ? 5 : 0) - (camera ? 4 : 0);
            state.Pressure = Unity.Mathematics.math.clamp(state.Pressure + change, 0, 100);
            state.Trend = state.Pressure >= 70 ? "Rising concern" : state.Pressure >= 35 ? "Building activity" : "Low activity";
            state.LeadingCategory = Clean(category);
        }

        public static void RecordDistrictResponse(string area, int referrals, bool police, bool camera)
        {
            DistrictState state = GetDistrict(area);
            state.Support += math.max(0, referrals);
            state.Pressure = Unity.Mathematics.math.max(0, state.Pressure - math.min(18, referrals + (police ? 5 : 0) + (camera ? 3 : 0)));
            state.Trend = state.Pressure >= 70 ? "Rising concern" : state.Pressure >= 35 ? "Building activity" : "Responding";
        }

        public static void DecayDistrictPressure()
        {
            foreach (DistrictState state in s_Districts.Values)
            {
                state.Pressure = Unity.Mathematics.math.max(0, state.Pressure - 3);
                if (state.Pressure < 35 && state.Trend != "Responding") state.Trend = state.Pressure == 0 ? "No recent activity" : "Low activity";
            }
        }

        public static string DistrictRows(uint frame)
        {
            var rows = new List<string>();
            foreach (DistrictState state in s_Districts.Values)
                rows.Add($"{Clean(state.Area)}|{state.Pressure}|{state.Markets}|{state.Buyers}|{state.Support}|{state.PoliceResponses}|{state.CameraObservations}|{Clean(state.Trend)}|{Clean(state.LeadingCategory)}|{(frame < state.ActiveUntilFrame ? "Active" : "Quiet")}");
            rows.Sort((a, b) => string.CompareOrdinal(a, b));
            return string.Join("\n", rows);
        }

        public static void Add(string group, string area, string category, int buyers, int sellers, long estimatedProfit, int density, uint frame, Entity location, string gangBuyer = "", int wholesaleUnits = 0, long wholesaleValue = 0)
        {
            s_Entries.Insert(0, new Entry { Group = Clean(group), Area = Clean(area), Category = Clean(category), Buyers = buyers, Sellers = sellers, EstimatedProfit = estimatedProfit, Density = density, Frame = frame, Location = location, GangBuyer = Clean(gangBuyer), WholesaleUnits = wholesaleUnits, WholesaleValue = wholesaleValue });
            if (s_Entries.Count > kMaxEntries) s_Entries.RemoveRange(kMaxEntries, s_Entries.Count - kMaxEntries);
        }

        public static void RecordHealthCall(string group, string area, string category, uint frame, string response)
        {
            s_HealthCalls++;
            s_HealthCallEntries.Insert(0, new HealthCall { Group = Clean(group), Area = Clean(area), Category = Clean(category), Frame = frame, Response = Clean(response) });
            if (s_HealthCallEntries.Count > 50) s_HealthCallEntries.RemoveRange(50, s_HealthCallEntries.Count - 50);
        }

        public static void RecordEnforcement(int arrests, int referrals, int sellersReplaced, bool raid)
        {
            if (raid) s_Raids++;
            s_Arrests += arrests;
            s_Referrals += referrals;
            s_SellersReplaced += sellersReplaced;
        }

        public static void AddEnforcementReport(string group, string area, string message, uint frame)
        {
            s_EnforcementEntries.Insert(0, new EnforcementReport { Group = Clean(group), Area = Clean(area), Message = Clean(message), Frame = frame });
            if (s_EnforcementEntries.Count > 50) s_EnforcementEntries.RemoveRange(50, s_EnforcementEntries.Count - 50);
        }

        public static string EnforcementRows(uint frame)
        {
            uint retention = OutingStarter.FramesPerDay * 30u;
            var rows = new List<string>();
            foreach (EnforcementReport report in s_EnforcementEntries)
            {
                if (frame >= report.Frame && frame - report.Frame > retention) continue;
                rows.Add($"{Clean(report.Group)}|{Clean(report.Area)}|{Clean(report.Message)}|{Age(frame, report.Frame)}|{report.Frame}");
            }
            return string.Join("\n", rows);
        }

        public static List<Entry> Recent(uint frame)
        {
            uint retention = OutingStarter.FramesPerDay * 7u;
            var result = new List<Entry>(s_Entries.Count);
            foreach (Entry entry in s_Entries)
                if (frame < entry.Frame || frame - entry.Frame <= retention) result.Add(entry);
            return result;
        }

        public static string Rows(uint frame)
        {
            var rows = new List<string>();
            foreach (Entry entry in Recent(frame))
                rows.Add($"{rows.Count}|{Clean(entry.Group)}|{Clean(entry.Area)}|{entry.Buyers}|{entry.EstimatedProfit}|{entry.Density}|{Age(frame, entry.Frame)}|{entry.Sellers}|{Clean(entry.Category)}|{entry.Frame}|{Clean(entry.GangBuyer)}|{entry.WholesaleUnits}|{entry.WholesaleValue}");
            return string.Join("\n", rows);
        }

        public static string HealthRows(uint frame)
        {
            uint retention = OutingStarter.FramesPerDay * 30u;
            var rows = new List<string>();
            foreach (HealthCall call in s_HealthCallEntries)
            {
                if (frame >= call.Frame && frame - call.Frame > retention) continue;
                rows.Add($"{Clean(call.Group)}|{Clean(call.Area)}|{Clean(call.Category)}|{Age(frame, call.Frame)}|{Clean(call.Response)}|{call.Frame}");
            }
            return string.Join("\n", rows);
        }

        public static string Summary(uint frame)
        {
            int reports = 0, buyers = 0;
            long profit = 0;
            long dailyProfit = 0;
            int gangDeals = 0, gangUnits = 0;
            uint day = OutingStarter.FramesPerDay;
            var byArea = new Dictionary<string, int>();
            foreach (Entry entry in Recent(frame))
            {
                reports++; buyers += entry.Buyers; profit += entry.EstimatedProfit;
                if (frame < entry.Frame || frame - entry.Frame <= day) dailyProfit += entry.EstimatedProfit;
                if (entry.WholesaleUnits > 0) { gangDeals++; gangUnits += entry.WholesaleUnits; }
                byArea.TryGetValue(entry.Area, out int count); byArea[entry.Area] = count + 1;
            }
            string busiest = "None reported"; int busiestCount = 0;
            foreach (KeyValuePair<string, int> item in byArea)
                if (item.Value > busiestCount) { busiest = item.Key; busiestCount = item.Value; }
            return $"{reports}|{buyers}|{profit.ToString(CultureInfo.InvariantCulture)}|{busiest}|{s_HealthCalls}|{dailyProfit.ToString(CultureInfo.InvariantCulture)}|{gangDeals}|{gangUnits}|{s_Raids}|{s_Arrests}|{s_SellersReplaced}|{s_Referrals}|{AveragePressure}|{s_Districts.Count}";
        }

        private static string Age(uint frame, uint reported)
        {
            uint hours = OutingStarter.FramesPerDay / 24u;
            uint elapsed = frame >= reported ? frame - reported : 0;
            if (elapsed < hours) return "Just now";
            if (elapsed < OutingStarter.FramesPerDay) return $"{elapsed / hours} in-game hours ago";
            uint days = elapsed / OutingStarter.FramesPerDay;
            return days == 1 ? "Yesterday" : $"{days} in-game days ago";
        }

        private static string Clean(string value) => (value ?? "Unknown").Replace("|", "/").Replace("\r", " ").Replace("\n", " ");
    }
}
