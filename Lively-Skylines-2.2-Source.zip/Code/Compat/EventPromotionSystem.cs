using System.Collections.Generic;
using Game;
using Game.Citizens;
using Game.City;
using Game.Common;
using Game.Simulation;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    public enum EventPurchase
    {
        Promote,
        Security,
    }

    public static class EventPurchaseQueue
    {
        public struct Request
        {
            public int EventIndex;
            public EventPurchase Purchase;
        }

        private static readonly Queue<Request> s_Queue = new Queue<Request>();
        public static string Status { get; private set; } = "Choose an active event to promote it or hire security.";

        public static void Enqueue(int index, EventPurchase purchase)
        {
            s_Queue.Enqueue(new Request { EventIndex = index, Purchase = purchase });
        }

        public static bool TryDequeue(out Request request)
        {
            if (s_Queue.Count > 0)
            {
                request = s_Queue.Dequeue();
                return true;
            }

            request = default;
            return false;
        }

        public static void SetStatus(string status) => Status = status;
    }

    // Applies player purchases in the simulation phase so city funds and citizen
    // components are changed on the same phase as other gameplay systems.
    public partial class EventPromotionSystem : GameSystemBase
    {
        public const int kPromotionCost = 25000;
        public const int kSecurityCost = 15000;

        private CitySystem m_CitySystem;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
            m_CandidateQuery = GetEntityQuery(
                ComponentType.ReadOnly<Citizen>(),
                ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(),
                ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(
                ComponentType.ReadOnly<Citizen>(),
                ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 16;

        protected override void OnUpdate()
        {
            var settings = Mod.Settings;
            if (settings == null || !settings.Enabled)
            {
                return;
            }

            if (!settings.EventPurchasesEnabled)
            {
                while (EventPurchaseQueue.TryDequeue(out _)) { }
                EventPurchaseQueue.SetStatus("Event promotion and security are turned off in Bar Rush settings.");
                return;
            }

            while (EventPurchaseQueue.TryDequeue(out EventPurchaseQueue.Request request))
            {
                if (request.Purchase == EventPurchase.Promote)
                {
                    Promote(request.EventIndex, settings);
                }
                else
                {
                    HireSecurity(request.EventIndex);
                }
            }
        }

        private void Promote(int eventIndex, Setting settings)
        {
            uint frame = World.GetOrCreateSystemManaged<SimulationSystem>().frameIndex;
            if (!ActiveEvents.TryGet(frame, eventIndex, out ActiveEvents.Entry activeEvent))
            {
                EventPurchaseQueue.SetStatus("That event has ended. Open Promotions again to refresh the list.");
                return;
            }

            if (!CanAfford(kPromotionCost))
            {
                EventPurchaseQueue.SetStatus("Not enough city funds for promotion ($25,000).");
                return;
            }

            int population = m_PopulationQuery.CalculateEntityCount();
            int cap = PopulationCap.MaxAttendees(population, settings.MaxAttendancePercent);
            int remaining = AttendanceLedger.Remaining(cap, frame);
            int target = math.min(math.max(1, population / 20), remaining); // up to 5% of population
            if (target <= 0)
            {
                EventPurchaseQueue.SetStatus("The city's active nightlife is already at its attendance cap.");
                return;
            }

            using NativeArray<Entity> candidates = m_CandidateQuery.ToEntityArray(Allocator.Temp);
            var random = new Random(math.max(1u, frame ^ ((uint)(eventIndex + 1) * 2654435761u)));
            uint duration = activeEvent.EndFrame > frame ? activeEvent.EndFrame - frame : 0u;
            int started = OutingStarter.Start(EntityManager, candidates, target, ref random, frame, duration);
            if (started <= 0)
            {
                EventPurchaseQueue.SetStatus("No eligible sims could join this promotion; no money was charged.");
                return;
            }

            if (!ActiveEvents.AddAttendees(frame, eventIndex, started))
            {
                EventPurchaseQueue.SetStatus("That event ended before the promotion could be applied.");
                return;
            }

            AttendanceLedger.Add(started, activeEvent.EndFrame);
            Charge(kPromotionCost);
            EventPurchaseQueue.SetStatus($"Promotion purchased: {started:N0} more sims started a night out. ($25,000)");
        }

        private void HireSecurity(int eventIndex)
        {
            uint frame = World.GetOrCreateSystemManaged<SimulationSystem>().frameIndex;
            if (!ActiveEvents.TryGet(frame, eventIndex, out ActiveEvents.Entry activeEvent))
            {
                EventPurchaseQueue.SetStatus("That event has ended. Open Promotions again to refresh the list.");
                return;
            }

            if (activeEvent.Building == Entity.Null)
            {
                EventPurchaseQueue.SetStatus("Security can only be hired for an event at a bar.");
                return;
            }

            if (activeEvent.Security)
            {
                EventPurchaseQueue.SetStatus("Security is already hired for this event.");
                return;
            }

            if (!CanAfford(kSecurityCost))
            {
                EventPurchaseQueue.SetStatus("Not enough city funds for event security ($15,000).");
                return;
            }

            if (!ActiveEvents.HireSecurity(frame, eventIndex))
            {
                EventPurchaseQueue.SetStatus("Security could not be assigned to that event.");
                return;
            }

            Charge(kSecurityCost);
            EventPurchaseQueue.SetStatus($"Security hired for {activeEvent.Title} at {activeEvent.Place}. ($15,000)");
        }

        private bool CanAfford(int amount)
        {
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city))
            {
                EventPurchaseQueue.SetStatus("City funds are not available right now.");
                return false;
            }

            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            return money.m_Unlimited || money.money >= amount;
        }

        private void Charge(int amount)
        {
            Entity city = m_CitySystem.City;
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            money.Subtract(amount);
            EntityManager.SetComponentData(city, money);
        }
    }
}
