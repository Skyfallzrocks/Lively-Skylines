using System;
using System.Collections.Generic;

namespace BarRush
{
    /// <summary>Session-level city ordinances and modeled council/election actions.</summary>
    public static class CityPolicyLedger
    {
        private sealed class Policy
        {
            public string Name;
            public string Category;
            public string Description;
            public string Pros;
            public string Cons;
            public string Status;
            public int CrimeOffset;   // violent-crime chance points while active (negative = safer)
            public int MonthlyBudget; // city money per 30 in-game days while active (+ income, - cost)
            public int Mood;          // public anger change when enacted (+ angrier, - calmer)
            public int MinPopulation; // locked until the city reaches this population
            public int[] Stance;      // Democratic, Republican, Green, Independent: -2..+2
            public int Yes;
            public int No;
            public int MayorLean;      // -1 lobbying against, 0 neutral, +1 lobbying for
            public string Votes = "";  // roll call per council seat: Y / N / - (vacant)

            public Policy(string name, string category, string description, string pros, string cons, string status, int crime, int budget, int mood, int minPopulation, int[] stance)
            { Name = name; Category = category; Description = description; Pros = pros; Cons = cons; Status = status; CrimeOffset = crime; MonthlyBudget = budget; Mood = mood; MinPopulation = minPopulation; Stance = stance; }

            public string Effects
            {
                get
                {
                    var parts = new List<string>(3);
                    if (CrimeOffset != 0) parts.Add($"Crime {(CrimeOffset > 0 ? "+" : "−")}{Math.Abs(CrimeOffset) * 3}%");
                    if (MonthlyBudget != 0) parts.Add($"{(MonthlyBudget > 0 ? "+" : "−")}${Math.Abs(MonthlyBudget):N0}/mo");
                    if (Mood != 0) parts.Add(Mood > 0 ? $"Anger +{Mood}" : $"Calm +{-Mood}");
                    return parts.Count > 0 ? string.Join(" · ", parts) : "No direct city effects";
                }
            }

            public string Cost => MonthlyBudget == 0 ? "No direct cost" : MonthlyBudget > 0 ? $"+${MonthlyBudget:N0} / mo income" : $"−${-MonthlyBudget:N0} / mo";
        }

        private static readonly Policy[] s_Policies =
        {
            new Policy("Sanctuary City", "Civic & rights", "Local police and city services do not take part in outside immigration enforcement. Residents can report crimes and use services without being asked about status.", "More residents report crimes and use clinics · Trust +8", "Some state and federal grants are lost · Political backlash in parts of the city", "Vote pending", -1, -12000, 2, 0, new[] { 2,-2,2,0 }),
            new Policy("Late-Night Licenses", "Nightlife", "Bars may serve until 4 AM. Sims stay later and the midnight rush runs longer.", "Bar revenue +14% · Longer midnight rush · More nightlife jobs", "Noise complaints +11 · Late-night crime up", "Active", 2, 14000, 2, 0, new[] { 1,2,-1,1 }),
            new Policy("Open Patio Law", "Nightlife", "Eligible venues may seat and serve customers outdoors.", "Foot traffic +18% · Livelier streets", "More litter · Sidewalk crowding", "Active", 0, -2000, -1, 0, new[] { 1,1,1,1 }),
            new Policy("Body Cameras", "Public safety", "Officers record every call. Footage is kept for review.", "Complaints drop · Convictions stick more often · Trust +10", "Ongoing storage and equipment cost", "Active", -2, -6400, -2, 0, new[] { 2,1,2,1 }),
            new Policy("Noise Curfew", "Public safety", "Outdoor music must stop at 11 PM.", "Residents sleep better · Grievance −6", "Events lose 22% of their reach · Venues lose late revenue", "Available", -1, -2000, -3, 0, new[] { -1,1,1,0 }),
            new Policy("Nightlife Levy", "Economy", "A small tax on bar revenue funds public cleanup.", "City income +$18k/mo · Cleaner streets after closing", "Bar profits −8% · Owners complain", "Available", 0, 18000, 1, 0, new[] { 1,-2,2,-1 }),
            new Policy("Anti-Corruption Audits", "Public safety", "Financial Crimes inspects bar books more often and hardens laundering fronts.", "Laundering risk −35% · Cleaner government", "Audit staff cost · Paperwork for small businesses", "Available", -1, -9100, -2, 0, new[] { 2,-1,2,1 }),
            new Policy("Neighborhood Watch", "Public safety", "Residents report trouble near bars through a city hotline.", "Tips +15% · Faster police response", "More false alarms · Profiling concerns", "Available", -3, -1500, 0, 0, new[] { -1,2,-1,1 }),
            new Policy("Gambling Licenses", "Economy", "Allows casinos and betting rooms in the city.", "Revenue +$40k/mo · Tourism up", "Crime +20% near venues · Problem gambling", "Available", 3, 40000, 2, 20000, new[] { -1,1,-2,0 }),
            new Policy("Rent Control", "Housing", "Caps yearly rent increases for existing tenants.", "Tenants stay in their homes · Fewer evictions", "Less new housing gets built · Landlords put off repairs", "Available", 0, -3000, -3, 0, new[] { 2,-2,2,-1 }),
            new Policy("Upzoning Near Transit", "Housing", "Allows apartment buildings near stations and main roads.", "More homes · Lower long-run rents · Bigger tax base", "Neighborhood pushback · Construction noise", "Available", 0, 6000, 2, 0, new[] { 1,0,1,1 }),
            new Policy("Short-Term Rental Ban", "Housing", "Bans whole-home short-term rentals in residential zones.", "Frees up homes for residents · Quieter streets", "Tourism and host income drop · Fewer visitors at bars", "Available", 0, -4000, -1, 0, new[] { 1,-2,1,0 }),
            new Policy("Homeless Shelter Expansion", "Health & social", "Funds new shelter beds and case workers.", "Fewer encampments · Safer parks", "Expensive · Not-in-my-backyard complaints", "Available", -1, -22000, 0, 0, new[] { 2,-1,2,1 }),
            new Policy("Public Camping Ban", "Public safety", "Bans sleeping and camping in parks and on sidewalks.", "Clears encampments from parks", "Moves people around without housing them · Fines go unpaid", "Available", -1, -5000, 1, 0, new[] { -2,2,-2,1 }),
            new Policy("Safe Consumption Site", "Health & social", "A supervised site where drug users get medical care and treatment referrals.", "Fewer overdose deaths · More people enter treatment", "Neighbors fear more crime · Highly controversial", "Available", 1, -15000, 3, 0, new[] { 1,-2,2,-1 }),
            new Policy("Police Budget Increase", "Public safety", "Adds officers and patrol cars.", "Faster responses · More patrols near bars", "Very expensive · Trust concerns in some wards", "Available", -3, -30000, 0, 0, new[] { 0,2,-2,1 }),
            new Policy("Civilian Crisis Responders", "Public safety", "Mental-health teams answer non-violent 911 calls.", "Frees up police · Fewer escalations", "Ongoing cost · Slower for some calls", "Available", -1, -12000, -2, 0, new[] { 2,-1,2,1 }),
            new Policy("Youth Curfew", "Public safety", "Under-18s must be off the streets by 11 PM.", "Fewer late-night teen incidents", "Civil-liberty complaints · Uses officer time", "Available", -1, -2500, 1, 0, new[] { -1,1,-1,0 }),
            new Policy("Gun-Free Nightlife Zones", "Public safety", "No firearms inside bars or within a block of nightlife strips.", "Fewer shootings near bars", "Hard to enforce · Gun-rights objections", "Available", -2, -4000, 1, 0, new[] { 2,-2,2,0 }),
            new Policy("Stop-and-Frisk Patrols", "Public safety", "Officers may stop and search pedestrians in high-crime areas.", "More weapons seized", "Trust collapses in targeted wards · Lawsuits", "Available", -2, -8000, 5, 0, new[] { -2,1,-2,-1 }),
            new Policy("Traffic Safety Cameras", "Transport", "Red-light and speed cameras on busy roads.", "Fewer crashes · Fine revenue", "Seen as a cash grab", "Available", 0, 9000, 2, 0, new[] { 1,-1,1,0 }),
            new Policy("Congestion Charge", "Transport", "Drivers pay to enter downtown at peak times.", "Less traffic · Funds transit", "Hurts commuters and downtown shops", "Available", 0, 20000, 4, 30000, new[] { 1,-2,2,-1 }),
            new Policy("Free Public Transit", "Transport", "All buses and trains are free to ride.", "More riders · Fewer cars", "Large budget hole", "Available", 0, -35000, -4, 0, new[] { 1,-2,2,-1 }),
            new Policy("Protected Bike Lanes", "Transport", "Builds a connected network of separated bike lanes.", "Safer cycling · Bike-share use up", "Loses street parking · Some business complaints", "Available", 0, -7000, 1, 0, new[] { 1,-1,2,0 }),
            new Policy("Late-Night Transit", "Nightlife", "Buses and trains run until 4 AM on weekends.", "Safer rides home · Fewer drunk drivers", "Costly, often empty late runs", "Available", -1, -11000, -1, 0, new[] { 1,0,1,1 }),
            new Policy("Ride-Share Pickup Zones", "Nightlife", "Dedicated curb zones outside busy bar strips.", "Less double parking · Faster pickups", "Takes curb space from deliveries", "Available", 0, -1500, -1, 0, new[] { 1,1,1,1 }),
            new Policy("Happy Hour Ban", "Nightlife", "Bans discounted drink specials.", "Less binge drinking · Fewer fights", "Bar revenue drops · Very unpopular with patrons", "Available", -1, -3000, 2, 0, new[] { 0,-1,1,-1 }),
            new Policy("Bar Security Mandate", "Nightlife", "Bars over 100 capacity must employ licensed door staff.", "Fewer fights and robberies", "Small bars pay more · Some may close", "Available", -2, 0, 0, 0, new[] { 1,-1,1,0 }),
            new Policy("Single-Use Plastics Ban", "Environment", "Bans plastic bags, cups and straws at shops and events.", "Less litter after events", "Higher costs for venues", "Available", 0, -1000, 1, 0, new[] { 1,-2,2,0 }),
            new Policy("Green Roof Requirement", "Environment", "New large buildings must include green roofs.", "Cooler streets · Less flooding", "Raises building costs", "Available", 0, -2000, 0, 0, new[] { 1,-2,2,-1 }),
            new Policy("Clean Energy Mandate", "Environment", "City buildings switch to renewable power.", "Cleaner air · Long-run savings", "Higher short-term utility bills", "Available", 0, -16000, 1, 0, new[] { 2,-2,2,0 }),
            new Policy("Tree Planting Program", "Environment", "Plants street trees across every ward.", "Shade · Happier residents", "Upkeep costs", "Available", 0, -4500, -2, 0, new[] { 1,1,2,1 }),
            new Policy("Small Business Tax Cut", "Economy", "Lowers local taxes for businesses under 50 staff.", "More shops open · More jobs", "Less city revenue", "Available", 0, -15000, -2, 0, new[] { 0,2,-1,1 }),
            new Policy("Minimum Wage Increase", "Economy", "Raises the city minimum wage.", "Workers earn more · Spending goes up", "Some businesses cut staff or hours", "Available", -1, 0, -1, 0, new[] { 2,-2,2,0 }),
            new Policy("Property Tax Hike", "Economy", "Raises property taxes to fund services.", "Big revenue for city services", "Very unpopular · Pushes rents up", "Available", 0, 45000, 6, 0, new[] { 0,-2,1,-1 }),
            new Policy("Tourism Marketing Fund", "Economy", "Advertises the city's nightlife and events.", "More visitors at bars and events", "Costs money · Results vary", "Available", 0, -10000, 0, 0, new[] { 1,1,0,1 }),
            new Policy("Street Vendor Permits", "Economy", "Licensed food carts may operate near nightlife strips.", "Food carts liven up the night · Permit income", "Restaurants complain · More litter", "Available", 0, 2500, 0, 0, new[] { 1,0,1,1 }),
            new Policy("Universal Pre-K", "Health & social", "Free preschool for every 4-year-old.", "Parents can work · Long-term gains", "Expensive", "Available", -1, -25000, -3, 0, new[] { 2,-1,2,0 }),
            new Policy("Free Clinic Network", "Health & social", "Neighborhood clinics with free basic care.", "Fewer ER visits · Healthier workforce", "Expensive to run", "Available", 0, -18000, -3, 0, new[] { 2,-1,2,1 }),
            new Policy("Voter ID Requirement", "Civic & rights", "Voters must show photo ID at polling stations.", "Supporters say it boosts confidence in elections", "Critics say it lowers turnout", "Available", 0, -2000, 2, 0, new[] { -2,2,-2,0 }),
            new Policy("Same-Day Voter Registration", "Civic & rights", "Residents can register and vote on election day.", "Higher turnout", "Critics worry about verification", "Available", 0, -1500, 1, 0, new[] { 2,-2,2,0 }),
            new Policy("Council Term Limits", "Civic & rights", "Council members may serve at most two terms.", "Fresh leadership · Less entrenched power", "Experienced members are forced out", "Available", 0, 0, -2, 0, new[] { 0,1,0,2 }),
            new Policy("Police Oversight Board", "Civic & rights", "A civilian board reviews misconduct complaints.", "Accountability · Trust up", "Police unions object · Morale concerns", "Available", 0, -5000, -1, 0, new[] { 2,-1,2,1 }),
            new Policy("Public Campaign Financing", "Civic & rights", "Matches small donations with public funds.", "Less big-donor influence", "Taxpayer cost", "Available", 0, -8000, 0, 0, new[] { 2,-1,2,1 }),
            new Policy("Graffiti Removal Crew", "Public safety", "A city crew removes tags within 48 hours.", "Cleaner streets · Fewer repeat tags", "Some street art is lost", "Available", -1, -3500, -1, 0, new[] { 1,2,0,1 }),
        };

        // ---- Party platforms: each Policy carries its party stances (Democratic, Republican, Green, Independent).
        private static readonly string[] s_SeatParty = { "Democratic Party", "Republican Party", "Democratic Party", "Green Party", "Independent", "Republican Party", "Democratic Party", "Green Party", "Independent", "Vacant" };
        private static readonly string[] s_SeatName = { "Maya Thompson", "Elliot Brooks", "Priya Patel", "Andre Williams", "Sofia Kim", "Noah Bennett", "Grace Okafor", "Luis Hernandez", "Amara Johnson", "Vacant seat" };
        private static readonly int[] s_SeatApproval = { 54, 61, 68, 75, 82, 89, 59, 66, 73, 0 };
        private static readonly string[] s_SeatWard = { "Ward 1 · Ridgeview", "Ward 2 · West End", "Ward 3 · Central", "Ward 4 · Lakeside", "Ward 5 · Eastwood", "Ward 6 · Northside", "Ward 7 · Southgate", "At-large", "At-large", "At-large" };
        private static readonly string[] s_NamePool = { "Jordan Reyes", "Hannah Cole", "Marcus Lee", "Isabel Ortiz", "Victor Hale", "Nadia Brooks", "Owen Price", "Leah Kim", "Diego Navarro", "Ruth Adams", "Kofi Mensah", "Erin Walsh", "Samir Haddad", "Tessa Long", "Caleb Ford", "Mei Chen", "Ronan Doyle", "Aisha Bello", "Wyatt Hayes", "Lucia Romero" };
        private static int s_NameCursor;
        private static int s_MayorParty = 3; // incumbent Daniel Mercer runs as an Independent
        private static string s_LastCouncilResult = "";

        private static readonly string[] s_PartyNames = { "Democratic Party", "Republican Party", "Green Party", "Independent" };

        /// <summary>Poll support by party (Democratic, Republican, Green, Independent), summing to 100.</summary>
        private static float[] PartySupport()
        {
            var sup = new float[4];
            for (int i = 0; i < s_Parties.Length; i++) sup[PartyIndex(s_Parties[i])] += s_PollSupport[i];
            return sup;
        }

        private static void CouncilElection(uint frame)
        {
            float[] sup = PartySupport();
            var random = new Unity.Mathematics.Random(Math.Max(1u, frame * 2246822519u + (uint)s_ElectionNumber * 3266489917u));
            int flips = 0;
            var seats = new int[4];
            for (int m = 0; m < s_SeatParty.Length; m++)
            {
                bool vacant = s_SeatParty[m] == "Vacant";
                int current = vacant ? -1 : PartyIndex(s_SeatParty[m]);
                var w = new float[4]; float total = 0f;
                for (int k = 0; k < 4; k++)
                {
                    w[k] = Math.Max(1f, sup[k]);
                    if (k == current) w[k] *= 1.6f + s_SeatApproval[m] / 120f; // incumbency + approval advantage
                    total += w[k];
                }
                float roll = random.NextFloat() * total; int pick = 3;
                for (int k = 0; k < 4; k++) { if (roll < w[k]) { pick = k; break; } roll -= w[k]; }
                if (pick != current)
                {
                    flips++;
                    s_SeatParty[m] = s_PartyNames[pick];
                    s_SeatName[m] = s_NamePool[s_NameCursor++ % s_NamePool.Length];
                    s_SeatApproval[m] = random.NextInt(48, 66);
                }
                else s_SeatApproval[m] = Math.Max(30, Math.Min(95, s_SeatApproval[m] + random.NextInt(-6, 7)));
                seats[pick]++;
            }
            s_LastCouncilResult = $"Council: {seats[0]} Democratic · {seats[1]} Republican · {seats[2]} Green · {seats[3]} Independent · {flips} seat(s) changed hands";
            CityBuzzFeed.Add("City election · council results", "Election desk", "City Hall", s_LastCouncilResult + ". The new council takes its seats immediately and votes on all pending laws.", frame);
        }

        /// <summary>A campaign rally (held as a real park event) boosts the candidate's polling.</summary>
        public static void Rally(int candidate, bool big, uint frame)
        {
            if (candidate < 0 || candidate >= s_CandidateNames.Length) return;
            float boost = big ? 2.2f : 1.1f;
            s_CampaignShift[candidate] += boost;
            s_CampaignFunds[candidate] = Math.Max(0, s_CampaignFunds[candidate] - (big ? 75000 : 25000));
            RecalculatePoll();
            CityBuzzFeed.Add("Campaign rally", "Election desk", "City park", $"{s_CandidateNames[candidate]} ({s_Parties[candidate]}) held a {(big ? "mass" : "neighborhood")} rally. Polling moved {boost:0.0} points in their favor.", frame);
            s_ElectionStatus = $"{s_CandidateNames[candidate]} rallied supporters · now polling {s_PollSupport[candidate]:0.0}%.";
        }
        // Personal lean of each member: +1 leans yes on swing votes, -1 leans no, 0 follows the party.
        private static readonly int[] s_SeatLean = { 0, 1, -1, 0, 1, -1, 0, 1, -1, 0 };

        private static int PartyIndex(string party)
        {
            if (party.StartsWith("Democratic", StringComparison.Ordinal)) return 0;
            if (party.StartsWith("Republican", StringComparison.Ordinal)) return 1;
            if (party.StartsWith("Green", StringComparison.Ordinal)) return 2;
            return 3;
        }

        /// <summary>Roll call for a policy: every seated member votes their party's platform.</summary>
        private static string RollCall(int policyIndex, Policy p, out int yes, out int no)
        {
            yes = 0; no = 0;
            var call = new char[s_SeatParty.Length];
            for (int m = 0; m < s_SeatParty.Length; m++)
            {
                if (s_SeatParty[m] == "Vacant") { call[m] = '-'; continue; }
                int stance = p.Stance[PartyIndex(s_SeatParty[m])];
                bool vote;
                if (stance >= 2) vote = true;
                else if (stance <= -2) vote = false;
                else
                {
                    int total = stance + s_SeatLean[m] + p.MayorLean * (PartyIndex(s_SeatParty[m]) == s_MayorParty ? 2 : 1);
                    vote = total == 0 ? ((m + policyIndex) % 2 == 0) : total > 0;
                }
                call[m] = vote ? 'Y' : 'N';
                if (vote) yes++; else no++;
            }
            return new string(call);
        }

        private static int s_Population;
        private static uint s_LastBudgetFrame;
        private static bool IsLocked(Policy p) => p.Status != "Active" && p.MinPopulation > 0 && s_Population < p.MinPopulation;

        /// <summary>Net monthly budget of all active ordinances (+ income, - cost).</summary>
        public static int NetMonthlyBudget { get { int n = 0; foreach (Policy p in s_Policies) if (p.Status == "Active") n += p.MonthlyBudget; return n; } }

        /// <summary>Returns the ordinance budget due once every 30 in-game days, otherwise 0.</summary>
        public static int TakeMonthlyBudget(uint frame)
        {
            if (s_LastBudgetFrame == 0 || frame < s_LastBudgetFrame) { s_LastBudgetFrame = frame; return 0; }
            if (frame - s_LastBudgetFrame < OutingStarter.FramesPerDay * 30u) return 0;
            s_LastBudgetFrame = frame;
            return NetMonthlyBudget;
        }

        private static int s_ElectionNumber;
        private static string s_Mayor = "Mayor Daniel Mercer";
        private static string s_ElectionStatus = "Next city election has not been called.";
        private static readonly string[] s_CandidateNames = { "Tara Whitfield", "Marcus Vale", "Lena Cruz", "Dante Salazar", "Daniel Mercer" };
        private static readonly string[] s_Parties = { "Democratic Party", "Republican Party", "Green Party", "Independent", "Incumbent · Independent" };
        private static readonly string[] s_Colors = { "#f23f9e", "#ff526f", "#43d58a", "#d9a741", "#48c8ef" };
        private static readonly string[] s_Promises = { "Affordable housing · safer streets", "Lower taxes · small business", "Clean energy · transit", "Neighborhood jobs · public safety", "Steady services · balanced budget" };
        private static readonly int[] s_CampaignFunds = { 2120000, 1560000, 980000, 760000, 2840000 };
        private static readonly float[] s_BaseSupport = { 32.4f, 24.8f, 18.7f, 12.1f, 11.9f };
        private static readonly float[] s_CampaignShift = new float[5];
        private static float[] s_PollSupport = { 32.4f, 24.8f, 18.7f, 12.1f, 11.9f };
        private static int[] s_LastVotes = new int[5];
        private static float[] s_LastShare = new float[5];
        private static int s_RegisteredVoters = 1000;
        private static int s_LastTotalVotes;
        private static int s_LastTurnout;
        private static int s_PollCount;
        private static int s_DebateCount;
        private static uint s_NextElectionFrame;
        private static uint s_LastFrame;
        private static bool s_HasElectionRun;

        public static bool IsActive(string name) { foreach (Policy p in s_Policies) if (p.Name == name) return p.Status == "Active"; return false; }
        public static int ActiveCount { get { int n = 0; foreach (Policy p in s_Policies) if (p.Status == "Active") n++; return n; } }
        public static int PendingCount { get { int n = 0; foreach (Policy p in s_Policies) if (p.Status == "Vote pending") n++; return n; } }
        public static string Mayor => s_Mayor;
        public static string ElectionStatus => s_ElectionStatus;

        public static void Advance(uint frame, int population)
        {
            if (frame < s_LastFrame)
            {
                s_NextElectionFrame = 0;
                s_HasElectionRun = false;
            }
            s_LastFrame = frame;
            s_Population = Math.Max(0, population);
            s_RegisteredVoters = Math.Max(1, (int)Math.Round(Math.Max(0, population) * 0.72));
            if (s_NextElectionFrame == 0) s_NextElectionFrame = frame + AnnualElectionFrames;
            if (frame >= s_NextElectionFrame)
            {
                RunElection(frame, true);
                s_NextElectionFrame = frame + AnnualElectionFrames;
            }
            RecalculatePoll();
        }

        private static uint AnnualElectionFrames => OutingStarter.FramesPerDay * 365u;

        public static string ElectionStats(uint frame)
        {
            if (s_NextElectionFrame == 0) s_NextElectionFrame = frame + AnnualElectionFrames;
            uint daysLeft = frame < s_NextElectionFrame ? (s_NextElectionFrame - frame) / OutingStarter.FramesPerDay : 0u;
            int turnoutForecast = Math.Max(35, Math.Min(90, 62 + PublicReactionLedger.Anger / 5));
            int funds = 0;
            foreach (int amount in s_CampaignFunds) funds += amount;
            return $"{s_RegisteredVoters}|{turnoutForecast}|{funds}|{s_LastTotalVotes}|{daysLeft}|{s_ElectionNumber}|{s_PollCount}|{s_DebateCount}|{s_LastTurnout}";
        }

        public static string CandidateRows
        {
            get
            {
                RecalculatePoll();
                var rows = new List<string>(s_CandidateNames.Length);
                for (int i = 0; i < s_CandidateNames.Length; i++)
                {
                    string endorsement = i == 0 ? "Neighborhood Coalition" : i == 1 ? "Business Alliance" : i == 2 ? "Green Future Coalition" : i == 3 ? "Public Safety Union" : "Incumbent's Office";
                    float share = s_PollSupport[i];
                    rows.Add($"{i}|{s_CandidateNames[i]}|{s_Parties[i]}|{s_Colors[i]}|{share.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)}|{(i == 4 ? 54 : Math.Max(31, 49 - i * 4))}|{s_CampaignFunds[i]}|{s_Promises[i]}|{endorsement}|{s_LastVotes[i]}");
                }
                return string.Join("\n", rows);
            }
        }

        public static string ResultRows
        {
            get
            {
                RecalculatePoll();
                var rows = new List<string>(s_CandidateNames.Length);
                for (int i = 0; i < s_CandidateNames.Length; i++)
                {
                    float share = s_HasElectionRun ? s_LastShare[i] : s_PollSupport[i];
                    int votes = s_HasElectionRun ? s_LastVotes[i] : (int)Math.Round(s_RegisteredVoters * (s_LastTurnout > 0 ? s_LastTurnout : 62) / 100d * share / 100d);
                    rows.Add($"{i}|{s_CandidateNames[i]}|{s_Parties[i]}|{s_Colors[i]}|{share.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)}|{votes}");
                }
                return string.Join("\n", rows);
            }
        }

        public static string StatusAt(uint frame)
        {
            if (s_NextElectionFrame == 0) s_NextElectionFrame = frame + AnnualElectionFrames;
            if (s_HasElectionRun) return $"Last result: {s_ElectionStatus} · Next annual election in {(frame < s_NextElectionFrame ? (s_NextElectionFrame - frame) / OutingStarter.FramesPerDay : 0u)} in-game days.";
            uint days = frame < s_NextElectionFrame ? (s_NextElectionFrame - frame) / OutingStarter.FramesPerDay : 0u;
            return $"First annual city election in {days} in-game days · special election can be called at any time.";
        }

        public static string CouncilMembers
        {
            get
            {
                string[] colors = { "#3d7bff", "#ff4f5e", "#3fd68d", "#d9a741" };
                var rows = new List<string>(10);
                for (int i = 0; i < s_SeatName.Length; i++)
                {
                    bool vacant = s_SeatParty[i] == "Vacant";
                    rows.Add($"{i}|{(vacant ? "Vacant seat" : s_SeatName[i])}|{s_SeatParty[i]}|{s_SeatWard[i]}|{(vacant ? "#78698b" : colors[PartyIndex(s_SeatParty[i])])}|{(vacant ? 0 : s_SeatApproval[i])}|{(PartyIndex(s_SeatParty[i]) == s_MayorParty && !vacant ? 1 : 0)}");
                }
                return string.Join("\n", rows);
            }
        }

        public static string LastCouncilResult => s_LastCouncilResult;
        public static string MayorParty => s_PartyNames[s_MayorParty];

        public static int FilledCouncilSeats { get { int n = 0; foreach (string p in s_SeatParty) if (p != "Vacant") n++; return n; } }
        public static int CouncilTotalSeats => 10;

        public static void RunPoll(uint frame)
        {
            RecalculatePoll();
            s_PollCount++;
            CityBuzzFeed.Add("Election poll released", "Election desk", "Citywide",
                $"Poll {s_PollCount}: {s_CandidateNames[LeadingCandidate()]} leads the modeled mayoral race at {s_PollSupport[LeadingCandidate()]:0.0}%. Registered voter base: {s_RegisteredVoters:N0}.", frame);
            s_ElectionStatus = $"Latest city poll published · {s_CandidateNames[LeadingCandidate()]} leads at {s_PollSupport[LeadingCandidate()]:0.0}% · {s_RegisteredVoters:N0} registered voters.";
        }

        public static void StartDebate(uint frame)
        {
            int candidate = s_DebateCount % s_CandidateNames.Length;
            s_DebateCount++;
            s_CampaignShift[candidate] += 1.25f;
            for (int i = 0; i < s_CampaignShift.Length; i++) if (i != candidate) s_CampaignShift[i] -= 0.25f;
            RecalculatePoll();
            CityBuzzFeed.Add("Mayoral debate", "Election desk", "City Hall",
                $"Candidates debated housing, public safety, nightlife, transport, and city services. {s_CandidateNames[candidate]} gained a small modeled polling bump after the forum.", frame);
            s_ElectionStatus = $"Debate {s_DebateCount} complete · {s_CandidateNames[candidate]} gained 1.3 polling points; polling recalculated.";
            PublicReactionLedger.Add("Mayoral candidates debated city policy", -1);
        }

        public static string Rows
        {
            get
            {
                var rows = new List<string>(s_Policies.Length);
                for (int i = 0; i < s_Policies.Length; i++)
                {
                    Policy p = s_Policies[i];
                    if (p.Status == "Vote pending")
                    {
                        p.Votes = RollCall(i, p, out int fy, out int fn);
                        p.Yes = fy; p.No = fn;
                    }
                    string shown = IsLocked(p) ? "Locked" : p.Status;
                    rows.Add($"{i}|{p.Name}|{p.Category}|{shown}|{p.Description}|{p.Effects}|{p.Cost}|{p.Yes}|{p.No}|{p.Votes}|{p.MayorLean}|{p.Pros}|{p.Cons}|{string.Join(",", p.Stance)}|{p.CrimeOffset}|{p.MonthlyBudget}|{p.Mood}|{p.MinPopulation}");
                }
                return string.Join("\n", rows);
            }
        }

        public static void Act(int index, int action, uint frame)
        {
            if (index < 0 || index >= s_Policies.Length) return;
            Policy p = s_Policies[index];
            switch (action)
            {
                case 0: // Propose / reintroduce
                    if (IsLocked(p)) return;
                    p.Status = "Vote pending"; p.MayorLean = 0;
                    p.Votes = RollCall(index, p, out p.Yes, out p.No);
                    CityBuzzFeed.Add("Ordinance proposed", "City Council", p.Name, $"Council opened debate on {p.Name}. Early whip count: {p.Yes} for, {p.No} against.", frame);
                    break;
                case 1: // Council vote
                    if (p.Status != "Vote pending") return;
                    p.Votes = RollCall(index, p, out p.Yes, out p.No);
                    p.Status = p.Yes > p.No ? "Active" : "Available";
                    if (p.Status == "Active" && p.Mood != 0)
                    {
                        // Popular laws (calming) lift the parties that backed them; unpopular ones hurt them.
                        int popularity = p.Mood < 0 ? 1 : -1;
                        for (int c = 0; c < s_Parties.Length; c++) s_CampaignShift[c] += 0.25f * p.Stance[PartyIndex(s_Parties[c])] * popularity;
                        RecalculatePoll();
                    }
                    CityBuzzFeed.Add(p.Status == "Active" ? "Ordinance passed" : "Ordinance rejected", "City Council", p.Name,
                        p.Status == "Active" ? $"Council passed {p.Name} {p.Yes}-{p.No} along party lines; its city effects are now in force." : $"Council rejected {p.Name} {p.Yes}-{p.No}; it remains available for a future vote.", frame);
                    PublicReactionLedger.Add(p.Status == "Active" ? $"Council passed {p.Name}" : $"Council rejected {p.Name}", p.Status == "Active" ? p.Mood - 1 : 1);
                    break;
                case 2: // Sign by decree
                    if (IsLocked(p)) return;
                    p.Status = "Active";
                    CityBuzzFeed.Add("Ordinance signed", "Mayor's office", p.Name, $"The mayor signed {p.Name} into the modeled city policy book.", frame);
                    PublicReactionLedger.Add($"Mayor signed {p.Name} without a council vote", p.Mood + 2);
                    break;
                case 3: // Withdraw / repeal
                    if (IsLocked(p)) return;
                    bool wasActive = p.Status == "Active";
                    p.Status = "Available"; p.Yes = 0; p.No = 0; p.Votes = ""; p.MayorLean = 0;
                    CityBuzzFeed.Add(wasActive ? "Ordinance repealed" : "Ordinance withdrawn", "City Council", p.Name, $"{p.Name} is no longer in force.", frame);
                    PublicReactionLedger.Add($"{p.Name} withdrawn", 1);
                    break;
                case 4: // Mayor lobbies swing members to vote yes
                    if (p.Status != "Vote pending") return;
                    p.MayorLean = p.MayorLean == 1 ? 0 : 1;
                    p.Votes = RollCall(index, p, out p.Yes, out p.No);
                    break;
                case 5: // Mayor lobbies swing members to vote no
                    if (p.Status != "Vote pending") return;
                    p.MayorLean = p.MayorLean == -1 ? 0 : -1;
                    p.Votes = RollCall(index, p, out p.Yes, out p.No);
                    break;
            }
        }

        public static void RunElection(uint frame) => RunElection(frame, false);

        private static void RunElection(uint frame, bool annual)
        {
            s_ElectionNumber++;
            RecalculatePoll();
            int turnout = Math.Max(35, Math.Min(90, 62 + PublicReactionLedger.Anger / 5 + (s_ElectionNumber % 5) - 2));
            s_LastTurnout = turnout;
            s_LastTotalVotes = (int)Math.Round(s_RegisteredVoters * turnout / 100d);
            int winner = 0;
            int assigned = 0;
            for (int i = 0; i < s_CandidateNames.Length; i++)
            {
                s_LastShare[i] = s_PollSupport[i];
                s_LastVotes[i] = (int)Math.Round(s_LastTotalVotes * s_LastShare[i] / 100d);
                assigned += s_LastVotes[i];
                if (s_LastVotes[i] > s_LastVotes[winner]) winner = i;
            }
            s_LastVotes[winner] += s_LastTotalVotes - assigned;
            s_Mayor = "Mayor " + s_CandidateNames[winner];
            s_MayorParty = PartyIndex(s_Parties[winner]);
            s_HasElectionRun = true;
            s_NextElectionFrame = frame + AnnualElectionFrames;
            s_ElectionStatus = $"{(annual ? "Annual election" : "Special election")} {s_ElectionNumber} certified · {turnout}% turnout · {s_Mayor} elected with {s_LastShare[winner]:0.0}% of votes.";
            CityBuzzFeed.Add("City election · results certified", "Election desk", "Citywide",
                $"{s_ElectionStatus} {s_LastTotalVotes:N0} ballots counted from {s_RegisteredVoters:N0} registered voters.", frame);
            PublicReactionLedger.Add("City election held", -4);
            CouncilElection(frame);
            s_CampaignShift[winner] += 1f;
            RecalculatePoll();
        }

        private static void RecalculatePoll()
        {
            float anger = PublicReactionLedger.Anger;
            float[] raw = new float[s_BaseSupport.Length];
            float sum = 0f;
            for (int i = 0; i < raw.Length; i++)
            {
                float mood = (i == 0 ? 0.01f : i == 1 ? -0.015f : i == 2 ? -0.005f : i == 3 ? 0.012f : 0f) * (anger - 40f);
                float policy = i == 0 && s_Policies[0].Status == "Active" ? 1.4f
                    : i == 2 && s_Policies[4].Status == "Active" ? 1.1f
                    : i == 1 && s_Policies[5].Status == "Active" ? 1.3f
                    : i == 4 && s_Policies[3].Status == "Active" ? 1.1f : 0f;
                raw[i] = Math.Max(1f, s_BaseSupport[i] + mood + policy + s_CampaignShift[i]);
                sum += raw[i];
            }
            for (int i = 0; i < raw.Length; i++) s_PollSupport[i] = raw[i] * 100f / sum;
        }

        private static int LeadingCandidate()
        {
            int leader = 0;
            for (int i = 1; i < s_PollSupport.Length; i++) if (s_PollSupport[i] > s_PollSupport[leader]) leader = i;
            return leader;
        }

        // Active public-safety policies modestly alter the mod's incident model.
        public static int ViolentCrimeChanceOffset
        {
            get
            {
                int offset = 0;
                foreach (Policy p in s_Policies) if (p.Status == "Active") offset += p.CrimeOffset;
                return Math.Max(-12, Math.Min(12, offset));
            }
        }
    }
}
