using Colossal.UI.Binding;
using Game;
using Game.Tools;
using Game.UI;

namespace BarRush
{
    public static class ShutDownRoadState
    {
        public static string Status { get; private set; } = "Choose Shut Down Road, then click a road segment.";
        private static float s_VisibleUntil;
        public static bool Visible => UnityEngine.Time.realtimeSinceStartup < s_VisibleUntil;
        public static void SetStatus(string status)
        {
            Status = status;
            s_VisibleUntil = UnityEngine.Time.realtimeSinceStartup + 8f;
        }
    }

    public partial class ShutDownRoadUISystem : UISystemBase
    {
        private const string kGroup = "BarRush";
        private ToolSystem m_ToolSystem;
        private ShutDownRoadToolSystem m_RoadTool;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_ToolSystem = World.GetOrCreateSystemManaged<ToolSystem>();
            m_RoadTool = World.GetOrCreateSystemManaged<ShutDownRoadToolSystem>();
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "roadUpgradeActive", IsRoadUpgradeActive));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "shutDownRoadActive", () => m_ToolSystem.activeTool == m_RoadTool));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "roadClosuresEnabled", () => Mod.Settings != null && Mod.Settings.Enabled && Mod.Settings.RoadClosuresEnabled));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "shutDownRoadStatus", () => ShutDownRoadState.Status));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "shutDownRoadStatusVisible", () => ShutDownRoadState.Visible));
            AddBinding(new TriggerBinding(kGroup, "activateShutDownRoad", ActivateTool));
            AddBinding(new TriggerBinding(kGroup, "cancelShutDownRoad", CancelTool));
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 16;

        private bool IsRoadUpgradeActive()
        {
            return m_ToolSystem.activeTool == m_RoadTool
                || m_ToolSystem.activeTool is NetToolSystem;
        }

        private void ActivateTool()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.RoadClosuresEnabled) return;
            // Never install a prefab-less tool as the active tool: the game's
            // toolbar dereferences activePrefab while updating and throws a
            // NullReferenceException before the player can click a road.
            if (m_RoadTool == null || !m_RoadTool.IsReady)
            {
                ShutDownRoadState.SetStatus("Road tool could not load a network prefab. Please reload the city and try again.");
                return;
            }
            m_ToolSystem.activeTool = m_RoadTool;
            ShutDownRoadState.SetStatus("Click a road to close it to vehicle routes and request police. Click it again to reopen. Press Esc to cancel.");
        }

        private void CancelTool()
        {
            if (m_ToolSystem.activeTool == m_RoadTool) m_ToolSystem.activeTool = null;
            ShutDownRoadState.SetStatus("Road shutdown tool closed.");
        }
    }
}
