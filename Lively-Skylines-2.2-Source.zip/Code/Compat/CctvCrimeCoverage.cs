using System.Collections.Generic;
using Game.Common;
using Game.Objects;
using Game.Prefabs;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Reduces Lively Skylines' modeled crime odds near placed mobile CCTV props.</summary>
    public static class CctvCrimeCoverage
    {
        private const float kCoverageRadius = 180f;
        private static readonly HashSet<Entity> s_CoveredPrefabs = new HashSet<Entity>();
        private static readonly HashSet<Entity> s_AlprPrefabs = new HashSet<Entity>();

        public static void RegisterCameraPrefab(Entity prefabEntity)
        {
            if (prefabEntity != Entity.Null) s_CoveredPrefabs.Add(prefabEntity);
        }

        public static void RegisterAlprPrefab(Entity prefabEntity)
        {
            if (prefabEntity != Entity.Null) s_AlprPrefabs.Add(prefabEntity);
        }

        public static List<float3> GetAlprPositions(EntityManager entityManager)
        {
            var positions = new List<float3>();
            if (entityManager == null || s_AlprPrefabs.Count == 0) return positions;
            EntityQuery query = entityManager.CreateEntityQuery(
                ComponentType.ReadOnly<PrefabRef>(), ComponentType.ReadOnly<Transform>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<PrefabData>());
            try
            {
                using NativeArray<Entity> objects = query.ToEntityArray(Allocator.Temp);
                foreach (Entity instance in objects)
                {
                    PrefabRef prefabRef = entityManager.GetComponentData<PrefabRef>(instance);
                    if (!s_AlprPrefabs.Contains(prefabRef.m_Prefab)) continue;
                    positions.Add(entityManager.GetComponentData<Transform>(instance).m_Position);
                }
            }
            finally { query.Dispose(); }
            return positions;
        }

        public static bool Covers(EntityManager entityManager, float3 position)
        {
            if (entityManager == null) return false;
            return Covers(position, GetCameraPositions(entityManager));
        }

        public static List<float3> GetCameraPositions(EntityManager entityManager)
        {
            var positions = new List<float3>();
            if (entityManager == null || s_CoveredPrefabs.Count == 0) return positions;
            EntityQuery query = entityManager.CreateEntityQuery(
                ComponentType.ReadOnly<PrefabRef>(), ComponentType.ReadOnly<Transform>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<PrefabData>());
            try
            {
                using NativeArray<Entity> objects = query.ToEntityArray(Allocator.Temp);
                foreach (Entity instance in objects)
                {
                    PrefabRef prefabRef = entityManager.GetComponentData<PrefabRef>(instance);
                    if (!s_CoveredPrefabs.Contains(prefabRef.m_Prefab)) continue;
                    positions.Add(entityManager.GetComponentData<Transform>(instance).m_Position);
                }
            }
            finally { query.Dispose(); }
            return positions;
        }

        public static bool Covers(float3 position, List<float3> cameraPositions)
        {
            if (cameraPositions == null || cameraPositions.Count == 0) return false;
            float radiusSq = kCoverageRadius * kCoverageRadius;
            foreach (float3 cameraPosition in cameraPositions)
                if (math.distancesq(new float2(cameraPosition.x, cameraPosition.z),
                    new float2(position.x, position.z)) <= radiusSq) return true;
            return false;
        }
    }
}
