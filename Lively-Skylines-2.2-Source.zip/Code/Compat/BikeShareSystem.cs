using System.Collections.Generic;
using Colossal.UI.Binding;
using Game;
using Game.Citizens;
using Game.City;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    public enum BikeShareInvestment
    {
        Launch,
        Expand,
        Citywide,
        EBikes,
        ToggleRebalancing,
        SetFare,
    }

    public static class BikeShareQueue
    {
        private static readonly Queue<BikeShareInvestment> s_Queue = new Queue<BikeShareInvestment>();
        public static string Status { get; private set; } = "Invest to launch a public bike-share network.";
        public static void Enqueue(BikeShareInvestment investment) => s_Queue.Enqueue(investment);
        public static bool TryDequeue(out BikeShareInvestment investment)
        {
            if (s_Queue.Count > 0) { investment = s_Queue.Dequeue(); return true; }
            investment = default;
            return false;
        }
        public static void SetStatus(string status) => Status = status;
        public static int PendingFare = 4;
    }

    public static class BikeShareLedger
    {
        private struct RideRecord { public int Count; public uint EndFrame; }
        public sealed class Station
        {
            public string Name;
            public string Area;
            public float3 Position;
            public int Capacity;
            public Entity Building;
            public int Rides;
        }

        // ---- Operations & money -------------------------------------------------------------
        public static int Fare { get; private set; } = 4;
        public static bool EBikes { get; private set; }
        public static bool Rebalancing { get; private set; }
        public static int Members { get; private set; }
        public static int BikesLost { get; private set; }
        public static long FareRevenueTotal { get; private set; }
        public static long CostsTotal { get; private set; }
        public static long LastMonthNet { get; private set; }
        private static long s_FaresThisMonth;
        private static uint s_LastMonthFrame, s_LastDayFrame;

        public static void SetFare(int fare) => Fare = math.clamp(fare, 0, 6);
        public static void UpgradeEBikes() => EBikes = true;
        public static void ToggleRebalancing() => Rebalancing = !Rebalancing;

        public static float DemandMultiplier
        {
            get
            {
                float fare = Fare <= 0 ? 1.6f : Fare <= 2 ? 1.25f : Fare <= 4 ? 1f : 0.7f;
                return fare * (EBikes ? 1.35f : 1f) * (Rebalancing ? 1.15f : 1f);
            }
        }

        public static int Availability => !Launched ? 0 : Rebalancing ? 95 : 70;
        public static long MonthlyMaintenance => (long)Fleet * (EBikes ? 18 : 12) + (Rebalancing ? 8000 : 0);
        public static long MonthlyMembership => (long)Members * 15;
        public static long EstimatedMonthlyNet => s_FaresThisMonth + MonthlyMembership - MonthlyMaintenance;

        /// <summary>Daily theft/vandalism. Higher crime and turf wars cost more bikes; rebalancing crews recover some.</summary>
        public static void DailyLosses(uint frame, ref Random random, int crimePressure)
        {
            if (!Launched) return;
            if (s_LastDayFrame == 0 || frame < s_LastDayFrame) { s_LastDayFrame = frame; return; }
            if (frame - s_LastDayFrame < OutingStarter.FramesPerDay) return;
            s_LastDayFrame = frame;
            int chance = 6 + crimePressure * 3 - (Rebalancing ? 4 : 0);
            if (random.NextInt(100) < math.max(1, chance))
            {
                int lost = math.max(1, Fleet / 120 + random.NextInt(0, 3));
                Fleet = math.max(0, Fleet - lost);
                BikesLost += lost;
                CityBuzzFeed.Add("Bike share", "City transport", "Citywide", $"{lost} shared bike(s) were stolen or vandalized overnight. {Fleet} bikes remain in service.", frame);
            }
        }

        /// <summary>Returns the bike-share net (+ income, - cost) due once every 30 in-game days.</summary>
        public static long TakeMonthly(uint frame)
        {
            if (!Launched) { s_LastMonthFrame = frame; return 0; }
            if (s_LastMonthFrame == 0 || frame < s_LastMonthFrame) { s_LastMonthFrame = frame; return 0; }
            if (frame - s_LastMonthFrame < OutingStarter.FramesPerDay * 30u) return 0;
            s_LastMonthFrame = frame;
            long income = s_FaresThisMonth + MonthlyMembership;
            long cost = MonthlyMaintenance;
            FareRevenueTotal += income; CostsTotal += cost;
            s_FaresThisMonth = 0;
            LastMonthNet = income - cost;
            Members = math.max(0, (int)(Members * 0.92f)); // some members cancel each month
            return LastMonthNet;
        }

        private static readonly List<Station> s_Stations = new List<Station>();
        private static readonly List<RideRecord> s_ActiveTrips = new List<RideRecord>();
        public static int Fleet { get; private set; }
        public static int Rides { get; private set; }
        public static int ActiveRiders { get; private set; }
        public static uint LastRideFrame { get; private set; }
        public static bool Launched => Fleet > 0;
        public static IReadOnlyList<Station> Stations => s_Stations;

        public static void Launch(List<Station> stations, int bikes)
        {
            s_Stations.Clear();
            s_Stations.AddRange(stations);
            Fleet = bikes;
        }

        public static void Expand(List<Station> stations, int bikes)
        {
            foreach (Station station in stations)
            {
                if (s_Stations.Count >= 30) break;
                bool duplicate = false;
                foreach (Station existing in s_Stations)
                    if (math.distance(existing.Position, station.Position) < 250f) { duplicate = true; break; }
                if (!duplicate) s_Stations.Add(station);
            }
            Fleet += bikes;
        }

        public static void RecordRide(int riders, uint frame, uint duration, Station station = null)
        {
            Rides += riders;
            if (station != null) station.Rides += riders;
            s_FaresThisMonth += (long)riders * Fare;
            if (riders > 0) Members += math.max(0, riders / (Fare <= 0 ? 40 : 15));
            LastRideFrame = frame;
            if (riders > 0) s_ActiveTrips.Add(new RideRecord { Count = riders, EndFrame = frame + duration });
        }

        public static void UpdateActive(uint frame)
        {
            s_ActiveTrips.RemoveAll(ride => ride.EndFrame <= frame);
            int active = 0;
            foreach (RideRecord ride in s_ActiveTrips) active += ride.Count;
            ActiveRiders = math.min(Fleet, active);
        }

        public static string StationsText
        {
            get
            {
                var lines = new List<string>(s_Stations.Count);
                for (int i = 0; i < s_Stations.Count; i++)
                {
                    Station s = s_Stations[i];
                    lines.Add($"{i}|{s.Name}|{s.Area}|{s.Capacity}|{s.Position.x:0.##}|{s.Position.z:0.##}|{s.Rides}");
                }
                return string.Join("\n", lines);
            }
        }

        public static void AppendMapRows(System.Text.StringBuilder rows)
        {
            foreach (Station station in s_Stations)
                rows.Append("Q|").Append(station.Position.x.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture)).Append('|')
                    .Append(station.Position.z.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture)).Append('|')
                    .Append(station.Name.Replace('|', ' ')).Append('|').Append(station.Area.Replace('|', ' ')).Append('|').Append(station.Capacity).AppendLine();
        }
    }

    /// <summary>Funded city bike-share network: city-funded stations and resident outings.</summary>
    public partial class BikeShareSystem : GameSystemBase
    {
        public const int kLaunchCost = 100000;
        public const int kExpandCost = 250000;
        public const int kCitywideCost = 750000;
        public const int kEBikeCost = 150000;
        private const uint kRideInterval = 3600;
        private CitySystem m_CitySystem;
        private SimulationSystem m_SimulationSystem;
        private NameSystem m_NameSystem;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;
        private EntityQuery m_BuildingQuery;
        private uint m_NextRideFrame;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CandidateQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_BuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Buildings.Building>(), ComponentType.ReadOnly<Game.Objects.Transform>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 128;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.BikeShareEnabled)
            {
                while (BikeShareQueue.TryDequeue(out _)) { }
                return;
            }

            while (BikeShareQueue.TryDequeue(out BikeShareInvestment investment)) ApplyInvestment(investment);
            uint frame = m_SimulationSystem.frameIndex;
            BikeShareLedger.UpdateActive(frame);
            var lossRandom = new Random(math.max(1u, frame * 1664525u + 1013904223u));
            BikeShareLedger.DailyLosses(frame, ref lossRandom, GangEconomyLedger.ViolenceOffset / 2);
            long net = BikeShareLedger.TakeMonthly(frame);
            if (net != 0)
            {
                Entity cityEntity = m_CitySystem.City;
                if (cityEntity != Entity.Null && EntityManager.Exists(cityEntity) && EntityManager.HasComponent<PlayerMoney>(cityEntity))
                {
                    PlayerMoney cash = EntityManager.GetComponentData<PlayerMoney>(cityEntity);
                    if (!cash.m_Unlimited)
                    {
                        int amount = (int)math.clamp(net, -int.MaxValue, int.MaxValue);
                        if (amount > 0) cash.Add(amount); else cash.Subtract(-amount);
                        EntityManager.SetComponentData(cityEntity, cash);
                    }
                }
                CityBuzzFeed.Add("Bike share", "City finance", "Citywide", net > 0 ? $"Bike share earned the city ${net:N0} this month after maintenance." : $"Bike share cost the city ${-net:N0} this month after fares and memberships.", frame);
            }
            if (!BikeShareLedger.Launched || frame < m_NextRideFrame) return;
            m_NextRideFrame = frame + kRideInterval;
            StartResidentTrips(frame);
        }

        private void ApplyInvestment(BikeShareInvestment investment)
        {
            uint frame = m_SimulationSystem.frameIndex;
            if (investment == BikeShareInvestment.SetFare)
            {
                BikeShareLedger.SetFare(BikeShareQueue.PendingFare);
                BikeShareQueue.SetStatus(BikeShareLedger.Fare == 0 ? "Rides are now free: ridership jumps, but the system earns only from memberships." : $"Fare set to ${BikeShareLedger.Fare} per ride.");
                return;
            }
            if (investment == BikeShareInvestment.ToggleRebalancing)
            {
                if (!BikeShareLedger.Launched) { BikeShareQueue.SetStatus("Launch the network first."); return; }
                BikeShareLedger.ToggleRebalancing();
                BikeShareQueue.SetStatus(BikeShareLedger.Rebalancing ? "Rebalancing crews hired: $8,000 a month keeps bikes where riders need them and cuts theft." : "Rebalancing crews released: availability drops and theft rises.");
                return;
            }
            int cost = investment == BikeShareInvestment.Launch ? kLaunchCost : investment == BikeShareInvestment.Expand ? kExpandCost : investment == BikeShareInvestment.EBikes ? kEBikeCost : kCitywideCost;
            if (investment == BikeShareInvestment.EBikes && (!BikeShareLedger.Launched || BikeShareLedger.EBikes))
            {
                BikeShareQueue.SetStatus(BikeShareLedger.EBikes ? "The fleet is already electric." : "Launch the network first."); return;
            }
            if (investment == BikeShareInvestment.Launch && BikeShareLedger.Launched)
            {
                BikeShareQueue.SetStatus("The bike-share network is already running. Expand it to add more stations and bikes."); return;
            }
            if (investment != BikeShareInvestment.Launch && !BikeShareLedger.Launched)
            {
                BikeShareQueue.SetStatus("Launch the network before purchasing an expansion."); return;
            }
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city))
            {
                BikeShareQueue.SetStatus("City funds are not available right now."); return;
            }
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            if (!money.m_Unlimited && money.money < cost)
            {
                BikeShareQueue.SetStatus($"Not enough city funds. This investment costs ${cost:N0}."); return;
            }

            if (investment == BikeShareInvestment.EBikes)
            {
                if (!money.m_Unlimited) { money.Subtract(cost); EntityManager.SetComponentData(city, money); }
                BikeShareLedger.UpgradeEBikes();
                BikeShareQueue.SetStatus($"Fleet upgraded to e-bikes for ${cost:N0}: about 35% more riders, higher upkeep per bike.");
                CityBuzzFeed.Add("Bike share", "City transport", "Citywide", "The city bike-share fleet switched to electric bikes. Longer trips and hills are now easy for riders.", frame);
                return;
            }
            List<BikeShareLedger.Station> stations = ChooseStations(investment == BikeShareInvestment.Launch ? 8 : investment == BikeShareInvestment.Expand ? 10 : 20);
            if (stations.Count == 0) { BikeShareQueue.SetStatus("No city buildings were available for bike stations. Try again after the city loads."); return; }
            if (!money.m_Unlimited)
            {
                money.Subtract(cost);
                EntityManager.SetComponentData(city, money);
            }
            int bikes = investment == BikeShareInvestment.Launch ? 80 : investment == BikeShareInvestment.Expand ? 120 : 300;
            if (investment == BikeShareInvestment.Launch) BikeShareLedger.Launch(stations, bikes);
            else BikeShareLedger.Expand(stations, bikes);
            string level = investment == BikeShareInvestment.Launch ? "launched" : investment == BikeShareInvestment.Expand ? "expanded" : "expanded citywide";
            BikeShareQueue.SetStatus($"Bike share {level}: {BikeShareLedger.Stations.Count} stations, {BikeShareLedger.Fleet} bikes. Investment: ${cost:N0}.");
            CityBuzzFeed.Add("Bike share", "City transport", "Citywide", $"The city bike-share network {level} with {BikeShareLedger.Fleet} bikes at {BikeShareLedger.Stations.Count} stations.", frame);
        }

        private List<BikeShareLedger.Station> ChooseStations(int wanted)
        {
            var buildings = new List<(Entity entity, float3 position, string name)>();
            using NativeArray<Entity> entities = m_BuildingQuery.ToEntityArray(Allocator.Temp);
            int stride = entities.Length > 15000 ? (entities.Length + 14999) / 15000 : 1;
            for (int i = 0; i < entities.Length; i += stride)
            {
                Entity entity = entities[i];
                if (!EntityManager.Exists(entity)) continue;
                float3 pos = EntityManager.GetComponentData<Game.Objects.Transform>(entity).m_Position;
                string name = m_NameSystem.GetRenderedLabelName(entity);
                if (string.IsNullOrWhiteSpace(name)) name = "Neighborhood station";
                buildings.Add((entity, pos, name.Replace('|', ' ').Replace('\n', ' ')));
            }
            if (buildings.Count == 0) return new List<BikeShareLedger.Station>();
            var chosen = new List<BikeShareLedger.Station>(math.min(wanted, buildings.Count));
            uint seed = math.max(1u, m_SimulationSystem.frameIndex ^ (uint)buildings.Count * 2654435761u);
            var random = new Random(seed);
            int spacing = math.max(1, buildings.Count / math.max(1, wanted));
            int offset = random.NextInt(0, math.max(1, spacing));
            var used = new HashSet<int>();
            for (int n = 0; n < wanted && chosen.Count < buildings.Count; n++)
            {
                int idx = (offset + n * spacing) % buildings.Count;
                while (used.Contains(idx)) idx = (idx + 1) % buildings.Count;
                used.Add(idx);
                var candidate = buildings[idx];
                chosen.Add(new BikeShareLedger.Station { Building = candidate.entity, Position = candidate.position, Name = $"{candidate.name} Bike Hub", Area = DistrictOf(candidate.entity), Capacity = investmentCapacity(n) });
            }
            return chosen;
        }

        private string DistrictOf(Entity building)
        {
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
            return string.IsNullOrWhiteSpace(area) ? "City district" : area.Replace('|', ' ');
        }

        private static int investmentCapacity(int index) => index % 2 == 0 ? 12 : 16;

        private void StartResidentTrips(uint frame)
        {
            using NativeArray<Entity> candidates = m_CandidateQuery.ToEntityArray(Allocator.Temp);
            int population = m_PopulationQuery.CalculateEntityCount();
            if (candidates.Length == 0 || population == 0) return;
            var random = new Random(math.max(1u, frame ^ (uint)BikeShareLedger.Rides * 2246822519u));
            int cap = PopulationCap.MaxAttendees(population, Mod.Settings.MaxAttendancePercent);
            int bikesAvailable = math.max(0, BikeShareLedger.Fleet - BikeShareLedger.ActiveRiders);
            bikesAvailable = bikesAvailable * BikeShareLedger.Availability / 100;
            int maxRiders = math.min(math.min(bikesAvailable, math.max(1, (int)(BikeShareLedger.Fleet / 12 * BikeShareLedger.DemandMultiplier))), math.max(1, (int)(population / 100 * BikeShareLedger.DemandMultiplier)));
            int desired = AttendanceLedger.Remaining(cap, frame);
            desired = math.min(maxRiders, desired);
            if (desired <= 0) return;
            uint duration = math.max(1u, OutingStarter.FramesPerDay / 18u);
            BikeShareLedger.Station station = BikeShareLedger.Stations[random.NextInt(0, BikeShareLedger.Stations.Count)];
            Entity stationBuilding = station.Building != Entity.Null && EntityManager.Exists(station.Building) ? station.Building : Entity.Null;
            int started = OutingStarter.Start(EntityManager, candidates, desired, ref random, frame, duration, stationBuilding);
            if (started <= 0) return;
            AttendanceLedger.Add(started, frame + duration);
            BikeShareLedger.RecordRide(started, frame, duration, station);
            BikeShareLedger.UpdateActive(frame);
            CityBuzzFeed.Add("Bike share", "City transport", station.Name, $"{started:N0} residents checked out shared bikes for local trips. {math.max(0, BikeShareLedger.Fleet - BikeShareLedger.ActiveRiders):N0} bikes remain available across the network.", frame);
            Mod.log.Info($"Bike share started {started} resident trips from a {BikeShareLedger.Fleet}-bike fleet, routed toward {station.Name}.");
        }
    }

    public partial class BikeShareUISystem : UISystemBase
    {
        private const string kGroup = "BarRush";
        protected override void OnCreate()
        {
            base.OnCreate();
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "bikeShareEnabled", () => Mod.Settings != null && Mod.Settings.Enabled && Mod.Settings.BikeShareEnabled));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "bikeShareFleet", () => BikeShareLedger.Fleet));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "bikeShareRides", () => BikeShareLedger.Rides));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "bikeShareActiveRiders", () => BikeShareLedger.ActiveRiders));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "bikeShareStationsCount", () => BikeShareLedger.Stations.Count));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bikeShareStations", () => BikeShareLedger.StationsText));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bikeShareStatus", () => BikeShareQueue.Status));
            AddBinding(new TriggerBinding<int>(kGroup, "investBikeShare", level => BikeShareQueue.Enqueue((BikeShareInvestment)math.clamp(level, 0, 4))));
            AddBinding(new TriggerBinding<int>(kGroup, "setBikeShareFare", fare => { BikeShareQueue.PendingFare = fare; BikeShareQueue.Enqueue(BikeShareInvestment.SetFare); }));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "bikeShareDetails", () =>
                $"{BikeShareLedger.Fare}|{(BikeShareLedger.EBikes ? 1 : 0)}|{(BikeShareLedger.Rebalancing ? 1 : 0)}|{BikeShareLedger.Members}|{BikeShareLedger.BikesLost}|{BikeShareLedger.FareRevenueTotal}|{BikeShareLedger.CostsTotal}|{BikeShareLedger.LastMonthNet}|{BikeShareLedger.EstimatedMonthlyNet}|{BikeShareLedger.Availability}|{BikeShareLedger.MonthlyMaintenance}|{BikeShareLedger.MonthlyMembership}|{BikeShareLedger.DemandMultiplier.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture)}"));
        }
        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;
        protected override void OnUpdate() => base.OnUpdate();
    }
}
