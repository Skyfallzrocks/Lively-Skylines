using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace BarRush
{
    /// <summary>Approximate session map locations for unhoused-resident encampments.</summary>
    public static class HomelessEncampmentLedger
    {
        public sealed class Encampment
        {
            public float X;
            public float Z;
            public string Place;
            public string Area;
            public int Residents;
        }

        private static readonly List<Encampment> s_Entries = new List<Encampment>();
        private static bool s_HasFrame;
        private static uint s_LastFrame;

        public static void Replace(List<Encampment> entries, uint frame)
        {
            SyncFrame(frame);
            s_Entries.Clear();
            s_Entries.AddRange(entries);
        }

        public static void Clear(uint frame)
        {
            SyncFrame(frame);
            s_Entries.Clear();
        }

        public static List<Encampment> CopyEntries(uint frame)
        {
            SyncFrame(frame);
            var copy = new List<Encampment>(s_Entries.Count);
            foreach (Encampment entry in s_Entries)
                copy.Add(new Encampment { X = entry.X, Z = entry.Z, Place = entry.Place, Area = entry.Area, Residents = entry.Residents });
            return copy;
        }

        public static void AppendMapRows(StringBuilder rows, uint frame)
        {
            SyncFrame(frame);
            foreach (Encampment entry in s_Entries)
            {
                rows.Append("H|").Append(entry.X.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(entry.Z.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(Clean(entry.Place)).Append('|').Append(Clean(entry.Area)).Append('|').Append(entry.Residents).AppendLine();
            }
        }

        private static void SyncFrame(uint frame)
        {
            if (s_HasFrame && frame < s_LastFrame) s_Entries.Clear();
            s_HasFrame = true;
            s_LastFrame = frame;
        }

        private static string Clean(string value) => (value ?? string.Empty).Replace('|', '/').Replace('\r', ' ').Replace('\n', ' ').Trim();
    }
}
