using System.Collections.Generic;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Small, newest-first city activity log shared by the UI and simulation systems.</summary>
    public static class CityBuzzFeed
    {
        private struct Item
        {
            public string Kind;
            public string Author;
            public string Place;
            public string Message;
            public uint Frame;
            public int Likes;
            public int Dislikes;
            public int Going;
            public int Skipping;
            public Entity CrimeIncident;
            public bool Hidden;
            public string ImageKind;
        }

        private const int kMaxItems = 100;
        private static readonly List<Item> s_Items = new List<Item>();

        public static string Text
        {
            get
            {
                var lines = new List<string>(s_Items.Count);
                foreach (Item item in s_Items)
                {
                    if (item.Hidden) continue;
                    lines.Add($"{item.Kind}|{item.Author}|{item.Place}|{item.Message}|{item.Frame}|{item.Likes}|{item.Dislikes}|{item.Going}|{item.Skipping}|{item.ImageKind}");
                }
                return string.Join("\n", lines);
            }
        }

        public static void Add(string kind, string author, string place, string message, uint frame)
        {
            s_Items.Insert(0, new Item
            {
                Kind = Clean(kind),
                Author = Clean(author),
                Place = Clean(place),
                Message = Clean(message),
                Frame = frame,
                ImageKind = IsPlaceStory(kind) ? "building" : "person",
            });
            if (s_Items.Count > kMaxItems)
                s_Items.RemoveRange(kMaxItems, s_Items.Count - kMaxItems);
        }

        public static void AddVideo(string author, string place, string message, uint frame, int likes, int dislikes, int going, int skipping, string imageKind = "person")
        {
            s_Items.Insert(0, new Item
            {
                Kind = "TikTok",
                Author = Clean(author),
                Place = Clean(place),
                Message = Clean(message),
                Frame = frame,
                Likes = likes,
                Dislikes = dislikes,
                Going = going,
                Skipping = skipping,
                ImageKind = Clean(imageKind),
            });
            if (s_Items.Count > kMaxItems)
                s_Items.RemoveRange(kMaxItems, s_Items.Count - kMaxItems);
        }

        public static void AddCrime(Entity incident, string place, string message, uint frame, string author = "Police report", string crimeType = "Crime")
        {
            s_Items.Insert(0, new Item
            {
                Kind = $"Crime · {Clean(crimeType)}",
                Author = Clean(author),
                Place = Clean(place),
                Message = Clean(message),
                Frame = frame,
                CrimeIncident = incident,
                ImageKind = "building",
            });
            Trim();
            DjAnnouncement.EnqueueCrimeReport(place, message, crimeType);
        }

        public static void AddSocial(string kind, string author, string place, string message, uint frame, int likes, int dislikes, Entity incident, int going = 0, int skipping = 0, string imageKind = "person")
        {
            s_Items.Insert(0, new Item
            {
                Kind = Clean(kind),
                Author = Clean(author),
                Place = Clean(place),
                Message = Clean(message),
                Frame = frame,
                Likes = likes,
                Dislikes = dislikes,
                CrimeIncident = incident,
                Going = going,
                Skipping = skipping,
                ImageKind = Clean(imageKind),
            });
            Trim();
            if (kind == "Tweet") DjAnnouncement.EnqueueTweet(author, place, message, likes, dislikes);
        }

        public static void HideIncident(Entity incident)
        {
            for (int i = 0; i < s_Items.Count; i++)
            {
                if (s_Items[i].CrimeIncident != incident) continue;
                Item item = s_Items[i];
                item.Hidden = true;
                s_Items[i] = item;
            }
        }

        private static void Trim()
        {
            if (s_Items.Count > kMaxItems)
                s_Items.RemoveRange(kMaxItems, s_Items.Count - kMaxItems);
        }

        private static bool IsPlaceStory(string kind)
        {
            return kind == "Nightlife" || kind == "Live music" || kind == "Major live show" || kind == "City event"
                || kind == "Crime" || kind == "Protest" || kind == "City fine" || kind == "Public health" || kind == "Drug market"
                || kind == "Venue action" || kind == "Community update" || kind == "Case";
        }

        public static void Clear() => s_Items.Clear();

        private static string Clean(string value) => CityText.Clean(value);
    }
}
