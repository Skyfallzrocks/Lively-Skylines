using System.Collections.Generic;
using Game;
using Game.Citizens;
using Game.City;
using Game.Simulation;
using Unity.Entities;

namespace BarRush
{
    public static class CrimeHideQueue
    {
        private static readonly Queue<Entity> s_Requests = new Queue<Entity>();
        public const int Cost = 25000;
        public static string Status { get; private set; } = "Hide a public crime report for $25,000.";

        public static void Enqueue(Entity incident) => s_Requests.Enqueue(incident);

        public static bool TryDequeue(out Entity incident)
        {
            if (s_Requests.Count > 0)
            {
                incident = s_Requests.Dequeue();
                return true;
            }
            incident = Entity.Null;
            return false;
        }

        public static void SetStatus(string status) => Status = status;
    }

    // Applies report-suppression purchases on the simulation thread.
    public partial class CrimeDisclosureSystem : GameSystemBase
    {
        private CitySystem m_CitySystem;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 16;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.CrimeReportHidingEnabled) return;
            while (CrimeHideQueue.TryDequeue(out Entity incident))
            {
                if (!CityCrimeLedger.Contains(incident))
                {
                    CrimeHideQueue.SetStatus("That report is no longer public.");
                    continue;
                }

                Entity city = m_CitySystem.City;
                if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city))
                {
                    CrimeHideQueue.SetStatus("City funds are not available right now.");
                    continue;
                }

                PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
                if (!money.m_Unlimited && money.money < CrimeHideQueue.Cost)
                {
                    CrimeHideQueue.SetStatus("Not enough city funds to hide the report ($25,000).");
                    continue;
                }

                if (!CityCrimeLedger.Hide(incident))
                {
                    CrimeHideQueue.SetStatus("That report is no longer public.");
                    continue;
                }

                if (!money.m_Unlimited)
                {
                    money.Subtract(CrimeHideQueue.Cost);
                    EntityManager.SetComponentData(city, money);
                }
                CrimeHideQueue.SetStatus("Crime report hidden from the public feed. ($25,000)");
            }
        }
    }
}
