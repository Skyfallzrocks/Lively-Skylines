using System.Collections.Generic;
using Game;
using Game.Citizens;
using Game.Common;
using Game.City;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    public static class ParkEventPlanningQueue
    {
        public struct Request
        {
            public Entity Park;
            public int Size;
            public string Name;
            public string Type;
            public int DurationHours;
            public int Budget;
            public bool Ticketed;
            public bool Security;
            public bool Cleanup;
            public int Noise;
            public int StartDelayHours;
        }

        private static readonly Queue<Request> s_Queue = new Queue<Request>();
        public static string Status { get; private set; } = "Choose a park to plan a small city event.";
        public static void Enqueue(Entity park, int size, string name, string options)
        {
            string[] values = (options ?? "Community").Split('|');
            int Parse(int index, int fallback) => index < values.Length && int.TryParse(values[index], out int value) ? value : fallback;
            bool Flag(int index, bool fallback) => index < values.Length ? values[index] == "1" : fallback;
            s_Queue.Enqueue(new Request
            {
                Park = park, Size = size, Name = name ?? "", Type = values.Length > 0 ? values[0] : "Community",
                DurationHours = Parse(1, 4), Ticketed = Flag(2, false), Security = Flag(3, false),
                Cleanup = Flag(4, true), Noise = Parse(5, 1), Budget = Parse(6, 25000), StartDelayHours = Parse(7, 0)
            });
        }
        public static void SetStatus(string status) => Status = status;
        public static bool TryDequeue(out Request request)
        {
            if (s_Queue.Count > 0) { request = s_Queue.Dequeue(); return true; }
            request = default;
            return false;
        }
    }

    public partial class ParkEventPlanningSystem : GameSystemBase
    {
        private static readonly string[] s_EventNames = { "Park dance night", "Community music evening", "Food and friends festival", "Neighborhood talent show", "Summer lights gathering" };
        private static readonly string[] s_TheatreActs = { "The Last Train to Bellweather", "A Lantern for the Moon", "The Clockmaker's Secret", "Midnight at the Grand Hotel", "The Garden Behind the Stage", "Letters from the Northbound", "The Curious Case of the Red Umbrella", "A Very Small Tragedy" };
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private CitySystem m_CitySystem;
        private NameSystem m_NameSystem;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;
        private readonly List<ParkEventPlanningQueue.Request> m_Scheduled = new List<ParkEventPlanningQueue.Request>();
        private readonly List<uint> m_ScheduledFrames = new List<uint>();

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CandidateQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 16;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled) return;
            if (!Mod.Settings.CityEventsEnabled)
            {
                while (ParkEventPlanningQueue.TryDequeue(out _)) { }
                m_Scheduled.Clear();
                m_ScheduledFrames.Clear();
                ParkEventPlanningQueue.SetStatus("City events are turned off in Bar Rush settings.");
                return;
            }
            uint frame = m_SimulationSystem.frameIndex;
            while (ParkEventPlanningQueue.TryDequeue(out ParkEventPlanningQueue.Request request))
            {
                if (request.StartDelayHours > 0)
                {
                    int delay = math.clamp(request.StartDelayHours, 1, 24);
                    uint startFrame = frame + (uint)math.max(1, OutingStarter.FramesPerDay * delay / 24);
                    m_Scheduled.Add(request);
                    m_ScheduledFrames.Add(startFrame);
                    ParkEventPlanningQueue.SetStatus($"Event scheduled for {delay} in-game hours from now.");
                }
                else Plan(request);
            }
            for (int i = m_Scheduled.Count - 1; i >= 0; i--)
            {
                if (frame < m_ScheduledFrames[i]) continue;
                ParkEventPlanningQueue.Request scheduled = m_Scheduled[i];
                m_Scheduled.RemoveAt(i);
                m_ScheduledFrames.RemoveAt(i);
                Plan(scheduled);
            }
        }

        private void Plan(ParkEventPlanningQueue.Request request)
        {
            uint frame = m_SimulationSystem.frameIndex;
            Entity park = request.Park;
            if (ActiveEvents.HasActiveCityEvent(frame))
            {
                ParkEventPlanningQueue.SetStatus("A city event is already running. Wait for it to finish before planning another.");
                return;
            }
            if (park == Entity.Null || !EntityManager.Exists(park) || !EntityManager.HasComponent<Game.Buildings.Park>(park))
            {
                ParkEventPlanningQueue.SetStatus("That park is no longer available. Refresh the list and choose another.");
                return;
            }

            int population = m_PopulationQuery.CalculateEntityCount();
            int cap = PopulationCap.MaxAttendees(population, Mod.Settings.MaxAttendancePercent);
            int remaining = AttendanceLedger.Remaining(cap, frame);
            int sizePercent = request.Size >= 4 ? 25 : request.Size == 3 ? 18 : request.Size == 2 ? 12 : request.Size == 1 ? 8 : 4;
            int eventMax = math.min(math.max(1, population * sizePercent / 100), remaining);
            if (eventMax <= 0)
            {
                ParkEventPlanningQueue.SetStatus("The city is at the active event attendance limit. Wait for an event to end.");
                return;
            }

            int productionCost = math.clamp(request.Budget, 0, 2000000);
            if (!CanAffordBudget(productionCost))
            {
                ParkEventPlanningQueue.SetStatus($"The city budget cannot cover the ${productionCost:N0} event budget. No event was started.");
                return;
            }

            var random = new Random(math.max(1u, frame * 747796405u + (uint)park.Index * 2891336453u));
            int wanted = request.Ticketed ? math.max(1, eventMax * 85 / 100) : eventMax;
            uint duration = (uint)math.max(1, OutingStarter.FramesPerDay * math.clamp(request.DurationHours, 1, 12) / 24);
            using NativeArray<Entity> candidates = m_CandidateQuery.ToEntityArray(Allocator.Temp);
            int attendees = OutingStarter.Start(EntityManager, candidates, wanted, ref random, frame, duration, park);
            if (attendees <= 0)
            {
                ParkEventPlanningQueue.SetStatus("No available sims could join. No event was added.");
                return;
            }

            if (!ChargeBudget(productionCost))
            {
                ParkEventPlanningQueue.SetStatus($"The city budget cannot cover the ${productionCost:N0} event budget. No event was started.");
                return;
            }

            string parkName = m_NameSystem.GetRenderedLabelName(park);
            if (string.IsNullOrEmpty(parkName)) parkName = "City park";
            string eventType = string.IsNullOrWhiteSpace(request.Type) ? "Community" : request.Type;
            bool carMeet = string.Equals(eventType, "Car Meet", System.StringComparison.OrdinalIgnoreCase);
            bool streetRace = string.Equals(eventType, "Street Race", System.StringComparison.OrdinalIgnoreCase);
            string title = string.IsNullOrWhiteSpace(request.Name)
                ? string.Equals(eventType, "Theatre", System.StringComparison.OrdinalIgnoreCase) ? $"{eventType} · {s_TheatreActs[random.NextInt(s_TheatreActs.Length)]}" : carMeet ? $"City car meet · {parkName}" : streetRace ? $"Street race · {parkName}" : $"{eventType} · {s_EventNames[random.NextInt(s_EventNames.Length)]}"
                : request.Name.Trim();
            if (title.Length > 36) title = title.Substring(0, 36);
            ActiveEvents.AddCityEvent(title, parkName, attendees, frame + duration, park);
            if (request.Security) ActiveEvents.HireSecurity(frame, ActiveEvents.Current(frame).Count - 1);
            AttendanceLedger.Add(attendees, frame + duration);
            // Use a modest carpool estimate for event parking demand. CS2's own
            // traffic simulation still chooses each visitor's travel mode.
            int parkingSpaces = (attendees + 2) / 3;
            string productionNote = $" Type: {eventType}. Duration: {math.clamp(request.DurationHours, 1, 12)} in-game hours. Budget spent: ${productionCost:N0}.";
            if (carMeet)
            {
                productionNote += $" Car meet: {attendees:N0} residents are routed to the venue through ordinary game travel and traffic; estimated parking demand is {parkingSpaces:N0} spaces. No vehicles are created or forced onto roads.";
                PublicReactionLedger.Add("Organized community car meet", request.Security ? -2 : -1);
            }
            else if (streetRace)
            {
                Entity district = EntityManager.HasComponent<Game.Areas.CurrentDistrict>(park)
                    ? EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(park).m_District : Entity.Null;
                bool policeCoverage = district != Entity.Null && CrimeAreaSystem.HasPoliceStation(district);
                int incidentRisk = math.clamp(16 + request.Noise * 14 + (request.Security ? 0 : 12) - (policeCoverage ? 12 : 0), 3, 65);
                bool incident = random.NextInt(100) < incidentRisk;
                string raceResult = incident
                    ? policeCoverage ? "Police coverage responded quickly to a reported minor collision; no native vehicle or criminal record was changed." : "With no nearby police coverage, a minor collision and noise complaints were reported; no native vehicle or criminal record was changed."
                    : "The modeled race finished without a reported collision; the native traffic simulation continued to control every vehicle.";
                productionNote += $" Street race result: {raceResult} Modeled incident risk was {incidentRisk}% ({(policeCoverage ? "police coverage nearby" : "no nearby police station")}).";
                PublicReactionLedger.Add(incident ? "Street-race safety and noise report" : "Street-race event reported", incident ? 5 : 2);
                CityBuzzFeed.Add(incident ? "Street race · Incident reported" : "Street race · Results", "Breaking news · City Desk", parkName,
                    $"{title}: {raceResult} {attendees:N0} attendees were routed to the event. {incidentRisk}% modeled incident risk; {(policeCoverage ? "police coverage was available nearby" : "the district has no nearby police station")}.", frame);
            }
            if (request.Ticketed) productionNote += $" Ticketing is enabled; estimated event-door revenue is ${attendees * 18:N0} (modeled, not credited to the city treasury).";
            productionNote += request.Security ? " Event security is assigned." : " No dedicated event security was purchased.";
            if (request.Cleanup) { productionNote += " Cleanup crew is included."; PublicReactionLedger.Add("Funded event cleanup", -1); }
            else { productionNote += " Cleanup is not funded; litter and resident complaints may follow."; PublicReactionLedger.Add("Event cleanup not funded", 1); }
            if (request.Noise >= 2) { productionNote += " Late-night amplified sound may disturb nearby residents."; PublicReactionLedger.Add("Late-night event noise", 1); }
            else if (request.Noise == 0) productionNote += " Quiet sound plan reduces neighborhood disruption.";
            CityBuzzFeed.Add(eventType, "Event desk", parkName, $"{title} started. {attendees:N0} sims are attending; estimated parking demand is {parkingSpaces:N0} spaces.{productionNote}", frame);
            if (random.NextInt(100) < 75)
                FamousSimRoster.PublishShowTweet(EntityManager, ref random, parkName, $"I'm heading to {parkName} for {title}. The show is on now!", frame, attendees);
            DjAnnouncement.EnqueueCityEvent(title, parkName, attendees);
            ParkEventPlanningQueue.SetStatus($"{eventType} '{title}' is live at {parkName} for {attendees:N0} sims · {request.DurationHours}h · ${productionCost:N0} city cost · {parkingSpaces:N0} estimated parking spaces.");
            Mod.log.Info($"Planned {SizeName(request.Size)} {eventType} '{title}' at {parkName} for {attendees} sims (cap {cap}, population {population}, cost {productionCost}).");
        }

        private bool ChargeBudget(int amount)
        {
            if (amount <= 0) return true;
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city)) return false;
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            if (!money.m_Unlimited && money.money < amount) return false;
            if (!money.m_Unlimited) { money.Subtract(amount); EntityManager.SetComponentData(city, money); }
            return true;
        }

        private bool CanAffordBudget(int amount)
        {
            if (amount <= 0) return true;
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<PlayerMoney>(city)) return false;
            PlayerMoney money = EntityManager.GetComponentData<PlayerMoney>(city);
            return money.m_Unlimited || money.money >= amount;
        }

        private static string SizeName(int size) => size >= 4 ? "festival" : size == 3 ? "major" : size == 2 ? "big" : size == 1 ? "medium" : "small";
    }
}
