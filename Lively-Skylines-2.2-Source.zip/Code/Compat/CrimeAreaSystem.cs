using System.Collections.Generic;
using Game;
using Game.Areas;
using Game.Buildings;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;

namespace BarRush
{
    /// <summary>
    /// Applies a restrained local crime-pressure increase to districts without a police station.
    /// Crime events are still generated and timestamped by the game's own crime simulation.
    /// </summary>
    [UpdateAfter(typeof(CrimeAccumulationSystem))]
    [UpdateBefore(typeof(CrimeCheckSystem))]
    public partial class CrimeAreaSystem : GameSystemBase
    {
        private EntityQuery m_ProducerQuery;
        private EntityQuery m_StationQuery;
        private EntityQuery m_CitizenQuery;
        private readonly Dictionary<Entity, float> m_LastScaledValues = new Dictionary<Entity, float>();
        private readonly Dictionary<Entity, float> m_BaseValues = new Dictionary<Entity, float>();
        private static readonly HashSet<Entity> s_DistrictsWithPolice = new HashSet<Entity>();
        private static int s_CityPopulation;

        public static int CityPopulation => s_CityPopulation;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_ProducerQuery = GetEntityQuery(ComponentType.ReadWrite<CrimeProducer>(), ComponentType.ReadOnly<CurrentDistrict>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_StationQuery = GetEntityQuery(ComponentType.ReadOnly<PoliceStation>(), ComponentType.ReadOnly<CurrentDistrict>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.CrimeAreaScalingEnabled)
            {
                RestoreScaledValues();
                return;
            }
            s_CityPopulation = m_CitizenQuery.CalculateEntityCount();
            s_DistrictsWithPolice.Clear();

            using (NativeArray<Entity> stations = m_StationQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity station in stations)
                {
                    if (!EntityManager.HasComponent<CurrentDistrict>(station)) continue;
                    Entity district = EntityManager.GetComponentData<CurrentDistrict>(station).m_District;
                    if (district != Entity.Null) s_DistrictsWithPolice.Add(district);
                }
            }

            float cityCrimeRate = CityCrimeLedger.WeeklyPerThousand(World.GetOrCreateSystemManaged<SimulationSystem>().frameIndex);
            // The uncovered-area bonus rises with the city's observed, real incident rate, capped at +75%.
            float noPoliceMultiplier = 1.25f + Unity.Mathematics.math.saturate(cityCrimeRate / 10f) * 0.5f;
            var seen = new HashSet<Entity>();
            using (NativeArray<Entity> producers = m_ProducerQuery.ToEntityArray(Allocator.Temp))
            {
                foreach (Entity entity in producers)
                {
                    seen.Add(entity);
                    CurrentDistrict current = EntityManager.GetComponentData<CurrentDistrict>(entity);
                    Entity district = current.m_District;
                    CrimeProducer producer = EntityManager.GetComponentData<CrimeProducer>(entity);
                    float baseValue = producer.m_Crime;

                    if (m_LastScaledValues.TryGetValue(entity, out float previousScaled) &&
                        m_BaseValues.TryGetValue(entity, out float previousBase) &&
                        Unity.Mathematics.math.abs(baseValue - previousScaled) < 0.0001f)
                        baseValue = previousBase;

                    float multiplier = district != Entity.Null && !s_DistrictsWithPolice.Contains(district) ? noPoliceMultiplier : 1f;
                    producer.m_Crime = baseValue * multiplier;
                    EntityManager.SetComponentData(entity, producer);
                    m_BaseValues[entity] = baseValue;
                    m_LastScaledValues[entity] = producer.m_Crime;
                }
            }
            var stale = new List<Entity>();
            foreach (Entity entity in m_LastScaledValues.Keys)
                if (!seen.Contains(entity) || !EntityManager.Exists(entity)) stale.Add(entity);
            foreach (Entity entity in stale)
            {
                m_LastScaledValues.Remove(entity);
                m_BaseValues.Remove(entity);
            }
        }

        private void RestoreScaledValues()
        {
            foreach (KeyValuePair<Entity, float> item in m_LastScaledValues)
            {
                if (!EntityManager.Exists(item.Key) || !EntityManager.HasComponent<CrimeProducer>(item.Key) ||
                    !m_BaseValues.TryGetValue(item.Key, out float baseValue)) continue;
                CrimeProducer producer = EntityManager.GetComponentData<CrimeProducer>(item.Key);
                if (Unity.Mathematics.math.abs(producer.m_Crime - item.Value) >= 0.0001f) continue;
                producer.m_Crime = baseValue;
                EntityManager.SetComponentData(item.Key, producer);
            }
            m_LastScaledValues.Clear();
            m_BaseValues.Clear();
        }

        public static bool HasPoliceStation(Entity district) => district != Entity.Null && s_DistrictsWithPolice.Contains(district);

        public static string GetDistrictName(EntityManager entityManager, NameSystem nameSystem, Entity building)
        {
            if (entityManager.HasComponent<CurrentDistrict>(building))
            {
                Entity district = entityManager.GetComponentData<CurrentDistrict>(building).m_District;
                if (district != Entity.Null)
                {
                    string name = nameSystem.GetRenderedLabelName(district);
                    if (!string.IsNullOrEmpty(name)) return name;
                }
            }
            return "Undistricted area";
        }
    }
}
