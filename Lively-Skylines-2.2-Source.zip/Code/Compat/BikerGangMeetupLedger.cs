using System.Collections.Generic;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Recent biker meetup locations for the Lively Skylines directory.</summary>
    public static class BikerGangMeetupLedger
    {
        public struct Entry
        {
            public int Id;
            public string Gang;
            public string Venue;
            public string Area;
            public int Bikes;
            public int Residents;
            public uint Frame;
            public uint EndFrame;
            public Entity Location;
        }

        private const int kMaxEntries = 30;
        private static readonly List<Entry> s_Entries = new List<Entry>();
        private static int s_NextId;

        public static void Add(string gang, string venue, string area, int bikes, int residents, uint frame, uint endFrame, Entity location)
        {
            s_Entries.Insert(0, new Entry
            {
                Id = ++s_NextId,
                Gang = Clean(gang),
                Venue = Clean(venue),
                Area = Clean(area),
                Bikes = bikes,
                Residents = residents,
                Frame = frame,
                EndFrame = endFrame,
                Location = location,
            });
            if (s_Entries.Count > kMaxEntries) s_Entries.RemoveRange(kMaxEntries, s_Entries.Count - kMaxEntries);
        }

        public static List<Entry> Recent(uint frame)
        {
            uint retention = OutingStarter.FramesPerDay * 7u;
            var result = new List<Entry>(s_Entries.Count);
            foreach (Entry entry in s_Entries)
                if (frame < entry.Frame || frame - entry.Frame <= retention) result.Add(entry);
            return result;
        }

        private static string Clean(string value) => (value ?? "Unknown").Replace("|", "/").Replace("\r", " ").Replace("\n", " ");
    }
}
