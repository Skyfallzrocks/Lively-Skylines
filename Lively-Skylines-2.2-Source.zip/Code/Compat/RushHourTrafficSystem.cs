using Game;
using Game.Common;
using Game.Simulation;
using Unity.Collections;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Observes the city's naturally simulated commuter traffic during morning and evening rush windows.</summary>
    public partial class RushHourTrafficSystem : GameSystemBase
    {
        private const float kMorningStart = 7f / 24f;
        private const float kMorningEnd = 10f / 24f;
        private const float kEveningStart = 16f / 24f;
        private const float kEveningEnd = 19f / 24f;
        private EntityQuery m_MovingCars;
        private SimulationSystem m_Simulation;
        private TimeSystem m_Time;
        private float m_PreviousTime = -1f;
        private uint m_LastMorningDay = uint.MaxValue;
        private uint m_LastEveningDay = uint.MaxValue;
        private uint m_LastCountFrame;
        private int m_MovingVehicleCount;
        private string m_Status = "Traffic monitor is waiting for city simulation data.";
        private string m_LastReport = "No rush-hour report yet.";

        protected override void OnCreate()
        {
            base.OnCreate();
            m_Simulation = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_Time = World.GetOrCreateSystemManaged<TimeSystem>();
            m_MovingCars = GetEntityQuery(ComponentType.ReadOnly<Game.Vehicles.PersonalCar>(),
                ComponentType.ReadOnly<Game.Objects.Moving>(), ComponentType.ReadOnly<Game.Objects.Transform>(),
                ComponentType.Exclude<Game.Vehicles.ParkedCar>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled || !Mod.Settings.CityEventsEnabled) return;
            uint frame = m_Simulation.frameIndex;
            uint day = frame / OutingStarter.FramesPerDay;
            float time = m_Time.normalizedTime;
            bool morning = time >= kMorningStart && time < kMorningEnd;
            bool evening = time >= kEveningStart && time < kEveningEnd;
            m_Status = morning ? "Morning commute · 7:00–10:00" : evening ? "Evening commute · 16:00–19:00" : "Between rush windows";
            if (frame - m_LastCountFrame >= 128 || m_LastCountFrame == 0)
            {
                using NativeArray<Entity> cars = m_MovingCars.ToEntityArray(Allocator.Temp);
                m_MovingVehicleCount = cars.Length;
                m_LastCountFrame = frame;
            }

            if (m_PreviousTime >= 0f)
            {
                bool morningStarted = m_PreviousTime < kMorningStart && time >= kMorningStart;
                bool eveningStarted = m_PreviousTime < kEveningStart && time >= kEveningStart;
                if (morningStarted && m_LastMorningDay != day)
                {
                    m_LastMorningDay = day;
                    Publish("Morning rush hour", frame);
                }
                if (eveningStarted && m_LastEveningDay != day)
                {
                    m_LastEveningDay = day;
                    Publish("Evening rush hour", frame);
                }
            }
            m_PreviousTime = time;
        }

        private void Publish(string title, uint frame)
        {
            m_LastReport = $"{title}: {m_MovingVehicleCount:N0} moving personal cars observed citywide at the start of the commute window.";
            CityBuzzFeed.Add("Rush hour", "Traffic monitor", "Citywide", m_LastReport + " Counts reflect currently moving cars; the mod does not spawn or reroute native traffic.", frame);
            Mod.log.Info(m_LastReport);
        }

        public string Status => m_Status;
        public string LastReport => m_LastReport;
        public int MovingVehicleCount => m_MovingVehicleCount;
    }
}
