using System.Collections.Generic;
using Unity.Entities;

namespace BarRush
{
    public static class BarCaseLedger
    {
        private static readonly Dictionary<Entity, int> s_Cases = new Dictionary<Entity, int>();

        public static void Record(Entity building)
        {
            if (building == Entity.Null) return;
            s_Cases.TryGetValue(building, out int count);
            s_Cases[building] = count + 1;
        }

        public static int Get(Entity building) => s_Cases.TryGetValue(building, out int count) ? count : 0;

        public static void ClearOne(Entity building)
        {
            if (!s_Cases.TryGetValue(building, out int count)) return;
            if (count <= 1) s_Cases.Remove(building);
            else s_Cases[building] = count - 1;
        }
    }
}
