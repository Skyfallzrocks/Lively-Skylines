using System;
using System.Collections.Generic;
using System.Text;
using Game.UI;
using Unity.Entities;

namespace BarRush
{
    /// <summary>
    /// Fictional underworld economy layered on the gang/cartel roster: properties (grow houses,
    /// stash houses, warehouses, front businesses) on real city buildings, product stock that
    /// feeds the street market, district turf control, turf wars, police heat and intel, and
    /// city enforcement actions with real budget costs.
    /// </summary>
    public static class GangEconomyLedger
    {
        public sealed class Property
        {
            public int Id;
            public int OrgId;
            public string Kind;
            public Entity Building;
            public string Name;
            public string Area;
            public float X, Z;
            public int Stock;
            public int Capacity;
            public long Cash;
            public bool Discovered;
            public int Intel;
            public bool Seized;
            public uint SeizedUntil;
        }

        public sealed class OrgState
        {
            public int OrgId;
            public int Heat;
            public long Cash;
            public int Arrested;
            public int InterventionWeeks;
            public int Raided;
            public readonly Dictionary<string, int> Control = new Dictionary<string, int>();
        }

        private static readonly List<Property> s_Properties = new List<Property>();
        private static readonly Dictionary<int, OrgState> s_Orgs = new Dictionary<int, OrgState>();
        private static readonly List<string> s_Events = new List<string>();
        private static uint s_NextDayFrame, s_NextWeekFrame;
        private static int s_TurfWarHeat;
        private static int s_Seized, s_CashSeized, s_TotalArrests;

        private const int kSurveilCost = 5000, kRaidCost = 15000, kCrackdownCost = 25000, kInterventionCost = 12000;

        public static int ViolenceOffset => Math.Min(8, s_TurfWarHeat);

        /// <summary>A cartel tries to wash cash through a business. Returns the group's name, or null if none exists.</summary>
        public static string LaunderThrough(bool blocked, long amount, uint frame)
        {
            foreach (var org in Orgs())
            {
                if (org.Type != "Cartel") continue;
                OrgState st = State(org.Id);
                if (blocked) { st.Heat = Math.Min(100, st.Heat + 12); foreach (Property p in s_Properties) if (p.OrgId == org.Id && !p.Discovered) p.Intel = Math.Min(100, p.Intel + 15); }
                else st.Cash += amount;
                return org.Name;
            }
            return null;
        }

        /// <summary>The district where street gangs hold the most turf, or null.</summary>
        public static string HottestDistrict()
        {
            string best = null; int top = 0;
            foreach (var kv in s_Orgs) foreach (var c in kv.Value.Control) if (c.Value > top) { top = c.Value; best = c.Key; }
            return best;
        }

        /// <summary>Daily effect of youth centers: gangs recruit less and lose grip where centers operate.</summary>
        public static void YouthCentersWeaken(List<YouthCenterLedger.Center> centers, uint frame)
        {
            foreach (var org in Orgs())
            {
                OrgState st = State(org.Id);
                foreach (var center in centers)
                {
                    if (!st.Control.ContainsKey(center.Area)) continue;
                    int loss = 1 + (center.JobTraining ? 1 : 0) + (center.LateNight ? 1 : 0);
                    st.Control[center.Area] = Math.Max(0, st.Control[center.Area] - loss);
                    if (org.Type == "Street gang" && center.JobTraining && (frame / OutingStarter.FramesPerDay) % 4u == 0u) org.Members = Math.Max(3, org.Members - 1);
                }
            }
        }

        private static OrgState State(int orgId)
        {
            if (!s_Orgs.TryGetValue(orgId, out OrgState st)) { st = new OrgState { OrgId = orgId, Heat = 10, Cash = 15000 }; s_Orgs[orgId] = st; }
            return st;
        }

        private static IEnumerable<DrugOrganizationLedger.Organization> Orgs()
        {
            int total = DrugOrganizationLedger.Count("Street gang") + DrugOrganizationLedger.Count("Cartel");
            for (int i = 0; i < total; i++) { var o = DrugOrganizationLedger.ById(i); if (o != null) yield return o; }
        }

        private static void Event(string text)
        {
            s_Events.Insert(0, CityText.Clean(text));
            if (s_Events.Count > 14) s_Events.RemoveAt(s_Events.Count - 1);
        }

        // ---- Setup -------------------------------------------------------------------
        private static void EnsureProperties(EntityManager em, EntityQuery buildingQuery, NameSystem names, ref Unity.Mathematics.Random random)
        {
            List<Entity> pool = null; List<string> poolAreas = null;
            foreach (var org in Orgs())
            {
                OrgState st = State(org.Id);
                if (st.Control.Count == 0 && !string.IsNullOrWhiteSpace(org.Territory) && org.Territory != "Unassigned turf")
                    st.Control[org.Territory] = org.Type == "Cartel" ? 45 : 60;
                bool has = false;
                foreach (Property p in s_Properties) if (p.OrgId == org.Id) { has = true; break; }
                if (has) continue;
                if (pool == null) BuildPool(em, buildingQuery, names, out pool, out poolAreas);
                if (pool.Count == 0) return;
                if (org.Type == "Cartel")
                {
                    AddProperty(em, names, org, "Warehouse", pool, poolAreas, ref random, 220, 900);
                    AddProperty(em, names, org, "Stash house", pool, poolAreas, ref random, 60, 300);
                    AddProperty(em, names, org, "Front business", pool, poolAreas, ref random, 0, 0);
                }
                else
                {
                    AddProperty(em, names, org, "Grow house", pool, poolAreas, ref random, 30, 140);
                    AddProperty(em, names, org, "Stash house", pool, poolAreas, ref random, 40, 220);
                }
            }
        }

        private static void BuildPool(EntityManager em, EntityQuery q, NameSystem names, out List<Entity> pool, out List<string> areas)
        {
            pool = new List<Entity>(); areas = new List<string>();
            using (var buildings = q.ToEntityArray(Unity.Collections.Allocator.Temp))
            {
                int step = Math.Max(1, buildings.Length / 1500);
                for (int i = 0; i < buildings.Length; i += step)
                {
                    Entity b = buildings[i];
                    if (!em.HasComponent<Game.Objects.Transform>(b)) continue;
                    pool.Add(b);
                    string a = CrimeAreaSystem.GetDistrictName(em, names, b);
                    areas.Add(string.IsNullOrWhiteSpace(a) ? "Citywide" : a);
                }
            }
        }

        private static Property AddProperty(EntityManager em, NameSystem names, DrugOrganizationLedger.Organization org, string kind,
            List<Entity> pool, List<string> areas, ref Unity.Mathematics.Random random, int stock, int capacity, string preferArea = null)
        {
            string want = preferArea ?? org.Territory;
            int pick = -1;
            int start = random.NextInt(pool.Count);
            for (int k = 0; k < pool.Count; k++)
            {
                int i = (start + k) % pool.Count;
                if (Used(pool[i])) continue;
                if (areas[i] == want) { pick = i; break; }
                if (pick < 0) pick = i;
            }
            if (pick < 0) return null;
            Entity b = pool[pick];
            var pos = em.GetComponentData<Game.Objects.Transform>(b).m_Position;
            string label = names.GetRenderedLabelName(b);
            var p = new Property
            {
                Id = s_Properties.Count, OrgId = org.Id, Kind = kind, Building = b,
                Name = string.IsNullOrWhiteSpace(label) ? $"{kind} site" : label, Area = areas[pick], X = pos.x, Z = pos.z,
                Stock = stock, Capacity = capacity, Cash = kind == "Front business" ? 0 : random.NextInt(2000, 9000),
                Intel = random.NextInt(0, 25)
            };
            s_Properties.Add(p);
            return p;
        }

        private static bool Used(Entity b) { foreach (Property p in s_Properties) if (p.Building == b && !p.Seized) return true; return false; }

        private static Property Find(int orgId, string kind)
        {
            foreach (Property p in s_Properties) if (p.OrgId == orgId && p.Kind == kind && !p.Seized) return p;
            return null;
        }

        // ---- Simulation ---------------------------------------------------------------
        public static void Advance(uint frame, EntityManager em, EntityQuery buildingQuery, NameSystem names)
        {
            var random = new Unity.Mathematics.Random(Math.Max(1u, frame * 2654435761u + 97u));
            EnsureProperties(em, buildingQuery, names, ref random);
            if (s_NextDayFrame == 0 || frame + OutingStarter.FramesPerDay * 3u < s_NextDayFrame) { s_NextDayFrame = frame + OutingStarter.FramesPerDay; s_NextWeekFrame = frame + OutingStarter.FramesPerDay * 7u; return; }
            if (frame >= s_NextDayFrame) { s_NextDayFrame = frame + OutingStarter.FramesPerDay; Daily(frame, ref random); }
            if (frame >= s_NextWeekFrame) { s_NextWeekFrame = frame + OutingStarter.FramesPerDay * 7u; Weekly(frame, em, buildingQuery, names, ref random); }
        }

        private static void Daily(uint frame, ref Unity.Mathematics.Random random)
        {
            foreach (Property p in s_Properties)
            {
                if (p.Seized) continue;
                OrgState st = State(p.OrgId);
                switch (p.Kind)
                {
                    case "Grow house":
                        p.Stock = Math.Min(p.Capacity, p.Stock + random.NextInt(6, 15));
                        Property stash = Find(p.OrgId, "Stash house");
                        if (stash != null && p.Stock > 20)
                        {
                            int move = Math.Min(p.Stock - 10, stash.Capacity - stash.Stock);
                            if (move > 0) { p.Stock -= move; stash.Stock += move; }
                        }
                        break;
                    case "Warehouse":
                        if (random.NextInt(3) == 0) p.Stock = Math.Min(p.Capacity, p.Stock + random.NextInt(40, 90));
                        Property cstash = Find(p.OrgId, "Stash house");
                        if (cstash != null && cstash.Stock < cstash.Capacity / 2 && p.Stock > 60)
                        {
                            int move = Math.Min(p.Stock - 40, cstash.Capacity - cstash.Stock);
                            if (move > 0) { p.Stock -= move; cstash.Stock += move; }
                        }
                        break;
                    case "Front business":
                        long laundered = Math.Min(st.Cash, 2500);
                        st.Cash -= laundered; p.Cash += laundered;
                        st.Heat = Math.Max(0, st.Heat - 1);
                        break;
                }
                // Police intel builds over time on hidden properties, faster when the group is hot.
                if (!p.Discovered)
                {
                    p.Intel = Math.Min(100, p.Intel + 1 + st.Heat / 25 + (random.NextInt(100) < 8 ? 10 : 0));
                    if (p.Intel >= 100)
                    {
                        p.Discovered = true;
                        var org = DrugOrganizationLedger.ById(p.OrgId);
                        string text = $"Detectives identified a suspected {p.Kind.ToLowerInvariant()} run by {org?.Name ?? "a local group"} at {p.Name} in {p.Area}.";
                        Event(text);
                        CityBuzzFeed.Add("Crime report · intel", "Crime Desk", $"{p.Name} · {p.Area}", text, frame);
                    }
                }
            }
            foreach (var kv in s_Orgs) kv.Value.Heat = Math.Max(0, kv.Value.Heat - 1);
            if (s_TurfWarHeat > 0 && random.NextInt(3) == 0) s_TurfWarHeat--;
            // Re-open seized operations elsewhere after a cooldown.
            foreach (Property p in s_Properties)
                if (p.Seized && frame >= p.SeizedUntil && p.SeizedUntil != 0) p.SeizedUntil = 0;
        }

        private static void Weekly(uint frame, EntityManager em, EntityQuery buildingQuery, NameSystem names, ref Unity.Mathematics.Random random)
        {
            var orgs = new List<DrugOrganizationLedger.Organization>(Orgs());
            // Extortion in strongly held turf.
            foreach (var org in orgs)
            {
                OrgState st = State(org.Id);
                foreach (var kv in st.Control)
                    if (kv.Value >= 60)
                    {
                        st.Cash += 1500 + kv.Value * 40;
                        PublicReactionLedger.Add($"Businesses in {kv.Key} report pressure from {org.Name}", 1);
                    }
                if (st.InterventionWeeks > 0)
                {
                    st.InterventionWeeks--;
                    org.Members = Math.Max(3, org.Members - 1);
                    org.Recruiters = Math.Max(0, org.Recruiters - (random.NextInt(2) == 0 ? 1 : 0));
                }
            }
            // Turf wars between rivals in the same district.
            var areas = new HashSet<string>();
            foreach (var org in orgs) foreach (var a in State(org.Id).Control.Keys) areas.Add(a);
            foreach (string area in areas)
            {
                DrugOrganizationLedger.Organization a = null, b = null;
                foreach (var org in orgs)
                {
                    if (!State(org.Id).Control.TryGetValue(area, out int c) || c <= 0) continue;
                    if (a == null) a = org; else if (b == null && org.Type == a.Type) b = org;
                }
                if (a == null || b == null) continue;
                OrgState sa = State(a.Id), sb = State(b.Id);
                long powA = a.Members + a.Sellers * 2 + sa.Cash / 5000 + random.NextInt(0, 12);
                long powB = b.Members + b.Sellers * 2 + sb.Cash / 5000 + random.NextInt(0, 12);
                var win = powA >= powB ? a : b; var lose = win == a ? b : a;
                int shift = random.NextInt(5, 16);
                State(win.Id).Control[area] = Math.Min(100, State(win.Id).Control[area] + shift);
                State(lose.Id).Control[area] = Math.Max(0, State(lose.Id).Control[area] - shift);
                State(win.Id).Heat += 8; State(lose.Id).Heat += 5;
                s_TurfWarHeat = Math.Min(10, s_TurfWarHeat + 2);
                win.LinkedCrimeReports++; lose.LinkedCrimeReports++;
                string text = $"Turf war in {area}: {win.Name} pushed back {lose.Name} ({State(win.Id).Control[area]}% vs {State(lose.Id).Control[area]}% control). Residents reported shots fired.";
                Event(text);
                CityBuzzFeed.Add("Crime report · turf war", "Crime Desk", area, text, frame);
                PublicReactionLedger.Add($"Turf war in {area}", 2);
            }
            // Expansion: rich groups buy a new property and push into a new district.
            foreach (var org in orgs)
            {
                OrgState st = State(org.Id);
                if (st.Cash < 30000 || org.Members < 14 || random.NextInt(100) >= 35) continue;
                List<Entity> pool; List<string> poolAreas;
                BuildPool(em, buildingQuery, names, out pool, out poolAreas);
                if (pool.Count == 0) break;
                string target = poolAreas[random.NextInt(poolAreas.Count)];
                string kind = org.Type == "Cartel" ? (random.NextInt(2) == 0 ? "Stash house" : "Warehouse") : (random.NextInt(2) == 0 ? "Grow house" : "Stash house");
                Property p = AddProperty(em, names, org, kind, pool, poolAreas, ref random, 10, kind == "Warehouse" ? 900 : kind == "Grow house" ? 140 : 220, target);
                if (p == null) continue;
                st.Cash -= 20000;
                st.Control[p.Area] = Math.Max(st.Control.TryGetValue(p.Area, out int c) ? c : 0, 15);
                Event($"{org.Name} expanded into {p.Area} with a new {kind.ToLowerInvariant()}.");
            }
        }

        // ---- Hooks from the street market -----------------------------------------------
        public static bool HasStock(DrugOrganizationLedger.Organization org)
        {
            if (org == null) return false;
            foreach (Property p in s_Properties) if (p.OrgId == org.Id && !p.Seized && p.Stock > 0 && (p.Kind == "Stash house" || p.Kind == "Grow house")) return true;
            return !OwnsAny(org.Id);
        }

        private static bool OwnsAny(int orgId) { foreach (Property p in s_Properties) if (p.OrgId == orgId) return true; return false; }

        public static void OnStreetSale(DrugOrganizationLedger.Organization org, int buyers, long revenue)
        {
            if (org == null) return;
            OrgState st = State(org.Id);
            int need = Math.Max(1, buyers);
            foreach (Property p in s_Properties)
            {
                if (need <= 0) break;
                if (p.OrgId != org.Id || p.Seized || (p.Kind != "Stash house" && p.Kind != "Grow house")) continue;
                int take = Math.Min(need, p.Stock); p.Stock -= take; need -= take;
                if (p.Kind == "Stash house") p.Cash += revenue / 2;
            }
            st.Cash += revenue / 2;
            st.Heat = Math.Min(100, st.Heat + 1 + buyers / 6);
        }

        /// <summary>Moves wholesale units from a cartel's warehouse to a gang's stash. Returns units moved.</summary>
        public static int Wholesale(DrugOrganizationLedger.Organization cartel, DrugOrganizationLedger.Organization gang, int units, long value)
        {
            if (cartel == null || gang == null || units <= 0) return units;
            if (!OwnsAny(cartel.Id)) return units;
            Property wh = Find(cartel.Id, "Warehouse") ?? Find(cartel.Id, "Stash house");
            if (wh == null) return 0;
            int moved = Math.Min(units, wh.Stock);
            wh.Stock -= moved;
            Property stash = Find(gang.Id, "Stash house");
            if (stash != null) stash.Stock = Math.Min(stash.Capacity, stash.Stock + moved);
            State(cartel.Id).Cash += value * moved / Math.Max(1, units);
            State(gang.Id).Cash = Math.Max(0, State(gang.Id).Cash - value * moved / Math.Max(1, units));
            return moved;
        }

        // ---- City enforcement --------------------------------------------------------------
        /// <summary>action 1 = surveil, 2 = raid. Returns money for the city (+) or 0; charge pays costs.</summary>
        public static long PropertyAction(int id, int action, uint frame, Func<int, bool> charge)
        {
            if (id < 0 || id >= s_Properties.Count) return 0;
            Property p = s_Properties[id];
            if (p.Seized) return 0;
            var org = DrugOrganizationLedger.ById(p.OrgId);
            OrgState st = State(p.OrgId);
            var random = new Unity.Mathematics.Random(Math.Max(1u, frame * 31u + (uint)id * 7919u + 3u));
            if (action == 1)
            {
                if (!charge(kSurveilCost)) { Event("Surveillance not funded: the city cannot cover $5,000."); return 0; }
                p.Intel = Math.Min(100, p.Intel + 40);
                st.Heat = Math.Min(100, st.Heat + 3);
                if (p.Intel >= 100 && !p.Discovered) { p.Discovered = true; Event($"Surveillance confirmed a {p.Kind.ToLowerInvariant()} at {p.Name} in {p.Area}."); }
                else Event($"Detectives watched a suspected {org?.Name ?? "group"} site · intel now {p.Intel}%.");
                return 0;
            }
            if (action == 2)
            {
                if (!p.Discovered) return 0;
                if (!charge(kRaidCost)) { Event("Raid not funded: the city cannot cover $15,000."); return 0; }
                int chance = Math.Max(35, Math.Min(90, 55 + p.Intel / 4 - (org?.Members ?? 10) / 4 + (100 - st.Heat) / 10));
                if (random.NextInt(100) < chance)
                {
                    int arrests = random.NextInt(2, 7);
                    long seizedCash = p.Cash;
                    if (org != null) { org.Members = Math.Max(3, org.Members - arrests); org.Sellers = Math.Max(1, org.Sellers - arrests / 2); }
                    st.Arrested += arrests; st.Raided++; s_TotalArrests += arrests; s_Seized += p.Stock; s_CashSeized += (int)Math.Min(int.MaxValue, seizedCash);
                    string text = $"Police raided {p.Name} in {p.Area}: seized {p.Stock} units of product and ${seizedCash:N0} in cash, and arrested {arrests} {org?.Name ?? "group"} members.";
                    p.Seized = true; p.Stock = 0; p.Cash = 0; p.SeizedUntil = frame + OutingStarter.FramesPerDay * 30u;
                    if (st.Control.ContainsKey(p.Area)) st.Control[p.Area] = Math.Max(0, st.Control[p.Area] - 20);
                    st.Heat = Math.Max(0, st.Heat - 15);
                    Event(text);
                    CityBuzzFeed.Add("Crime report · police raid", "Crime Desk", $"{p.Name} · {p.Area}", text + " Seized cash goes to the city budget.", frame);
                    PublicReactionLedger.Add($"Police raid in {p.Area}", -2);
                    return seizedCash;
                }
                else
                {
                    string text = $"Police raided {p.Name} in {p.Area} but found it cleared out — {org?.Name ?? "the group"} was tipped off and moved the operation.";
                    p.Discovered = false; p.Intel = 10; st.Heat = Math.Min(100, st.Heat + 10);
                    Event(text);
                    CityBuzzFeed.Add("Crime report · police raid", "Crime Desk", p.Area, text, frame);
                    PublicReactionLedger.Add($"Failed raid in {p.Area}", 2);
                }
            }
            return 0;
        }

        /// <summary>action 1 = district crackdown, 2 = youth intervention program (4 weeks).</summary>
        public static void OrgAction(int orgId, int action, uint frame, Func<int, bool> charge)
        {
            var org = DrugOrganizationLedger.ById(orgId);
            if (org == null) return;
            OrgState st = State(orgId);
            var random = new Unity.Mathematics.Random(Math.Max(1u, frame * 17u + (uint)orgId * 104729u + 11u));
            if (action == 1)
            {
                if (!charge(kCrackdownCost)) { Event("Crackdown not funded: the city cannot cover $25,000."); return; }
                string top = null; int best = -1;
                foreach (var kv in st.Control) if (kv.Value > best) { best = kv.Value; top = kv.Key; }
                if (top == null) return;
                int arrests = random.NextInt(1, 5);
                org.Members = Math.Max(3, org.Members - arrests); st.Arrested += arrests; s_TotalArrests += arrests;
                st.Control[top] = Math.Max(0, best - 20); st.Heat = Math.Min(100, st.Heat + 20);
                foreach (Property p in s_Properties) if (p.OrgId == orgId && p.Area == top && !p.Discovered) p.Intel = Math.Min(100, p.Intel + 25);
                s_TurfWarHeat = Math.Max(0, s_TurfWarHeat - 2);
                string text = $"Police crackdown in {top}: {arrests} {org.Name} members arrested; the group's grip on the district fell to {st.Control[top]}%. Some residents complained about heavy policing.";
                Event(text);
                CityBuzzFeed.Add("Crime report · crackdown", "Crime Desk", top, text, frame);
                PublicReactionLedger.Add($"Police crackdown in {top}", 2);
            }
            else if (action == 2)
            {
                if (st.InterventionWeeks > 0) return;
                if (!charge(kInterventionCost)) { Event("Intervention program not funded: the city cannot cover $12,000."); return; }
                st.InterventionWeeks = 4;
                string text = $"The city launched a youth intervention program targeting {org.Name} recruitment in {org.Territory}: mentors, jobs and outreach for four weeks.";
                Event(text);
                CityBuzzFeed.Add("Community · intervention", "Harbor Daily", org.Territory, text, frame);
                PublicReactionLedger.Add("Youth intervention program launched", -2);
            }
        }

        // ---- UI rows -------------------------------------------------------------------------
        public static string Rows
        {
            get
            {
                var sb = new StringBuilder();
                foreach (var org in Orgs())
                {
                    OrgState st = State(org.Id);
                    int stock = 0; foreach (Property p in s_Properties) if (p.OrgId == org.Id && !p.Seized) stock += p.Stock;
                    sb.Append("O|").Append(org.Id).Append('|').Append(CityText.Clean(org.Name)).Append('|').Append(CityText.Clean(org.Type)).Append('|')
                      .Append(st.Heat).Append('|').Append(st.Cash).Append('|').Append(stock).Append('|').Append(org.Members).Append('|')
                      .Append(st.Arrested).Append('|').Append(st.InterventionWeeks).Append('|').Append(st.Raided).Append('|')
                      .Append(org.Sellers).Append('|').Append(org.Recruiters).Append('|').Append(CityText.Clean(org.Territory)).Append('\n');
                    foreach (var kv in st.Control)
                        sb.Append("T|").Append(org.Id).Append('|').Append(CityText.Clean(kv.Key)).Append('|').Append(kv.Value).Append('\n');
                }
                foreach (Property p in s_Properties)
                    sb.Append("P|").Append(p.Id).Append('|').Append(p.OrgId).Append('|').Append(p.Kind).Append('|')
                      .Append(CityText.Clean(p.Name)).Append('|').Append(CityText.Clean(p.Area)).Append('|').Append((int)p.X).Append('|').Append((int)p.Z).Append('|')
                      .Append(p.Stock).Append('|').Append(p.Capacity).Append('|').Append(p.Cash).Append('|').Append(p.Discovered ? 1 : 0).Append('|')
                      .Append(p.Intel).Append('|').Append(p.Seized ? 1 : 0).Append('\n');
                sb.Append("S|").Append(s_Seized).Append('|').Append(s_CashSeized).Append('|').Append(s_TotalArrests).Append('|').Append(ViolenceOffset).Append('\n');
                foreach (string e in s_Events) sb.Append("E|").Append(e).Append('\n');
                return sb.ToString();
            }
        }
    }
}
