using System.Collections.Generic;
using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    public partial class DjEventSystem : GameSystemBase
    {
        private const float kEventTime = 21f / 24f;
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;
        private EntityQuery m_CompanyQuery;
        private readonly List<Entity> m_Bars = new List<Entity>();
        private float m_PreviousTime = -1f;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CandidateQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            var settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.DjEventsEnabled) return;
            float now = m_TimeSystem.normalizedTime;
            bool reachedEventTime = m_PreviousTime >= 0f && m_PreviousTime < kEventTime && now >= kEventTime;
            m_PreviousTime = now;
            if (reachedEventTime) RunEvening(settings);
        }

        private void RunEvening(Setting settings)
        {
            uint frame = m_SimulationSystem.frameIndex;
            var random = new Random(math.max(1u, frame * 2246822519u));
            int population = m_PopulationQuery.CalculateEntityCount();
            int cap = PopulationCap.MaxAttendees(population, settings.MaxAttendancePercent);
            uint baseOuting = OutingStarter.FramesPerDay / 8u;
            uint outing = baseOuting + (uint)(baseOuting * (settings.StayLongerPercent / 100f));
            using NativeArray<Entity> candidates = m_CandidateQuery.ToEntityArray(Allocator.Temp);
            if (random.NextInt(100) < settings.DjEventChancePercent)
            {
                BarFinder.CollectDIYMusicVenueBuildings(EntityManager, m_CompanyQuery, m_Bars);
                int events = math.min(settings.DjEventsPerNight, m_Bars.Count);
                for (int i = 0; i < events; i++)
                {
                    int remaining = AttendanceLedger.Remaining(cap, frame);
                    if (remaining <= 0) break;
                    int index = random.NextInt(m_Bars.Count);
                    Entity bar = m_Bars[index];
                    m_Bars.RemoveAt(index);
                    int wanted = math.max(1, (population * random.NextInt(2, 11)) / 100);
                    int started = OutingStarter.Start(EntityManager, candidates, math.min(wanted, remaining), ref random, frame, outing, bar);
                    AttendanceLedger.Add(started, frame + outing);
                    DjNames.MusicAct act = DjNames.PickMusicAct(ref random);
                    string barName = GetBarName(bar);
                    DjAnnouncement.EnqueueMusicAct(act.Name, act.Genre, act.Billing, barName, started);
                    ActiveEvents.Add($"{act.Name} · {act.Billing}", barName, started, frame + outing, bar);
                    ActiveEvents.RecordDjArrival();
                    CityBuzzFeed.Add("Live music", act.Name, barName, $"{act.Genre} show started with {started:N0} sims in the crowd.", frame);
                    if (random.NextInt(100) < 75)
                        FamousSimRoster.PublishShowTweet(EntityManager, ref random, barName, $"I'm heading to {barName} for {act.Name}'s {act.Genre} gig tonight. Come see the show!", frame, started);
                    Mod.log.Info($"Live music event: {act.Name} ({act.Genre}) at {barName}, {started} sims (cap {cap}, population {population}).");
                }
            }

            if (settings.MajorActsEnabled && random.NextInt(100) < settings.MajorActChancePercent)
                StartMajorAct(ref random, frame, population, cap, outing, candidates);
        }

        private void StartMajorAct(ref Random random, uint frame, int population, int cap, uint outing, NativeArray<Entity> candidates)
        {
            BarFinder.CollectBarBuildings(EntityManager, m_CompanyQuery, m_Bars);
            if (m_Bars.Count == 0) return;
            int remaining = AttendanceLedger.Remaining(cap, frame);
            if (remaining <= 0) return;

            Entity venue = m_Bars[random.NextInt(m_Bars.Count)];
            DjNames.MusicAct act = PickMajorAct(ref random);
            int percent = random.NextInt(18, 36);
            int wanted = math.max(1, (population * percent) / 100);
            int started = OutingStarter.Start(EntityManager, candidates, math.min(wanted, remaining), ref random, frame, outing, venue);
            AttendanceLedger.Add(started, frame + outing);
            string venueName = GetBarName(venue);
            uint tourismDuration = OutingStarter.FramesPerDay * 3u;
            MajorActTourismSystem.Start(frame, tourismDuration);
            DjAnnouncement.EnqueueMusicAct(act.Name, act.Genre, act.Billing, venueName, started);
            ActiveEvents.Add($"{act.Name} · Major touring act", venueName, started, frame + outing, venue);
            ActiveEvents.RecordDjArrival();
            CityBuzzFeed.Add("Major live show", act.Name, venueName,
                $"Major touring act {act.Name} brought {started:N0} local sims to the show. The game's tourism system is boosted for three in-game days.", frame);
            FamousSimRoster.PublishShowTweet(EntityManager, ref random, venueName,
                $"Big night at {venueName}: {act.Name} are in town. The show has boosted city tourism attraction for three days!", frame, started);
            Mod.log.Info($"Major touring act {act.Name} ({act.Genre}) at {venueName}; {started} local sims attending, tourism boost lasts three in-game days.");
        }

        private static DjNames.MusicAct PickMajorAct(ref Random random)
        {
            switch (random.NextInt(8))
            {
                case 0: return new DjNames.MusicAct { Name = "The Neon Atlas", Genre = "stadium indie rock", Billing = "Major touring act" };
                case 1: return new DjNames.MusicAct { Name = "Solar Arcade", Genre = "arena pop", Billing = "Major touring act" };
                case 2: return new DjNames.MusicAct { Name = "Violet Static", Genre = "electronic", Billing = "Major touring act" };
                case 3: return new DjNames.MusicAct { Name = "Gold District", Genre = "hip-hop", Billing = "Major touring act" };
                case 4: return new DjNames.MusicAct { Name = "Wild Meridian", Genre = "alternative rock", Billing = "Major touring act" };
                case 5: return new DjNames.MusicAct { Name = "Nova Avenue", Genre = "dance pop", Billing = "Major touring act" };
                case 6: return new DjNames.MusicAct { Name = "Weekend Riot", Genre = "punk rock", Billing = "Major touring act" };
                default: return new DjNames.MusicAct { Name = "The Satellites", Genre = "pop rock", Billing = "Major touring act" };
            }
        }

        private string GetBarName(Entity building)
        {
            Entity company = BarFinder.FindBarCompany(EntityManager, m_CompanyQuery, building);
            Entity target = company != Entity.Null ? company : building;
            string name = m_NameSystem.GetRenderedLabelName(target);
            return string.IsNullOrEmpty(name) ? "a local bar" : name;
        }
    }
}
