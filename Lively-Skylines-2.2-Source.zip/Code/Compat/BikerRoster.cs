using System.Collections.Generic;
using Game.UI;
using Unity.Mathematics;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Session roster of biker groups and the real city residents they ride with.</summary>
    public static class BikerRoster
    {
        public sealed class Group
        {
            public string Name;
            public string Area;
            public Entity Home;
            public readonly List<Entity> Riders = new List<Entity>();
            public uint LastRideFrame;
        }

        private static readonly List<Group> s_Groups = new List<Group>();
        private static readonly string[] s_Names = { "Iron Vultures", "Chrome Wolves", "Midnight Pistons", "Blacktop Riders", "Copper Skulls", "Night Owls MC", "Road Hounds", "Ashland Riders" };
        public static int Count => s_Groups.Count;
        public static Group Get(int index) => index >= 0 && index < s_Groups.Count ? s_Groups[index] : null;

        public static void EnsureInitialGroups()
        {
            while (s_Groups.Count < 2)
                s_Groups.Add(new Group { Name = s_Names[s_Groups.Count] });
        }

        public static void EnsureStartingTurfs(EntityManager entityManager, EntityQuery buildingQuery, NameSystem nameSystem, ref Random random)
        {
            EnsureInitialGroups();
            bool needsAssignment = false;
            foreach (Group group in s_Groups)
                if (group.Home == Entity.Null || !entityManager.Exists(group.Home) || string.IsNullOrWhiteSpace(group.Area)) { needsAssignment = true; break; }
            if (!needsAssignment) return;
            using (var buildings = buildingQuery.ToEntityArray(Unity.Collections.Allocator.Temp))
            {
                var candidates = new List<Entity>(buildings.Length);
                var areas = new List<string>(buildings.Length);
                foreach (Entity building in buildings)
                {
                    if (!entityManager.HasComponent<Game.Objects.Transform>(building)) continue;
                    string area = CrimeAreaSystem.GetDistrictName(entityManager, nameSystem, building);
                    candidates.Add(building);
                    areas.Add(string.IsNullOrWhiteSpace(area) ? "Citywide" : area);
                }
                if (candidates.Count == 0) return;
                for (int i = 0; i < s_Groups.Count; i++)
                {
                    Group group = s_Groups[i];
                    if (group.Home != Entity.Null && entityManager.Exists(group.Home) && !string.IsNullOrWhiteSpace(group.Area)) continue;
                    int index = i % candidates.Count;
                    group.Home = candidates[index];
                    group.Area = areas[index];
                }
            }
        }

        public static Group AddGroup(string area, Entity home, List<Entity> riders, uint frame)
        {
            if (s_Groups.Count >= 5) return null;
            EnsureInitialGroups();
            Group group = new Group { Name = s_Names[s_Groups.Count % s_Names.Length], Area = area, Home = home, LastRideFrame = frame };
            foreach (Entity rider in riders) group.Riders.Add(rider);
            s_Groups.Add(group);
            return group;
        }

        public static void SetRiders(Group group, List<Entity> riders, string area, Entity home, uint frame)
        {
            if (group == null) return;
            group.Riders.Clear();
            foreach (Entity rider in riders) group.Riders.Add(rider);
            group.Area = area;
            group.Home = home;
            group.LastRideFrame = frame;
        }

        public static List<Entity> GetActiveRiders(Group group, EntityManager entityManager)
        {
            var result = new List<Entity>();
            if (group == null) return result;
            foreach (Entity rider in group.Riders)
                if (entityManager.Exists(rider) && entityManager.HasComponent<Game.Citizens.Citizen>(rider)) result.Add(rider);
            return result;
        }
    }
}
