using System.Collections.Generic;
using Colossal.UI.Binding;
using Game.UI;
using Unity.Entities;

namespace BarRush
{
    public static class DjAnnouncement
    {
        private struct Item { public string Dj; public string Bar; public int Attendees; public string Kind; public string Message; public bool IsScandal; public bool CanResolveScandal; public Entity ScandalBuilding; public Entity Target; public string ChirpSender; }
        private static readonly Queue<Item> s_Queue = new Queue<Item>();
        public static bool Visible { get; private set; }
        public static string DjName { get; private set; } = "";
        public static string BarName { get; private set; } = "";
        public static int Attendees { get; private set; }
        public static string Kind { get; private set; } = "DJ set";
        public static string Message { get; private set; } = "";
        public static float ShownAt { get; private set; }
        public static bool IsScandal { get; private set; }
        public static bool CanResolveScandal { get; private set; }
        public static Entity ScandalBuilding { get; private set; }

        public static void Enqueue(string dj, string bar, int attendees) => s_Queue.Enqueue(new Item { Dj = dj, Bar = bar, Attendees = attendees, Kind = "DJ set", Message = "" });
        public static void EnqueueMusicAct(string name, string genre, string billing, string bar, int attendees)
        {
            // Scheduled performances stay in the Events dashboard and city feed; do not interrupt gameplay.
        }
        public static void EnqueueUnderageSalesScandal(string bar, Entity building, bool discovered)
        {
            s_Queue.Enqueue(new Item
            {
                Dj = discovered ? "Underage sales reported" : "Unnoticed underage sale",
                Bar = bar,
                Kind = discovered ? "Public scandal" : "Unreported incident",
                Message = discovered
                    ? $"Reports say {bar} sold alcohol to underage customers. The city can close the venue for $75,000 or cover up the case for $150,000."
                    : $"A bar sold alcohol to underage customers, but the incident went unnoticed by the public.",
                IsScandal = true,
                CanResolveScandal = discovered,
                ScandalBuilding = building,
            });
        }
        public static void SetScandalResolved(string message)
        {
            Message = message;
            CanResolveScandal = false;
            IsScandal = false;
        }
        public static void SetScandalActionError(string message) => Message = message;
        public static void EnqueueFamousVisitor(string name, string bar, string brand, bool positive)
        {
            string message = positive
                ? $"{name} is promoting {brand} after a visit to {bar}."
                : $"{name} says {brand} at {bar} did not meet their standards. No promotion this time.";
            s_Queue.Enqueue(new Item
            {
                Dj = name,
                Bar = bar,
                Attendees = 0,
                Kind = positive ? "Famous guest · promotion" : "Famous guest · critical review",
                Message = message,
            });
        }
        public static void EnqueueCityEvent(string title, string park, int attendees)
        {
            // Planned events are visible in the calendar and feed without a top-screen alert.
        }
        public static void EnqueueCrimeReport(string place, string message, string crimeType = "Crime")
        {
            if (crimeType == "Shooting") return;
            s_Queue.Enqueue(new Item
            {
                Dj = $"{crimeType} reported",
                Bar = place,
                Kind = $"Crime report · {crimeType}",
                Message = message,
                IsScandal = true,
            });
        }
        public static void EnqueueFineNotice(string place, string message)
        {
            if (message != null && (message.IndexOf("shooting", System.StringComparison.OrdinalIgnoreCase) >= 0
                || message.IndexOf("stabbing", System.StringComparison.OrdinalIgnoreCase) >= 0)) return;
            s_Queue.Enqueue(new Item
            {
                Dj = "City fined",
                Bar = place,
                Kind = "City fine",
                Message = message,
                IsScandal = true,
            });
        }
        public static void EnqueueBikerGang(string name, string place, int attendees, int bikes)
        {
            s_Queue.Enqueue(new Item
            {
                Dj = $"🏍 {name}",
                Bar = place,
                Attendees = attendees,
                Kind = "Motorbike meetup",
                Message = $"A Lively Skylines biker meetup is reported at {place}. {bikes} motorbikes reported; residents are gathering nearby.",
            });
        }
        public static void EnqueueTweet(string author, string place, string message, int likes, int dislikes)
        {
            s_Queue.Enqueue(new Item
            {
                Dj = author,
                Bar = place,
                Kind = "New tweet",
                Message = $"{message}\n{place} · {likes:N0} likes · {dislikes:N0} dislikes",
                ChirpSender = author,
            });
        }
        public static void EnqueueCityUpdate(string kind, string author, string place, string message, Entity target = default(Entity))
        {
            s_Queue.Enqueue(new Item
            {
                Dj = author,
                Bar = place,
                Kind = kind,
                Message = message,
                IsScandal = kind == "Crime" || kind == "Public health",
                Target = target,
                ChirpSender = "Lively Skylines",
            });
        }
        public static void TryAdvance(float now)
        {
            if (Visible || s_Queue.Count == 0) return;
            Item item = s_Queue.Dequeue();
            DjName = item.Dj; BarName = item.Bar; Attendees = item.Attendees; Kind = item.Kind; Message = item.Message; ShownAt = now; Visible = true;
            IsScandal = item.IsScandal; CanResolveScandal = item.CanResolveScandal; ScandalBuilding = item.ScandalBuilding;
            string chirpText = string.IsNullOrWhiteSpace(item.Message)
                ? $"{item.Kind}: {item.Dj} is playing at {item.Bar}."
                : $"{item.Kind}: {item.Message}";
            if (item.Attendees > 0) chirpText += $" Estimated attendance: {item.Attendees:N0} sims.";
            CustomChirpsBridge.Post(chirpText, item.Target, string.IsNullOrWhiteSpace(item.ChirpSender) ? "Lively Skylines" : item.ChirpSender);
        }
        public static void Dismiss() => Visible = false;
    }

    public partial class DjAnnouncementUISystem : UISystemBase
    {
        private const string kGroup = "BarRush";
        private const float kVisibleSeconds = 12f;
        protected override void OnCreate()
        {
            base.OnCreate();
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "visible", () => DjAnnouncement.Visible));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "djName", () => DjAnnouncement.DjName));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "barName", () => DjAnnouncement.BarName));
            AddUpdateBinding(new GetterValueBinding<int>(kGroup, "attendees", () => DjAnnouncement.Attendees));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "announcementKind", () => DjAnnouncement.Kind));
            AddUpdateBinding(new GetterValueBinding<string>(kGroup, "announcementMessage", () => DjAnnouncement.Message));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "scandalCanResolve", () => DjAnnouncement.CanResolveScandal));
            AddUpdateBinding(new GetterValueBinding<bool>(kGroup, "announcementIsScandal", () => DjAnnouncement.IsScandal));
            AddBinding(new TriggerBinding(kGroup, "dismiss", DjAnnouncement.Dismiss));
            AddBinding(new TriggerBinding(kGroup, "closeScandalVenue", () => UnderageSalesSystem.QueueResolution(DjAnnouncement.ScandalBuilding, true)));
            AddBinding(new TriggerBinding(kGroup, "coverUpScandal", () => UnderageSalesSystem.QueueResolution(DjAnnouncement.ScandalBuilding, false)));
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();
            float now = UnityEngine.Time.realtimeSinceStartup;
            if (DjAnnouncement.Visible && !DjAnnouncement.CanResolveScandal && now - DjAnnouncement.ShownAt > kVisibleSeconds) DjAnnouncement.Dismiss();
            DjAnnouncement.TryAdvance(now);
        }
    }
}
