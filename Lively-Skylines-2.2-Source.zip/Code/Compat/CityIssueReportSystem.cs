using System.Collections.Generic;
using Game;
using Game.Buildings;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Occasional non-graphic community issue and outreach stories for the city feed and optional Custom Chirps.</summary>
    public partial class CityIssueReportSystem : GameSystemBase
    {
        private const float kReportTime = 21f / 24f;
        private const uint kCooldown = OutingStarter.FramesPerDay * 2u;
        private static readonly string[] s_Issues = { "Sex-work outreach", "Noise complaint", "Public intoxication", "Street-level drug concern", "Civic protest" };
        private EntityQuery m_BuildingQuery;
        private EntityQuery m_CitizenQuery;
        private SimulationSystem m_SimulationSystem;
        private TimeSystem m_TimeSystem;
        private NameSystem m_NameSystem;
        private float m_PreviousTime = -1f;
        private uint m_LastReportFrame;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_BuildingQuery = GetEntityQuery(ComponentType.ReadOnly<Building>(), ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_TimeSystem = World.GetOrCreateSystemManaged<TimeSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.CityIssueReportsEnabled || !settings.CrimeReportsEnabled) return;
            float now = m_TimeSystem.normalizedTime;
            bool reached = m_PreviousTime >= 0f && m_PreviousTime < kReportTime && now >= kReportTime;
            m_PreviousTime = now;
            if (!reached) return;

            uint frame = m_SimulationSystem.frameIndex;
            if (m_LastReportFrame != 0 && frame >= m_LastReportFrame && frame - m_LastReportFrame < kCooldown) return;
            var random = new Random(math.max(1u, frame * 668265263u + 374761393u));
            bool grievanceDriven = PublicReactionLedger.Anger >= 15;
            if (!grievanceDriven && random.NextInt(100) >= math.clamp(settings.CityIssueReportChancePercent, 0, 40)) return;

            using NativeArray<Entity> buildings = m_BuildingQuery.ToEntityArray(Allocator.Temp);
            var named = new List<Entity>();
            foreach (Entity building in buildings)
                if (!string.IsNullOrWhiteSpace(m_NameSystem.GetRenderedLabelName(building))) named.Add(building);
            if (named.Count == 0) return;

            string issue = s_Issues[random.NextInt(s_Issues.Length)];
            if (grievanceDriven) issue = "Civic protest";
            Entity location = issue == "Civic protest"
                ? FindCivicBuilding(named, random)
                : named[random.NextInt(named.Count)];
            string place = m_NameSystem.GetRenderedLabelName(location);
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, location);
            int turnout = 0;
            if (issue == "Civic protest")
            {
                using NativeArray<Entity> candidates = m_CitizenQuery.ToEntityArray(Allocator.Temp);
                int population = m_CitizenQuery.CalculateEntityCount();
                int cap = PopulationCap.MaxAttendees(population, settings.MaxAttendancePercent);
                int wanted = math.min(random.NextInt(30, 121), cap);
                uint duration = math.max(1u, OutingStarter.FramesPerDay / 12u);
                turnout = wanted > 0 && candidates.Length > 0
                    ? OutingStarter.Start(EntityManager, candidates, wanted, ref random, frame, duration, location)
                    : 0;
                AttendanceLedger.Add(turnout, frame + duration);
                ProtestLocationLedger.Record(EntityManager, location, place, area, frame, turnout);
                PublicReactionLedger.ProtestOccurred();
            }
            string response = issue == "Civic protest"
                ? $"About {turnout} residents gathered outside {place}. The peaceful civic gathering is informational and is not classified as a crime."
                : issue == "Sex-work outreach"
                ? "Outreach services were notified; no resident is identified."
                : issue == "Public intoxication"
                    ? "A community support response was requested."
                    : issue == "Noise complaint"
                        ? "A neighborhood noise concern was reported."
                        : "A prevention and public-health response was requested.";
            string message = issue == "Civic protest"
                ? $"Fictional Lively Skylines civic alert: a peaceful protest is gathering outside {place}, {area}. Grievance: {PublicReactionLedger.LatestCause}. {response}"
                : $"Fictional Lively Skylines community report: {issue.ToLowerInvariant()} near {place}, {area}. {response}";
            string postKind = issue == "Civic protest" ? "Protest" : "Community update";
            string postAuthor = issue == "Civic protest" ? "Civic desk" : "City outreach";
            CityBuzzFeed.Add(postKind, postAuthor, $"{place} · {area}", message, frame);
            if (settings.FamousPeopleEnabled && random.NextInt(100) < 55)
            {
                FamousSimRoster.EnsureResidents(EntityManager, m_CitizenQuery, m_NameSystem, ref random);
                if (FamousSimRoster.TryPick(EntityManager, ref random, out Entity resident, out string residentName))
                {
                    string reaction = issue == "Civic protest"
                        ? $"A peaceful civic protest is happening near {place}. I hope people can make their views heard safely."
                        : issue == "Sex-work outreach"
                        ? $"I hope outreach workers can connect anyone near {place} who needs it with support and safe services."
                        : issue == "Public intoxication"
                            ? $"There was a public support call near {place}. I hope everyone gets home safely."
                            : $"Neighbors are asking for help with a community concern near {place}. Hope it gets sorted out soon.";
                    CityBuzzFeed.AddSocial("Tweet", residentName, $"{place} · {area}", reaction, frame, random.NextInt(20, 6500), random.NextInt(2, 1200), Entity.Null);
                    FamousSimRoster.RecordPost(resident);
                }
            }
            m_LastReportFrame = frame;
            Mod.log.Info($"Lively Skylines fictional {issue} report near {place} ({area}).");
        }

        private Entity FindCivicBuilding(List<Entity> buildings, Random random)
        {
            // Prefer buildings whose rendered address/name signals a civic or government role.
            // If a city has no named government building, use a named public building as a safe fallback.
            var civic = new List<Entity>();
            var fallback = new List<Entity>();
            foreach (Entity building in buildings)
            {
                string name = m_NameSystem.GetRenderedLabelName(building);
                if (string.IsNullOrWhiteSpace(name)) continue;
                fallback.Add(building);
                string lower = name.ToLowerInvariant();
                if (lower.Contains("city hall") || lower.Contains("town hall") || lower.Contains("administration")
                    || lower.Contains("government") || lower.Contains("civic") || lower.Contains("courthouse")
                    || lower.Contains("municipal") || lower.Contains("parliament")) civic.Add(building);
            }
            List<Entity> choices = civic.Count > 0 ? civic : fallback;
            return choices.Count > 0 ? choices[random.NextInt(choices.Count)] : buildings[random.NextInt(buildings.Count)];
        }
    }
}
