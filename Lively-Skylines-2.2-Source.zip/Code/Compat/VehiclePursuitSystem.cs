using System.Collections.Generic;
using System.Globalization;
using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Suspects who just committed a reported crime and will try to get away.</summary>
    public static class GetawayQueue
    {
        public sealed class Getaway { public Entity Scene; public string Area; public string Crime; public string Suspect; public bool PoliceNearby; public uint Frame; }
        private static readonly List<Getaway> s_Pending = new List<Getaway>();
        public static List<Getaway> Pending => s_Pending;

        public static void Report(Entity scene, string area, string crime, string suspect, bool policeNearby, uint frame)
        {
            if (string.IsNullOrEmpty(crime)) return;
            string c = crime.ToLowerInvariant();
            // Pursuits, traffic checks and police searches are already police actions, not new getaways.
            if (c.Contains("pursuit") || c.Contains("alpr") || c.Contains("police search") || c.Contains("health alert")) return;
            if (s_Pending.Count >= 12) s_Pending.RemoveAt(0);
            s_Pending.Add(new Getaway { Scene = scene, Area = area, Crime = crime, Suspect = suspect, PoliceNearby = policeNearby, Frame = frame });
        }
    }

    /// <summary>Session-only traffic pursuit reports anchored to resident-controlled moving cars.</summary>
    public static class VehiclePursuitLedger
    {
        public const uint FiveMinuteWindow = OutingStarter.FramesPerDay / 288u;
        private const uint kOutcomeDisplayFrames = OutingStarter.FramesPerDay / 12u;
        private static string s_LastOutcome = string.Empty;
        private static uint s_LastOutcomeUntil;

        public sealed class Pursuit
        {
            public Entity Incident;
            public Entity Vehicle;
            public Entity Driver;
            public Entity PoliceRequest;
            public bool OwnsCrimeProducer;
            public bool WillPullOver;
            public bool HasPulledOver;
            public bool IsPullingOver;
            public uint PullOverEndFrame;
            public float ResumeSpeed;
            public string DriverName;
            public string Area;
            public string Reason;
            public string Place;
            public uint StartedFrame;
            public uint EndFrame;
            public uint NextArrestCheckFrame;
            public bool PoliceNearby;
            public int PoliceCoverage;
            public bool WasArrested;
            public int Id;
            public string Crime = "Criminal record";
            public bool OnFoot;
            public int Backup;
            public bool Spikes;
            public bool CalledOff;
            public float X, Z;
        }

        private static int s_NextId = 1;
        public static int NextId() => s_NextId++;
        private static readonly List<string> s_Recent = new List<string>();
        private static readonly Queue<(int id, int action)> s_Actions = new Queue<(int, int)>();
        public static void EnqueueAction(int id, int action) { if (s_Actions.Count < 20) s_Actions.Enqueue((id, action)); }
        public static bool TryDequeueAction(out int id, out int action)
        {
            if (s_Actions.Count > 0) { var a = s_Actions.Dequeue(); id = a.id; action = a.action; return true; }
            id = 0; action = 0; return false;
        }
        public static int TotalArrests { get; private set; }
        public static int TotalEscapes { get; private set; }

        public static void AddRecent(Pursuit p, int coverage, bool arrested, uint frame)
        {
            if (arrested) TotalArrests++; else TotalEscapes++;
            s_Recent.Insert(0, string.Join("~", Clean(p.DriverName), Clean(p.Area), Clean(p.Crime), arrested ? "1" : "0", coverage.ToString(CultureInfo.InvariantCulture), p.OnFoot ? "1" : "0", p.CalledOff ? "1" : "0"));
            if (s_Recent.Count > 8) s_Recent.RemoveAt(s_Recent.Count - 1);
        }

        public static int Coverage(Pursuit p) => math.min(95, (p.PoliceNearby ? 70 : 15) + p.Backup * 20);

        /// <summary>Rows: A|id|driver|area|crime|remaining|duration|coverage|nearby|pulling|pulled|backup|spikes|foot|x|z ; R|recent ; S|arrests|escapes|pending.</summary>
        public static string DetailRows(uint frame, EntityManager em)
        {
            var sb = new System.Text.StringBuilder();
            foreach (Pursuit p in s_Active)
            {
                float x = p.X, z = p.Z;
                if (p.Vehicle != Entity.Null && em.Exists(p.Vehicle) && em.HasComponent<Game.Objects.Transform>(p.Vehicle))
                { var pos = em.GetComponentData<Game.Objects.Transform>(p.Vehicle).m_Position; x = pos.x; z = pos.z; }
                uint remaining = frame < p.EndFrame ? p.EndFrame - frame : 0u;
                sb.Append("A|").Append(p.Id).Append('|').Append(Clean(p.DriverName)).Append('|').Append(Clean(p.Area)).Append('|').Append(Clean(p.Crime)).Append('|')
                  .Append(remaining).Append('|').Append(p.EndFrame - p.StartedFrame).Append('|').Append(Coverage(p)).Append('|').Append(p.PoliceNearby ? 1 : 0).Append('|')
                  .Append(p.IsPullingOver ? 1 : 0).Append('|').Append(p.HasPulledOver ? 1 : 0).Append('|').Append(p.Backup).Append('|').Append(p.Spikes ? 1 : 0).Append('|')
                  .Append(p.OnFoot ? 1 : 0).Append('|').Append((int)x).Append('|').Append((int)z).Append('\n');
            }
            foreach (string r in s_Recent) sb.Append("R|").Append(r).Append('\n');
            sb.Append("S|").Append(TotalArrests).Append('|').Append(TotalEscapes).Append('|').Append(GetawayQueue.Pending.Count).Append('\n');
            return sb.ToString();
        }

        private static readonly List<Pursuit> s_Active = new List<Pursuit>();
        public static int ActiveCount => s_Active.Count;
        public static bool HasActive => s_Active.Count > 0;
        public static List<Pursuit> Active => s_Active;

        public static string OverlayData(uint frame)
        {
            if (s_Active.Count > 0)
            {
                Pursuit pursuit = s_Active[s_Active.Count - 1];
                uint remaining = frame < pursuit.EndFrame ? pursuit.EndFrame - frame : 0u;
                uint elapsed = frame >= pursuit.StartedFrame ? frame - pursuit.StartedFrame : 0u;
                return string.Join("|", "active", Clean(pursuit.DriverName), Clean(pursuit.Area),
                    remaining.ToString(CultureInfo.InvariantCulture), elapsed.ToString(CultureInfo.InvariantCulture),
                    pursuit.PoliceCoverage.ToString(CultureInfo.InvariantCulture), pursuit.PoliceNearby ? "1" : "0",
                    pursuit.WillPullOver ? "1" : "0", pursuit.HasPulledOver ? "1" : "0", pursuit.IsPullingOver ? "1" : "0");
            }
            return frame < s_LastOutcomeUntil ? s_LastOutcome : string.Empty;
        }

        public static void SetOutcome(string driver, string area, int coverage, bool arrested, uint frame)
        {
            s_LastOutcomeUntil = frame + kOutcomeDisplayFrames;
            s_LastOutcome = string.Join("|", "result", Clean(driver), Clean(area),
                coverage.ToString(CultureInfo.InvariantCulture), arrested ? "1" : "0",
                s_LastOutcomeUntil.ToString(CultureInfo.InvariantCulture));
        }

        public static void Add(Pursuit pursuit) => s_Active.Add(pursuit);
        public static void Remove(Pursuit pursuit) => s_Active.Remove(pursuit);

        public static void AppendMapRows(System.Text.StringBuilder rows, EntityManager entityManager, uint frame)
        {
            foreach (Pursuit pursuit in s_Active)
            {
                if (frame >= pursuit.EndFrame || pursuit.Vehicle == Entity.Null || !entityManager.Exists(pursuit.Vehicle)
                    || !entityManager.HasComponent<Game.Objects.Transform>(pursuit.Vehicle)) continue;
                Unity.Mathematics.float3 position = entityManager.GetComponentData<Game.Objects.Transform>(pursuit.Vehicle).m_Position;
                rows.Append("J|").Append(position.x.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(position.z.ToString("0.##", CultureInfo.InvariantCulture)).Append('|')
                    .Append(Clean(pursuit.DriverName)).Append('|').Append(Clean(pursuit.Area)).Append('|')
                    .Append(Clean(pursuit.IsPullingOver ? "Driver pulling over" : pursuit.Reason)).AppendLine();
            }
        }

        private static string Clean(string value) => (value ?? "Unknown").Replace("|", "/").Replace("\r", " ").Replace("\n", " ");
    }

    [UpdateAfter(typeof(Game.Simulation.CarNavigationSystem))]
    [UpdateBefore(typeof(Game.Simulation.CarMoveSystem))]
    public partial class VehiclePursuitSystem : GameSystemBase
    {
        private const uint kArrestCheckInterval = OutingStarter.FramesPerDay / 1440u;
        private readonly Dictionary<Entity, Entity> m_LastPursuedCrimeByDriver = new Dictionary<Entity, Entity>();
        private EntityQuery m_MovingPersonalCarQuery;
        private SimulationSystem m_SimulationSystem;
        private NameSystem m_NameSystem;
        private Game.Simulation.CitySystem m_CitySystem;
        private Game.Rendering.CameraUpdateSystem m_CameraUpdateSystem;
        private uint m_LastFrame;
        private uint m_NextGetawayCheck;
        private const int kMaxChases = 4;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CitySystem = World.GetOrCreateSystemManaged<Game.Simulation.CitySystem>();
            m_CameraUpdateSystem = World.GetOrCreateSystemManaged<Game.Rendering.CameraUpdateSystem>();
            m_MovingPersonalCarQuery = GetEntityQuery(ComponentType.ReadOnly<Game.Vehicles.PersonalCar>(),
                ComponentType.ReadOnly<Game.Vehicles.Controller>(), ComponentType.ReadOnly<Game.Objects.Moving>(),
                ComponentType.ReadOnly<Game.Objects.Transform>(), ComponentType.Exclude<Game.Vehicles.ParkedCar>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(),
                ComponentType.Exclude<Game.Prefabs.PrefabData>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 1;

        protected override void OnUpdate()
        {
            uint frame = m_SimulationSystem.frameIndex;
            if (frame < m_LastFrame) m_LastPursuedCrimeByDriver.Clear();
            m_LastFrame = frame;
            UpdatePullOvers(frame);
            HandleActions(frame);
            ResolveFinishedPursuits(frame);

            Setting settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.CrimeReportsEnabled) return;

            // Every new native criminal record starts a pursuit as soon as its
            // offender is observed driving a moving personal car. Do not wait for
            // a nighttime roll or a random citywide chance.
            if (VehiclePursuitLedger.ActiveCount >= kMaxChases) return;

            var random = new Random(math.max(1u, frame * 747796405u + 2891336453u));
            if (frame >= m_NextGetawayCheck)
            {
                m_NextGetawayCheck = frame + 32u;
                if (StartGetaway(frame, ref random)) return;
            }
            StartPursuit(frame, ref random);
        }

        private bool ChargeCity(int amount)
        {
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<Game.City.PlayerMoney>(city)) return false;
            var money = EntityManager.GetComponentData<Game.City.PlayerMoney>(city);
            if (!money.m_Unlimited && money.money < amount) return false;
            if (!money.m_Unlimited) { money.Subtract(amount); EntityManager.SetComponentData(city, money); }
            return true;
        }

        private void HandleActions(uint frame)
        {
            while (VehiclePursuitLedger.TryDequeueAction(out int id, out int action))
            {
                VehiclePursuitLedger.Pursuit p = null;
                foreach (var a in VehiclePursuitLedger.Active) if (a.Id == id) { p = a; break; }
                if (p == null) continue;
                switch (action)
                {
                    case 1: // follow with the camera
                        float3 pos = new float3(p.X, 0f, p.Z);
                        if (p.Vehicle != Entity.Null && EntityManager.Exists(p.Vehicle) && EntityManager.HasComponent<Game.Objects.Transform>(p.Vehicle))
                            pos = EntityManager.GetComponentData<Game.Objects.Transform>(p.Vehicle).m_Position;
                        var cam = m_CameraUpdateSystem.gamePlayController;
                        if (cam != null) cam.pivot = new UnityEngine.Vector3(pos.x, pos.y, pos.z);
                        break;
                    case 2: // backup units
                        if (p.Backup >= 2) break;
                        if (!ChargeCity(5000)) { CityBuzzFeed.Add("Police pursuit", "Police dispatch", p.Area, "Backup units could not be funded ($5,000).", frame); break; }
                        p.Backup++;
                        CityBuzzFeed.Add("Police pursuit · Backup", "Live news desk · Crime Desk", p.Area, $"More police units joined the chase for {p.DriverName}. Coverage is now {VehiclePursuitLedger.Coverage(p)}%.", frame);
                        break;
                    case 3: // spike strips
                        if (p.Spikes || p.OnFoot) break;
                        if (!ChargeCity(3000)) { CityBuzzFeed.Add("Police pursuit", "Police dispatch", p.Area, "Spike strips could not be funded ($3,000).", frame); break; }
                        p.Spikes = true;
                        PublicReactionLedger.Add("Spike strips deployed on city streets", 1);
                        CityBuzzFeed.Add("Police pursuit · Spike strips", "Live news desk · Crime Desk", p.Area, $"Officers laid spike strips ahead of {p.DriverName}'s car.", frame);
                        break;
                    case 4: // call off
                        p.CalledOff = true; p.EndFrame = frame;
                        PublicReactionLedger.Add("Police called off a pursuit", -1);
                        break;
                }
            }
        }

        /// <summary>Turns a freshly reported crime into a getaway: the nearest moving car driver flees, or the suspect runs on foot.</summary>
        private bool StartGetaway(uint frame, ref Random random)
        {
            var pending = GetawayQueue.Pending;
            if (pending.Count == 0) return false;
            GetawayQueue.Getaway g = pending[0];
            float3 scene = float3.zero; bool hasScene = false;
            if (g.Scene != Entity.Null && EntityManager.Exists(g.Scene) && EntityManager.HasComponent<Game.Objects.Transform>(g.Scene))
            { scene = EntityManager.GetComponentData<Game.Objects.Transform>(g.Scene).m_Position; hasScene = true; }
            Entity bestCar = Entity.Null, bestDriver = Entity.Null; float best = 700f;
            if (hasScene)
            {
                using NativeArray<Entity> cars = m_MovingPersonalCarQuery.ToEntityArray(Allocator.Temp);
                foreach (Entity vehicle in cars)
                {
                    if (EntityManager.HasComponent<Game.Buildings.CrimeProducer>(vehicle)) continue;
                    Entity driver = EntityManager.GetComponentData<Game.Vehicles.Controller>(vehicle).m_Controller;
                    if (driver == Entity.Null || !EntityManager.Exists(driver) || !EntityManager.HasComponent<Citizen>(driver)) continue;
                    bool busy = false; foreach (var a in VehiclePursuitLedger.Active) if (a.Vehicle == vehicle) { busy = true; break; }
                    if (busy) continue;
                    float d = math.distance(EntityManager.GetComponentData<Game.Objects.Transform>(vehicle).m_Position, scene);
                    if (d < best) { best = d; bestCar = vehicle; bestDriver = driver; }
                }
            }
            if (bestCar != Entity.Null)
            {
                pending.RemoveAt(0);
                StartPursuitFor(frame, ref random, bestCar, bestDriver, g.Crime, $"Fled the scene of a {g.Crime.ToLowerInvariant()} in {g.Area}");
                return true;
            }
            // No getaway car nearby within an in-game hour: the suspect runs on foot.
            if (frame - g.Frame > OutingStarter.FramesPerDay / 24u || !hasScene)
            {
                pending.RemoveAt(0);
                var p = new VehiclePursuitLedger.Pursuit
                {
                    Id = VehiclePursuitLedger.NextId(), Incident = EntityManager.CreateEntity(), Vehicle = Entity.Null, Driver = Entity.Null,
                    DriverName = string.IsNullOrWhiteSpace(g.Suspect) || g.Suspect == "Unknown" || g.Suspect == "Unidentified" ? "Unidentified suspect" : g.Suspect,
                    Area = string.IsNullOrWhiteSpace(g.Area) ? "City streets" : g.Area, Crime = g.Crime, OnFoot = true,
                    Reason = $"Ran from the scene of a {g.Crime.ToLowerInvariant()}", Place = $"Foot chase · {g.Area}",
                    StartedFrame = frame, EndFrame = frame + math.max(1u, VehiclePursuitLedger.FiveMinuteWindow * 2u / 3u),
                    NextArrestCheckFrame = frame + math.max(1u, kArrestCheckInterval), PoliceNearby = g.PoliceNearby,
                    PoliceCoverage = g.PoliceNearby ? 70 : 15, X = scene.x, Z = scene.z,
                };
                VehiclePursuitLedger.Add(p);
                CityBuzzFeed.Add("Police foot chase · Active", "Breaking news · Crime Desk", p.Area, $"BREAKING: Officers are chasing a suspect on foot after a {g.Crime.ToLowerInvariant()} in {p.Area}.", frame);
                return true;
            }
            return false;
        }

        private void StartPursuit(uint frame, ref Random random)
        {
            StartNativePursuit(frame, ref random);
        }

        private void StartNativePursuit(uint frame, ref Random random)
        {
            var candidates = new List<(Entity Vehicle, Entity Driver, Entity CrimeEvent)>();
            using NativeArray<Entity> cars = m_MovingPersonalCarQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity vehicle in cars)
            {
                Entity driver = EntityManager.GetComponentData<Game.Vehicles.Controller>(vehicle).m_Controller;
                if (driver == Entity.Null || !EntityManager.Exists(driver) || !EntityManager.HasComponent<Citizen>(driver)) continue;
                // Only use a native criminal record as the reason for this stop.
                if (!EntityManager.HasComponent<Game.Citizens.Criminal>(driver)) continue;
                // The vanilla police patrol dispatcher only accepts CrimeProducer targets.
                // Do not overwrite a crime source managed by another native system.
                if (EntityManager.HasComponent<Game.Buildings.CrimeProducer>(vehicle)) continue;
                Game.Citizens.Criminal criminal = EntityManager.GetComponentData<Game.Citizens.Criminal>(driver);
                Game.Citizens.CriminalFlags flags = criminal.m_Flags;
                if ((flags & (Game.Citizens.CriminalFlags.Arrested | Game.Citizens.CriminalFlags.Sentenced | Game.Citizens.CriminalFlags.Prisoner)) != 0) continue;
                if (m_LastPursuedCrimeByDriver.TryGetValue(driver, out Entity lastEvent) && lastEvent == criminal.m_Event) continue;
                candidates.Add((vehicle, driver, criminal.m_Event));
            }
            if (candidates.Count == 0) return;

            (Entity Vehicle, Entity Driver, Entity CrimeEvent) selected = candidates[random.NextInt(candidates.Count)];
            foreach (var a in VehiclePursuitLedger.Active) if (a.Vehicle == selected.Vehicle) return;
            m_LastPursuedCrimeByDriver[selected.Driver] = selected.CrimeEvent;
            StartPursuitFor(frame, ref random, selected.Vehicle, selected.Driver, "Criminal record", "Active native criminal record observed in a moving vehicle");
        }

        private void StartPursuitFor(uint frame, ref Random random, Entity vehicleEntity, Entity driverEntity, string crime, string reasonText)
        {
            Unity.Mathematics.float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(vehicleEntity).m_Position;
            string driverName = m_NameSystem.GetRenderedLabelName(driverEntity);
            if (string.IsNullOrWhiteSpace(driverName)) driverName = "Unidentified driver";
            string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, vehicleEntity);
            if (string.IsNullOrWhiteSpace(area)) area = "City roads";
            Entity district = EntityManager.HasComponent<Game.Areas.CurrentDistrict>(vehicleEntity)
                ? EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(vehicleEntity).m_District : Entity.Null;
            bool policeNearby = CrimeAreaSystem.HasPoliceStation(district);
            string reason = reasonText;
            string place = $"Police pursuit · {area}";
            uint duration = math.max(1u, VehiclePursuitLedger.FiveMinuteWindow);
            Entity incident = EntityManager.CreateEntity();
            Entity policeRequest = Entity.Null;
            bool ownsCrimeProducer = false;
            if (policeNearby)
            {
                // PolicePatrolDispatchSystem validates that the target is a CrimeProducer
                // and only processes requests in its scheduled UpdateFrame bucket. Mark
                // this suspect vehicle as a short-lived target so the native police AI can
                // dispatch a real unit to its live position.
                EntityManager.AddComponentData(vehicleEntity, new Game.Buildings.CrimeProducer
                {
                    m_Crime = 100f,
                    m_PatrolRequest = Entity.Null,
                    m_DispatchIndex = 0
                });
                ownsCrimeProducer = true;

                EntityArchetype requestArchetype = EntityManager.CreateArchetype(
                    ComponentType.ReadWrite<Game.Simulation.ServiceRequest>(),
                    ComponentType.ReadWrite<Game.Simulation.PolicePatrolRequest>(),
                    ComponentType.ReadWrite<Game.Simulation.UpdateFrame>());
                policeRequest = EntityManager.CreateEntity(requestArchetype);
                uint dispatchBucket = ((frame >> 4) + 4u) & 31u;
                EntityManager.SetSharedComponentManaged(policeRequest, new Game.Simulation.UpdateFrame(dispatchBucket));
                EntityManager.SetComponentData(policeRequest, new Game.Simulation.ServiceRequest
                {
                    m_Flags = Game.Simulation.ServiceRequestFlags.SkipCooldown
                });
                EntityManager.SetComponentData(policeRequest, new Game.Simulation.PolicePatrolRequest
                {
                    m_Target = vehicleEntity,
                    m_Priority = 1f,
                    m_DispatchIndex = 0
                });
            }
            var pursuit = new VehiclePursuitLedger.Pursuit
            {
                Id = VehiclePursuitLedger.NextId(),
                Crime = crime,
                X = position.x,
                Z = position.z,
                Incident = incident,
                Vehicle = vehicleEntity,
                Driver = driverEntity,
                PoliceRequest = policeRequest,
                OwnsCrimeProducer = ownsCrimeProducer,
                DriverName = driverName,
                Area = area,
                Reason = reason,
                Place = place,
                StartedFrame = frame,
                EndFrame = frame + duration,
                NextArrestCheckFrame = frame + math.max(1u, kArrestCheckInterval),
                PoliceNearby = policeNearby,
                PoliceCoverage = policeNearby ? 70 : 15,
                WillPullOver = policeNearby && random.NextInt(100) < 38,
            };
            VehiclePursuitLedger.Add(pursuit);
            string response = policeNearby ? "Native dispatch requested a patrol to pursue the moving vehicle" : "No police station in the district · response delayed";
            CityBuzzFeed.Add("District police pursuit · Active", "Breaking news · Crime Desk", $"{area} · {position.x:0}, {position.z:0}",
                $"BREAKING: Police are pursuing {driverName} after an active criminal record was detected in traffic. {response}. Five-minute game-time pursuit is active; the vehicle and police units remain under native traffic simulation.", frame);
            PublicReactionLedger.Add("Reported nighttime police traffic stop", 2);
            Mod.log.Info($"Police pursuit started for active criminal record in {area}: driver {driverName}; native patrol request {(policeNearby ? "submitted" : "not submitted; no local station")}.");
        }

        private void UpdatePullOvers(uint frame)
        {
            foreach (VehiclePursuitLedger.Pursuit pursuit in VehiclePursuitLedger.Active)
            {
                Entity vehicle = pursuit.Vehicle;
                if (vehicle == Entity.Null || !EntityManager.Exists(vehicle)) continue;

                if (pursuit.IsPullingOver)
                {
                    if (frame < pursuit.PullOverEndFrame)
                    {
                        // Keep the suspect at a roadside parking-lane position during the
                        // brief stop, then restore the native navigation speed below.
                        if (EntityManager.HasComponent<Game.Vehicles.CarNavigation>(vehicle))
                        {
                            Game.Vehicles.CarNavigation navigation = EntityManager.GetComponentData<Game.Vehicles.CarNavigation>(vehicle);
                            navigation.m_MaxSpeed = 0f;
                            EntityManager.SetComponentData(vehicle, navigation);
                        }
                        if (EntityManager.HasComponent<Game.Objects.Moving>(vehicle))
                        {
                            Game.Objects.Moving moving = EntityManager.GetComponentData<Game.Objects.Moving>(vehicle);
                            moving.m_Velocity = float3.zero;
                            EntityManager.SetComponentData(vehicle, moving);
                        }
                        continue;
                    }

                    ReleasePullOver(pursuit);
                    pursuit.HasPulledOver = true;
                    CityBuzzFeed.Add("District police pursuit · Driver yielded", "Live news desk · Crime Desk", $"{pursuit.Place} · {pursuit.Area}",
                        $"LIVE: {pursuit.DriverName} yielded briefly at a roadside parking lane during the police pursuit. The driver has not yet been arrested; the pursuit timer continues.", frame);
                    continue;
                }

                if (!pursuit.WillPullOver || pursuit.HasPulledOver || !pursuit.PoliceNearby
                    || frame < pursuit.StartedFrame + OutingStarter.FramesPerDay / 60
                    || !EntityManager.HasComponent<Game.Vehicles.CarCurrentLane>(vehicle)
                    || !EntityManager.HasComponent<Game.Vehicles.CarNavigation>(vehicle)
                    || !EntityManager.HasComponent<Game.Objects.Moving>(vehicle)) continue;

                Game.Vehicles.CarCurrentLane lane = EntityManager.GetComponentData<Game.Vehicles.CarCurrentLane>(vehicle);
                // Only pull over when the car reaches a parking-space lane, so the stop
                // does not deliberately halt it in a live travel lane.
                if (lane.m_Lane == Entity.Null || lane.m_ChangeLane != Entity.Null
                    || !EntityManager.HasComponent<Game.Net.ParkingLane>(lane.m_Lane)) continue;

                Game.Vehicles.CarNavigation carNavigation = EntityManager.GetComponentData<Game.Vehicles.CarNavigation>(vehicle);
                pursuit.ResumeSpeed = carNavigation.m_MaxSpeed;
                pursuit.PullOverEndFrame = frame + (uint)randomPullOverDuration(frame, pursuit);
                pursuit.IsPullingOver = true;
                carNavigation.m_MaxSpeed = 0f;
                EntityManager.SetComponentData(vehicle, carNavigation);
                Game.Objects.Moving vehicleMotion = EntityManager.GetComponentData<Game.Objects.Moving>(vehicle);
                vehicleMotion.m_Velocity = float3.zero;
                EntityManager.SetComponentData(vehicle, vehicleMotion);
                CityBuzzFeed.Add("District police pursuit · Live update", "Live news desk · Crime Desk", $"{pursuit.Place} · {pursuit.Area}",
                    $"LIVE: The suspect car reached a roadside parking lane and pulled over briefly. Police response is in progress; the five-minute pursuit timer continues.", frame);
                Mod.log.Info($"Suspect {pursuit.DriverName} pulled over briefly in {pursuit.Area} during a police pursuit.");
            }
        }

        private static int randomPullOverDuration(uint frame, VehiclePursuitLedger.Pursuit pursuit)
        {
            var random = new Random(math.max(1u, frame ^ (uint)pursuit.Incident.Index * 3266489917u));
            return random.NextInt(180, 361);
        }

        private void ReleasePullOver(VehiclePursuitLedger.Pursuit pursuit)
        {
            Entity vehicle = pursuit.Vehicle;
            if (vehicle == Entity.Null || !EntityManager.Exists(vehicle))
            {
                pursuit.IsPullingOver = false;
                return;
            }

            if (EntityManager.HasComponent<Game.Vehicles.CarNavigation>(vehicle))
            {
                Game.Vehicles.CarNavigation navigation = EntityManager.GetComponentData<Game.Vehicles.CarNavigation>(vehicle);
                navigation.m_MaxSpeed = pursuit.ResumeSpeed;
                EntityManager.SetComponentData(vehicle, navigation);
            }
            if (EntityManager.HasComponent<Game.Objects.Moving>(vehicle))
            {
                Game.Objects.Moving moving = EntityManager.GetComponentData<Game.Objects.Moving>(vehicle);
                moving.m_Velocity = float3.zero;
                EntityManager.SetComponentData(vehicle, moving);
            }
            pursuit.IsPullingOver = false;
        }

        private void ResolveFinishedPursuits(uint frame)
        {
            for (int i = VehiclePursuitLedger.Active.Count - 1; i >= 0; i--)
            {
                VehiclePursuitLedger.Pursuit pursuit = VehiclePursuitLedger.Active[i];
                if (!pursuit.WasArrested && frame < pursuit.EndFrame)
                {
                    if (frame < pursuit.NextArrestCheckFrame) continue;
                    pursuit.NextArrestCheckFrame = frame + math.max(1u, kArrestCheckInterval);
                    int checkCoverage = GetPoliceCoverage(pursuit);
                    int arrestChanceThisCheck = math.clamp(checkCoverage * 18 / 100 + (pursuit.HasPulledOver ? 15 : 0) + (pursuit.Spikes ? 15 : 0) + (pursuit.OnFoot && pursuit.PoliceNearby ? 8 : 0), 2, 60);
                    var arrestRandom = new Random(math.max(1u, frame ^ (uint)pursuit.Incident.Index * 2246822519u));
                    if (arrestRandom.NextInt(100) < arrestChanceThisCheck) pursuit.WasArrested = true;
                    else continue;
                }
                if (!pursuit.WasArrested && frame < pursuit.EndFrame) continue;
                if (pursuit.IsPullingOver) ReleasePullOver(pursuit);
                int coverage = GetPoliceCoverage(pursuit);
                bool arrested = pursuit.WasArrested;
                string result = arrested
                    ? $"ARRESTED during the pursuit — police coverage was {coverage}%"
                    : pursuit.CalledOff ? "CALLED OFF — police ended the chase for public safety; the suspect remains at large"
                    : "ESCAPED — the suspect stayed at large for the full pursuit window";

                string response = pursuit.PoliceNearby ? $"Police coverage in {pursuit.Area}: {coverage}% (local police station available)" : $"Police coverage in {pursuit.Area}: {coverage}% (no local police station; response delayed)";
                string details = $"Traffic stop / pursuit report: {pursuit.Reason}. {result}. {response}. The arrest or escape is a mod-side modeled outcome; native criminal records are not changed.";
                CityCrimeLedger.Record(pursuit.Incident, pursuit.Vehicle, pursuit.Place, pursuit.Area, pursuit.PoliceNearby,
                    false, frame, details, "Vehicle pursuit", pursuit.DriverName, response);
                CityBuzzFeed.Add(arrested ? "District police pursuit · Arrested" : "District police pursuit · Escaped",
                    "Crime Desk · Police dispatch", $"{pursuit.Place} · {pursuit.Area}", details, frame);
                VehiclePursuitLedger.SetOutcome(pursuit.DriverName, pursuit.Area, coverage, arrested, frame);
                VehiclePursuitLedger.AddRecent(pursuit, coverage, arrested, frame);
                if (pursuit.PoliceRequest != Entity.Null && EntityManager.Exists(pursuit.PoliceRequest))
                    EntityManager.DestroyEntity(pursuit.PoliceRequest);
                if (pursuit.OwnsCrimeProducer && pursuit.Vehicle != Entity.Null && EntityManager.Exists(pursuit.Vehicle)
                    && EntityManager.HasComponent<Game.Buildings.CrimeProducer>(pursuit.Vehicle))
                    EntityManager.RemoveComponent<Game.Buildings.CrimeProducer>(pursuit.Vehicle);
                Mod.log.Info($"Vehicle pursuit ended in {pursuit.Area}: {result}; {pursuit.DriverName}.");
                VehiclePursuitLedger.Remove(pursuit);
            }
        }

        private static int GetPoliceCoverage(VehiclePursuitLedger.Pursuit pursuit) => VehiclePursuitLedger.Coverage(pursuit);
    }
}
