using System.Collections.Generic;
using Game.UI;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Session roster for fictional organizations participating in the abstract drug-market system.</summary>
    public static class DrugOrganizationLedger
    {
        public const int MaxPerType = 5;
        private const uint kGrowthInterval = OutingStarter.FramesPerDay * 14u;

        public sealed class Organization
        {
            public int Id;
            public string Type;
            public string Name;
            public int Leaders;
            public int Members;
            public int Recruiters;
            public int Sellers;
            public int Sales;
            public int WholesaleDeals;
            public int WholesaleUnits;
            public long WholesaleRevenue;
            public int Buyers;
            public long EstimatedProfit;
            public string Territory = "Unassigned turf";
            public string LastActivity = "No recent activity report";
            public Entity Location;
            public int LinkedCrimeReports;
            public readonly List<string> Products = new List<string>();
            public readonly List<string> Rivals = new List<string>();
            public readonly List<string> Allies = new List<string>();
        }

        private static readonly List<Organization> s_Organizations = new List<Organization>();
        private static uint s_NextGrowthFrame;
        private static readonly string[] s_GangNames = {
            "Eastside Kings", "Redline Crew", "North Market Union", "Harbor Point Crew", "Sierra Verde Network"
        };
        private static readonly string[] s_CartelNames = {
            "Pacific Gate Organization", "Sol del Norte", "Coastal Route Network", "Mesa Valley Group", "Sunset Corridor Cartel"
        };

        public static void EnsureInitialRoster(ref Random random, uint frame)
        {
            if (s_Organizations.Count == 0)
            {
                Add("Street gang", s_GangNames[0], 14, 2, 3);
                Add("Street gang", s_GangNames[1], 11, 2, 2);
                Add("Cartel", s_CartelNames[0], 26, 3, 5);
                s_NextGrowthFrame = frame + kGrowthInterval;
            }
        }

        /// <summary>Assigns every group an existing district/building as its initial, approximate turf.</summary>
        public static void EnsureStartingTurfs(EntityManager entityManager, EntityQuery buildingQuery, NameSystem nameSystem, ref Random random)
        {
            if (s_Organizations.Count == 0) return;
            bool needsAssignment = false;
            foreach (Organization organization in s_Organizations)
                if (organization.Location == Entity.Null || !entityManager.Exists(organization.Location)
                    || string.IsNullOrWhiteSpace(organization.Territory) || organization.Territory == "Unassigned turf") { needsAssignment = true; break; }
            if (!needsAssignment) return;
            using (var buildings = buildingQuery.ToEntityArray(Unity.Collections.Allocator.Temp))
            {
                var candidates = new List<Entity>(buildings.Length);
                var areas = new List<string>(buildings.Length);
                foreach (Entity building in buildings)
                {
                    if (!entityManager.HasComponent<Game.Objects.Transform>(building)) continue;
                    string area = CrimeAreaSystem.GetDistrictName(entityManager, nameSystem, building);
                    candidates.Add(building);
                    areas.Add(string.IsNullOrWhiteSpace(area) ? "Citywide" : area);
                }
                if (candidates.Count == 0) return;
                for (int i = 0; i < s_Organizations.Count; i++)
                {
                    Organization organization = s_Organizations[i];
                    if (organization.Location != Entity.Null && entityManager.Exists(organization.Location)
                        && !string.IsNullOrWhiteSpace(organization.Territory) && organization.Territory != "Unassigned turf") continue;
                    int start = random.NextInt(candidates.Count);
                    for (int offset = 0; offset < candidates.Count; offset++)
                    {
                        int index = (start + offset) % candidates.Count;
                        bool claimedBySameType = false;
                        foreach (Organization other in s_Organizations)
                            if (other != organization && other.Type == organization.Type && other.Location == candidates[index]) claimedBySameType = true;
                        if (claimedBySameType) continue;
                        organization.Location = candidates[index];
                        organization.Territory = areas[index];
                        organization.LastActivity = "Established starting turf · awaiting reports";
                        break;
                    }
                }
            }
        }

        /// <summary>Each two in-game weeks a group may form; existing groups also recruit and add sellers.</summary>
        public static string GrowIfDue(uint frame, ref Random random)
        {
            if (s_Organizations.Count == 0)
            {
                EnsureInitialRoster(ref random, frame);
                return null;
            }
            if (frame < s_NextGrowthFrame) return null;
            s_NextGrowthFrame = frame + kGrowthInterval;

            int gangs = Count("Street gang"), cartels = Count("Cartel");
            bool canGang = gangs < MaxPerType;
            bool canCartel = cartels < MaxPerType;
            string formed = null;
            if ((canGang || canCartel) && random.NextInt(100) < 45)
            {
                bool addGang = canGang && (!canCartel || gangs <= cartels || random.NextInt(2) == 0);
                int index = addGang ? gangs : cartels;
                string type = addGang ? "Street gang" : "Cartel";
                string name = addGang ? s_GangNames[index] : s_CartelNames[index];
                int members = addGang ? random.NextInt(8, 17) : random.NextInt(18, 31);
                int recruiters = addGang ? random.NextInt(1, 4) : random.NextInt(2, 5);
                int sellers = addGang ? random.NextInt(2, 5) : random.NextInt(3, 7);
                Add(type, name, members, recruiters, sellers);
                formed = name;
            }

            foreach (Organization organization in s_Organizations)
            {
                organization.Members += random.NextInt(0, 3);
                if (random.NextInt(100) < 18) organization.Recruiters++;
                if (random.NextInt(100) < 28) organization.Sellers++;
            }
            return formed;
        }

        public static Organization Pick(ref Random random)
        {
            if (s_Organizations.Count == 0) return null;
            return s_Organizations[random.NextInt(s_Organizations.Count)];
        }

        public static Organization PickForArea(string area, ref Random random)
        {
            if (s_Organizations.Count == 0) return null;
            var local = new List<Organization>();
            if (!string.IsNullOrWhiteSpace(area))
                foreach (Organization organization in s_Organizations)
                    if (organization.Territory == area) local.Add(organization);
            return local.Count > 0 && random.NextInt(100) < 72 ? local[random.NextInt(local.Count)] : Pick(ref random);
        }

        public static Organization PickGangBuyer(string area, Organization supplier, ref Random random)
        {
            var local = new List<Organization>();
            var all = new List<Organization>();
            foreach (Organization organization in s_Organizations)
            {
                if (organization == supplier || organization.Type != "Street gang") continue;
                all.Add(organization);
                if (!string.IsNullOrWhiteSpace(area) && organization.Territory == area) local.Add(organization);
            }
            if (local.Count > 0 && random.NextInt(100) < 75) return local[random.NextInt(local.Count)];
            return all.Count > 0 ? all[random.NextInt(all.Count)] : null;
        }

        public static void RecordSale(Organization organization, string product, string area, Entity location, int buyers, long profit,
            Organization gangBuyer = null, int wholesaleUnits = 0, long wholesaleValue = 0)
        {
            if (organization == null) return;
            organization.Sales++;
            organization.Buyers += buyers;
            organization.EstimatedProfit += profit;
            if (gangBuyer != null && wholesaleUnits > 0)
            {
                organization.WholesaleDeals++;
                organization.WholesaleUnits += wholesaleUnits;
                organization.WholesaleRevenue += wholesaleValue;
                gangBuyer.WholesaleDeals++;
                gangBuyer.WholesaleUnits += wholesaleUnits;
                gangBuyer.WholesaleRevenue += wholesaleValue;
                gangBuyer.LastActivity = Clean($"Wholesale purchase · {product} from {organization.Name}");
            }
            if (!string.IsNullOrWhiteSpace(product) && !organization.Products.Contains(product)) organization.Products.Add(product);
            RecordActivity(organization, area, location, $"Market activity · {product}");
        }

        public static void RecordActivity(Organization organization, string area, Entity location, string activity)
        {
            if (organization == null) return;
            if (!string.IsNullOrWhiteSpace(area) && area != "Undistricted area") organization.Territory = area;
            if (location != Entity.Null) organization.Location = location;
            if (!string.IsNullOrWhiteSpace(activity)) organization.LastActivity = Clean(activity);
        }

        public static void RecordCrime(string groupName)
        {
            Organization organization = Find(groupName);
            if (organization != null) organization.LinkedCrimeReports++;
        }

        public static Organization Find(string name)
        {
            foreach (Organization organization in s_Organizations) if (organization.Name == name) return organization;
            return null;
        }

        public static Organization ById(int id) => id >= 0 && id < s_Organizations.Count ? s_Organizations[id] : null;

        public static int SellersInNetwork(Organization organization, string area)
        {
            if (organization == null) return 0;
            int capacity = organization.Sellers;
            foreach (string allyName in organization.Allies)
            {
                Organization ally = Find(allyName);
                if (ally == null || (ally.Territory != "Unassigned turf" && ally.Territory != area)) continue;
                capacity += ally.Sellers / 3;
            }
            return capacity;
        }

        public static string Rows(uint frame)
        {
            var rows = new List<string>(s_Organizations.Count);
            foreach (Organization organization in s_Organizations)
                rows.Add($"{organization.Id}|{Clean(organization.Type)}|{Clean(organization.Name)}|{organization.Leaders}|{organization.Members}|{organization.Recruiters}|{organization.Sellers}|{organization.Sales}|{organization.Buyers}|{organization.EstimatedProfit}|{Clean(organization.Territory)}|{Clean(string.Join(", ", organization.Products))}|{Clean(string.Join(", ", organization.Rivals))}|{Clean(string.Join(", ", organization.Allies))}|{Clean(organization.LastActivity)}|{CityCrimeLedger.CountInArea(organization.Territory, frame)}|{organization.WholesaleDeals}|{organization.WholesaleUnits}|{organization.WholesaleRevenue}");
            return string.Join("\n", rows);
        }

        public static int Count(string type)
        {
            int count = 0;
            foreach (Organization organization in s_Organizations)
                if (organization.Type == type) count++;
            return count;
        }

        private static void Add(string type, string name, int members, int recruiters, int sellers)
        {
            var organization = new Organization
            {
                Id = s_Organizations.Count,
                Type = type,
                Name = name,
                Leaders = 1,
                Members = members,
                Recruiters = recruiters,
                Sellers = sellers
            };
            foreach (Organization existing in s_Organizations)
            {
                if (existing.Type == type)
                {
                    AddUnique(existing.Rivals, organization.Name);
                    AddUnique(organization.Rivals, existing.Name);
                }
                else
                {
                    AddUnique(existing.Allies, organization.Name);
                    AddUnique(organization.Allies, existing.Name);
                }
            }
            s_Organizations.Add(organization);
        }

        private static void AddUnique(List<string> list, string value) { if (!list.Contains(value)) list.Add(value); }

        private static string Clean(string value) => CityText.Clean(value);
    }
}
