using System.Collections.Generic;
using Game;
using Game.Buildings;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Creates map patios and sends occasional residents to bars for short visits.</summary>
    public partial class BarPatioSystem : GameSystemBase
    {
        private const uint kRefreshInterval = 2400;
        private const uint kVisitDuration = OutingStarter.FramesPerDay / 24u;
        private SimulationSystem m_SimulationSystem;
        private NameSystem m_NameSystem;
        private EntityQuery m_CompanyQuery;
        private EntityQuery m_CandidateQuery;
        private EntityQuery m_PopulationQuery;
        private readonly List<Entity> m_Bars = new List<Entity>();
        private uint m_NextRefresh;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
            m_CandidateQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<HouseholdMember>(),
                ComponentType.ReadOnly<CurrentBuilding>(), ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(),
                ComponentType.Exclude<Game.Tools.Temp>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 128;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled) return;
            uint frame = m_SimulationSystem.frameIndex;
            if (frame < m_NextRefresh) return;
            m_NextRefresh = frame + kRefreshInterval;
            RefreshPatios(frame);
        }

        private void RefreshPatios(uint frame)
        {
            BarFinder.CollectBarBuildings(EntityManager, m_CompanyQuery, m_Bars);
            var patios = new List<BarPatioLedger.Patio>(m_Bars.Count);
            foreach (Entity building in m_Bars)
            {
                if (!EntityManager.Exists(building) || !EntityManager.HasComponent<Game.Objects.Transform>(building)) continue;
                float3 position = EntityManager.GetComponentData<Game.Objects.Transform>(building).m_Position;
                string name = m_NameSystem.GetRenderedLabelName(building);
                if (string.IsNullOrWhiteSpace(name)) name = "Neighborhood bar";
                string area = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                if (string.IsNullOrWhiteSpace(area)) area = "City district";

                int seats = 6;
                int seated = 0;
                using NativeArray<Entity> citizens = m_PopulationQuery.ToEntityArray(Allocator.Temp);
                foreach (Entity citizen in citizens)
                {
                    if (!EntityManager.HasComponent<Leisure>(citizen)) continue;
                    Leisure leisure = EntityManager.GetComponentData<Leisure>(citizen);
                    if (leisure.m_TargetAgent == building) seated++;
                }
                seated = math.min(seats, seated);
                int queue = math.clamp(seated == seats ? seated / 2 : 0, 0, 4);
                patios.Add(new BarPatioLedger.Patio
                {
                    X = position.x + 18f,
                    Z = position.z + 10f,
                    Name = name + " patio",
                    Area = area,
                    Seats = seats,
                    Seated = seated,
                    Queue = queue,
                });
            }
            BarPatioLedger.Replace(patios);

            if (m_Bars.Count == 0 || m_CandidateQuery.IsEmptyIgnoreFilter) return;
            using NativeArray<Entity> candidates = m_CandidateQuery.ToEntityArray(Allocator.Temp);
            int population = m_PopulationQuery.CalculateEntityCount();
            int cap = PopulationCap.MaxAttendees(population, Mod.Settings.MaxAttendancePercent);
            int wanted = math.max(1, math.min(m_Bars.Count * 2, population / 1500));
            int allowed = math.min(wanted, AttendanceLedger.Remaining(cap, frame));
            if (allowed <= 0) return;

            var random = new Random(math.max(1u, frame * 3266489917u + 668265263u));
            uint duration = math.max(1u, kVisitDuration);
            int started = 0;
            for (int i = m_Bars.Count - 1; i > 0; i--)
            {
                int swap = random.NextInt(i + 1);
                (m_Bars[i], m_Bars[swap]) = (m_Bars[swap], m_Bars[i]);
            }
            int perBar = math.max(1, allowed / m_Bars.Count);
            foreach (Entity bar in m_Bars)
            {
                if (started >= allowed) break;
                int request = math.min(perBar, allowed - started);
                int visitors = OutingStarter.Start(EntityManager, candidates, request, ref random, frame, duration, bar);
                started += visitors;
            }
            if (started > 0)
            {
                AttendanceLedger.Add(started, frame + duration);
                Mod.log.Info($"Bar patios routed {started} residents to {m_Bars.Count} local bars for short visits.");
            }
        }
    }
}
