using System.Collections.Generic;
using Game;
using Game.Common;
using Game.Events;
using Game.Simulation;
using Game.UI;
using Unity.Collections;
using Unity.Entities;

namespace BarRush
{
    public partial class CrimeCompanySwapSystem : GameSystemBase
    {
        private EntityQuery m_CompanyQuery;
        private EntityQuery m_AccidentSiteQuery;
        private SimulationSystem m_SimulationSystem;
        private NameSystem m_NameSystem;
        private readonly HashSet<Entity> m_Handled = new HashSet<Entity>();

        protected override void OnCreate()
        {
            base.OnCreate();
            m_CompanyQuery = BarFinder.CreateCompanyQuery(EntityManager);
            m_NameSystem = World.GetOrCreateSystemManaged<NameSystem>();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_AccidentSiteQuery = GetEntityQuery(ComponentType.ReadOnly<AccidentSite>(),
                ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>());
            RequireForUpdate(m_AccidentSiteQuery);
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 64;

        protected override void OnUpdate()
        {
            var settings = Mod.Settings;
            if (settings == null || !settings.Enabled || !settings.CrimeReportsEnabled) return;
            m_Handled.RemoveWhere(e => !EntityManager.Exists(e));
            using NativeArray<Entity> sites = m_AccidentSiteQuery.ToEntityArray(Allocator.Temp);
            foreach (Entity building in sites)
            {
                AccidentSite site = EntityManager.GetComponentData<AccidentSite>(building);
                if ((site.m_Flags & AccidentSiteFlags.CrimeScene) == 0) continue;
                Entity incident = site.m_Event != Entity.Null ? site.m_Event : building;
                if (!m_Handled.Add(incident)) continue;
                Entity company = BarFinder.FindBarCompany(EntityManager, m_CompanyQuery, building);
                string placeName = m_NameSystem.GetRenderedLabelName(building);
                if (string.IsNullOrEmpty(placeName)) placeName = company != Entity.Null ? m_NameSystem.GetRenderedLabelName(company) : "City district";
                string areaName = CrimeAreaSystem.GetDistrictName(EntityManager, m_NameSystem, building);
                Entity district = EntityManager.HasComponent<Game.Areas.CurrentDistrict>(building)
                    ? EntityManager.GetComponentData<Game.Areas.CurrentDistrict>(building).m_District : Entity.Null;
                bool policeStationInArea = CrimeAreaSystem.HasPoliceStation(district);
                bool isBar = company != Entity.Null || BarCaseLedger.Get(building) > 0;
                uint reportedFrame = site.m_CreationFrame;
                CityCrimeLedger.Record(incident, building, placeName, areaName, policeStationInArea, isBar, reportedFrame);
                string location = $"{placeName} · {areaName}";
                bool closedForLoss = false;
                string lossText = company != Entity.Null
                    ? RecordBusinessCrimeLoss(EntityManager, building, company, isBar ? 45000 : 30000, out closedForLoss)
                    : "No operating business was linked to this location, so no business loss was recorded.";
                string robberyMessage = isBar ? $"Robbery reported at {placeName}. {lossText} Police response: {(policeStationInArea ? "station in district" : "no nearby station")}." : $"Robbery reported near {placeName}. {lossText} Police response: {(policeStationInArea ? "station in district" : "no nearby station")}.";
                CityBuzzFeed.AddCrime(incident, location, robberyMessage, reportedFrame, "Police report", "Robbery");
                if (settings.CrimeTweetsEnabled) PublishCrimeTweet(incident, location, reportedFrame);
                if (closedForLoss)
                    CityBuzzFeed.Add("Business closure", "City dispatch", location,
                        $"{placeName} has closed after repeated reported robberies and break-in losses left the modeled business unable to cover operating costs. The building remains in place; only its current company has closed.", reportedFrame);
                if (closedForLoss || !isBar) continue;
                BarCaseLedger.Record(building);
                if (!settings.CrimeChangesCompany) continue;
                if (ActiveEvents.HasSecurityAt(building, m_SimulationSystem.frameIndex))
                {
                    Mod.log.Info($"Event security prevented the Bar Rush company change at building {building.Index}.");
                    continue;
                }
                if (company == Entity.Null) continue;

                EntityManager.AddComponent<Deleted>(company);
                CityCrimeLedger.MarkCompanyChanged(incident);
                Mod.log.Info($"Crime at a bar: removed company {company.Index} so the building can get a new one.");
            }
        }

        private void PublishCrimeTweet(Entity incident, string placeName, uint frame)
        {
            var random = new Unity.Mathematics.Random(unchecked((uint)(incident.Index * 73856093) ^ (uint)(incident.Version * 19349663) ^ frame) | 1u);
            if (random.NextInt(100) >= 45 || !FamousSimRoster.TryPick(EntityManager, ref random, out Entity citizen, out string name)) return;

            string[] messages =
            {
                $"Seeing reports of a crime at {placeName}. Please look out for each other tonight.",
                $"A crime was reported near {placeName}. Hoping everyone involved is safe.",
                $"Just heard about an incident at {placeName}. Stay aware and check in on your people.",
            };
            int likes = random.NextInt(100, 18000);
            int dislikes = random.NextInt(20, 2400);
            CityBuzzFeed.AddSocial("Tweet", name, placeName, messages[random.NextInt(messages.Length)], frame, likes, dislikes, incident);
            FamousSimRoster.RecordPost(citizen);
        }

        private static readonly Dictionary<Entity, long> s_BusinessLosses = new Dictionary<Entity, long>();

        public static long BusinessLosses(Entity building)
        {
            return s_BusinessLosses.TryGetValue(building, out long losses) ? losses : 0;
        }

        public static string RecordBusinessCrimeLoss(EntityManager entityManager, Entity building, Entity company, long loss, out bool closed)
        {
            closed = false;
            if (company == Entity.Null || !entityManager.Exists(company))
                return "No operating business was linked to this location, so no business loss was recorded.";
            s_BusinessLosses.TryGetValue(building, out long previous);
            long total = previous + loss;
            s_BusinessLosses[building] = total;
            if (total < 150000)
                return $"The modeled business recorded ${loss:N0} in property, inventory, and interruption losses (${total:N0} cumulative).";
            entityManager.AddComponent<Deleted>(company);
            s_BusinessLosses.Remove(building);
            closed = true;
            return $"The modeled business recorded ${loss:N0} in additional losses (${total:N0} cumulative); repeated crime losses pushed it past its operating threshold and the company closed.";
        }
    }
}
