using System;
using System.Reflection;
using Unity.Entities;

namespace BarRush
{
    /// <summary>Optional bridge to Custom Chirps. Reflection keeps BarRush loadable when that mod is absent.</summary>
    public static class CustomChirpsBridge
    {
        private static MethodInfo s_PostLargeChirp;
        private static Type s_DepartmentType;
        private static bool s_LoggedMissing;

        public static bool Post(string text, Entity target = default(Entity), string sender = "Lively Skylines")
        {
            if (string.IsNullOrWhiteSpace(text)) return false;
            if (target == default(Entity)) target = Entity.Null;
            try
            {
                if (!ResolveApi()) return false;
                object department = Enum.Parse(s_DepartmentType, "Communications");
                s_PostLargeChirp.Invoke(null, new object[] { text, department, target, sender });
                return true;
            }
            catch (Exception exception)
            {
                Mod.log.Warn($"Custom Chirps integration could not post an update: {exception.GetBaseException().Message}");
                return false;
            }
        }

        private static bool ResolveApi()
        {
            if (s_PostLargeChirp != null) return true;
            Assembly assembly = null;
            foreach (Assembly loaded in AppDomain.CurrentDomain.GetAssemblies())
                if (loaded.GetName().Name == "CustomChirps") { assembly = loaded; break; }
            if (assembly == null)
            {
                if (!s_LoggedMissing)
                {
                    Mod.log.Info("Custom Chirps is not loaded; Lively Skylines will use its in-game feed and popup only.");
                    s_LoggedMissing = true;
                }
                return false;
            }

            Type api = assembly.GetType("CustomChirps.Systems.CustomChirpApiSystem", false);
            s_DepartmentType = assembly.GetType("CustomChirps.Systems.DepartmentAccount", false);
            if (api == null || s_DepartmentType == null || !s_DepartmentType.IsEnum) return false;
            s_PostLargeChirp = api.GetMethod("PostLargeChirp", BindingFlags.Public | BindingFlags.Static,
                null, new[] { typeof(string), s_DepartmentType, typeof(Entity), typeof(string) }, null);
            return s_PostLargeChirp != null;
        }
    }
}
