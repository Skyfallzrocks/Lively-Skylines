using Game;
using Game.Citizens;
using Game.Common;
using Game.Simulation;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

namespace BarRush
{
    /// <summary>Routes real citizens to player-designated city buildings during casino sessions.</summary>
    public partial class CasinoSystem : GameSystemBase
    {
        private const uint kSessionInterval = 2400;
        private SimulationSystem m_SimulationSystem;
        private CitySystem m_CitySystem;
        private EntityQuery m_CitizenQuery;
        private EntityQuery m_PopulationQuery;
        private uint m_NextSession;
        private int m_RequestedCasinoIndex = -1;

        public void RequestSession(int casinoIndex) => m_RequestedCasinoIndex = casinoIndex;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_SimulationSystem = World.GetOrCreateSystemManaged<SimulationSystem>();
            m_CitySystem = World.GetOrCreateSystemManaged<CitySystem>();
            m_CitizenQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.ReadOnly<CurrentBuilding>(),
                ComponentType.Exclude<Leisure>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
            m_PopulationQuery = GetEntityQuery(ComponentType.ReadOnly<Citizen>(), ComponentType.Exclude<Deleted>(), ComponentType.Exclude<Game.Tools.Temp>(), ComponentType.Exclude<Game.Prefabs.PrefabData>());
        }

        public override int GetUpdateInterval(SystemUpdatePhase phase) => 128;

        protected override void OnUpdate()
        {
            if (Mod.Settings == null || !Mod.Settings.Enabled) return;
            uint frame = m_SimulationSystem.frameIndex;
            int requestedIndex = m_RequestedCasinoIndex;
            m_RequestedCasinoIndex = -1;
            bool manualSession = requestedIndex >= 0;
            if (!manualSession)
            {
                if (frame < m_NextSession) return;
                m_NextSession = frame + kSessionInterval;
            }
            if (CasinoLedger.Count == 0) return;

            int population = m_PopulationQuery.CalculateEntityCount();
            int cap = PopulationCap.MaxAttendees(population, Mod.Settings.MaxAttendancePercent);
            int remaining = AttendanceLedger.Remaining(cap, frame);
            if (remaining <= 0 || m_CitizenQuery.IsEmptyIgnoreFilter)
            {
                if (manualSession && CasinoLedger.Get(requestedIndex) is CasinoLedger.Casino unavailable)
                {
                    unavailable.LastVisitors = 0;
                    unavailable.LastReport = remaining <= 0 ? "No residents available under the city outing cap." : "No eligible residents were available for this session.";
                    CityBuzzFeed.Add("Casino session delayed", "Casino operations", unavailable.Name, unavailable.LastReport, frame);
                }
                return;
            }
            using NativeArray<Entity> candidates = m_CitizenQuery.ToEntityArray(Allocator.Temp);
            var random = new Random(math.max(1u, frame * 747796405u + 2891336453u));
            uint duration = math.max(1u, OutingStarter.FramesPerDay / 16u);
            int totalStarted = 0;
            int firstCasino = manualSession ? requestedIndex : 0;
            int endCasino = manualSession ? requestedIndex + 1 : CasinoLedger.All.Count;
            for (int i = firstCasino; i < endCasino && i < CasinoLedger.All.Count && remaining > 0; i++)
            {
                CasinoLedger.Casino casino = CasinoLedger.All[i];
                if (casino.Building == Entity.Null || !EntityManager.Exists(casino.Building) || !EntityManager.HasComponent<Game.Objects.Transform>(casino.Building)) continue;
                if (!casino.Open || (!manualSession && !casino.AllDay && !IsNightTime())) continue;
                bool licensed = CityPolicyLedger.IsActive("Gambling Licenses");
                float demandMult = (0.6f + casino.Reputation / 100f) * (licensed ? 1.2f : 1f) * (casino.Shows ? 1.3f : 1f) * (casino.ResponsibleGaming ? 0.92f : 1f);
                int floorDemand = casino.Slots * 3 + casino.Tables * 2 + casino.Poker * 2 + casino.Sportsbook * 2 + casino.Marketing * 2 + (casino.Hotel ? 4 : 0);
                int desired = math.clamp((int)((population / 4000 + floorDemand) * demandMult), 2, 60);
                int admitted = math.min(desired, remaining);
                int started = OutingStarter.Start(EntityManager, candidates, admitted, ref random, frame, duration, casino.Building);
                casino.LastVisitors = started;
                casino.TotalVisitors += started;
                long net = RunEconomy(casino, started, licensed, frame, ref random);
                casino.LastSessionFrame = frame;
                casino.LastNet = net;
                casino.CityProfit += net;
                casino.ModeledRevenue += math.max(0L, net);
                PayCity(net);
                casino.LastReport = started > 0
                    ? $"Session served {started} guest(s); the city {(net >= 0 ? "earned" : "lost")} ${math.abs(net):N0}."
                    : "Session ran, but no eligible resident outing could be started.";
                remaining -= started;
                totalStarted += started;
                if (started > 0) Incidents(casino, started, frame, ref random);
                CityBuzzFeed.Add("Casino session · " + started + " guests", "Casino operations", casino.Name, casino.LastReport, frame);
            }
            if (totalStarted > 0)
                AttendanceLedger.Add(totalStarted, frame + duration);
        }

        private void PayCity(long net)
        {
            if (net == 0) return;
            Entity city = m_CitySystem.City;
            if (city == Entity.Null || !EntityManager.Exists(city) || !EntityManager.HasComponent<Game.City.PlayerMoney>(city)) return;
            var money = EntityManager.GetComponentData<Game.City.PlayerMoney>(city);
            if (money.m_Unlimited) return;
            int amount = (int)math.clamp(net, -int.MaxValue, int.MaxValue);
            if (amount > 0) money.Add(amount); else money.Subtract(-amount);
            EntityManager.SetComponentData(city, money);
        }

        /// <summary>Wagers, house edge, jackpots, whales and running costs for one session. Returns city net.</summary>
        private static long RunEconomy(CasinoLedger.Casino c, int guests, bool licensed, uint frame, ref Random random)
        {
            if (guests <= 0) return -(300 + c.Security * 200);
            float perGuest = 40 + c.Slots * 55 + c.Tables * 90 + c.Poker * 70 + c.Sportsbook * 60;
            perGuest *= 1f + c.Marketing * 0.1f;
            float weight = c.Slots * 55f + c.Tables * 90f + c.Poker * 70f + c.Sportsbook * 60f + 1f;
            float edge = (c.Slots * 55f * 0.085f + c.Tables * 90f * 0.03f + c.Poker * 70f * 0.05f + c.Sportsbook * 60f * 0.045f) / weight;
            long handle = (long)(guests * perGuest);
            float swing = 0.6f + random.NextFloat() * 0.8f;
            long win = (long)(handle * math.max(0.02f, edge) * swing);
            // High rollers.
            int whaleChance = (c.Hotel ? 6 : 2) + c.Reputation / 40;
            if (random.NextInt(100) < whaleChance)
            {
                long stake = random.NextInt(40000, 200001);
                handle += stake; c.Whales++;
                bool whaleWins = random.NextInt(100) < 35;
                long result = whaleWins ? -stake / 2 : stake / 4;
                win += result;
                c.Log(whaleWins ? $"A high roller walked out ${stake / 2:N0} up." : $"A high roller lost ${stake / 4:N0} at the tables.");
                CityBuzzFeed.Add("Casino · high roller", "Nightlife Now", c.Name, whaleWins ? $"A high roller beat the house for ${stake / 2:N0} at {c.Name}." : $"A high roller dropped ${stake / 4:N0} at {c.Name} tonight.", frame);
            }
            // Slot jackpots.
            if (c.Slots > 0 && random.NextInt(100) < c.Slots * 3)
            {
                long jackpot = random.NextInt(15000, 80001) * c.Slots;
                win -= jackpot; c.Jackpots++; if (jackpot > c.BiggestJackpot) c.BiggestJackpot = jackpot;
                c.Reputation = math.min(100, c.Reputation + 3);
                c.Log($"JACKPOT: a resident hit ${jackpot:N0} on the slots.");
                CityBuzzFeed.Add("Casino · jackpot", "Nightlife Now", c.Name, $"JACKPOT! A local resident won ${jackpot:N0} on the slots at {c.Name}.", frame);
            }
            c.Handle += handle;
            long costs = 600 + (c.Slots + c.Tables * 2 + c.Poker * 2 + c.Sportsbook) * 350 + c.Security * 400 + c.Marketing * 300
                + (c.Hotel ? 1500 : 0) + (c.Shows ? 2500 : 0) + (c.ResponsibleGaming ? 600 : 0) + (c.Aml ? 400 : 0);
            // Unlicensed gambling risks state fines.
            if (!licensed && random.NextInt(100) < 8)
            {
                costs += 15000; c.Fines++;
                c.Log("State regulators fined the casino $15,000 for operating without Gambling Licenses.");
                CityBuzzFeed.Add("Casino · fine", "City finance", c.Name, $"{c.Name} was fined $15,000. Pass the Gambling Licenses law to operate legally.", frame);
            }
            // Problem gambling.
            c.AtRisk = c.AtRisk * 0.98f + guests * (c.Slots + c.Sportsbook + 1) / 30f * (c.ResponsibleGaming ? 0.4f : 1f);
            if ((int)(c.AtRisk / 25f) > c.AtRiskAlerted)
            {
                c.AtRiskAlerted = (int)(c.AtRisk / 25f);
                PublicReactionLedger.Add("Problem gambling rising near the casino", 2);
                c.Log($"Gambling helpline calls are rising: about {(int)c.AtRisk} residents now at risk.");
                CityBuzzFeed.Add("Community · problem gambling", "Harbor Daily", c.District, $"Counselors report about {(int)c.AtRisk} residents now at risk of problem gambling near {c.Name}.{(c.ResponsibleGaming ? "" : " Advocates are calling for a responsible-gaming program.")}", frame);
            }
            if (c.Hotel || c.Shows) c.Reputation = math.min(100, c.Reputation + 1);
            return win - costs;
        }

        private void Incidents(CasinoLedger.Casino c, int guests, uint frame, ref Random random)
        {
            int chance = math.max(2, 14 - c.Security * 4 + guests / 15);
            if (random.NextInt(100) >= chance) return;
            int kind = random.NextInt(4);
            if (kind == 0)
            {
                if (c.Security >= 2) { c.CheatersCaught++; c.Log("Security caught a card-counting team and banned them."); CityBuzzFeed.Add("Casino · cheating", "Crime Desk", c.Name, $"Security at {c.Name} caught a cheating ring and handed them to police.", frame); }
                else { c.Reputation = math.max(0, c.Reputation - 3); c.Log("A cheating ring took the tables for thousands before slipping out."); PayCity(-random.NextInt(5000, 20001)); }
            }
            else if (kind == 1)
            {
                c.Robberies++; c.SafetyReports++; c.Reputation = math.max(0, c.Reputation - 4);
                Entity incident = EntityManager.CreateEntity();
                CityCrimeLedger.Record(incident, c.Building, c.Name, c.District, false, false, frame, $"A guest was robbed in the parking lot at {c.Name}.", "Robbery", "Unidentified");
                c.Log("A guest was robbed in the parking lot; police are chasing the suspect.");
            }
            else if (kind == 2)
            {
                c.SafetyReports++; PublicReactionLedger.Add("Loan sharks working the casino floor", 2);
                c.Log("Loan sharks were reported working the floor.");
                CityBuzzFeed.Add("Casino · loan sharks", "Crime Desk", c.Name, $"Guests reported loan sharks offering cash at {c.Name}.", frame);
            }
            else
            {
                long amount = random.NextInt(20000, 90001);
                string group = GangEconomyLedger.LaunderThrough(c.Aml, amount, frame);
                if (group == null) return;
                if (c.Aml) { c.LaunderingBlocked++; c.Log($"Anti-money-laundering checks stopped {group} from washing ${amount:N0}."); CityBuzzFeed.Add("Casino · laundering stopped", "Crime Desk", c.Name, $"AML checks at {c.Name} flagged {group} trying to wash ${amount:N0}. Police are investigating.", frame); }
                else { c.LaunderingMissed++; c.Log($"Investigators later found {group} washed ${amount:N0} through the cage."); }
            }
        }

        private bool IsNightTime()
        {
            float time = World.GetOrCreateSystemManaged<TimeSystem>().normalizedTime;
            return time >= 0.75f || time < 0.25f;
        }

    }
}
